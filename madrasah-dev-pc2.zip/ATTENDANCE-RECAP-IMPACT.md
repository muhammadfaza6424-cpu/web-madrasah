# DAMPAK ABSENSI PER SESI TERHADAP REKAP & KOMPATIBILITAS

- **Tanggal:** 2 Oktober 2026
- **Workspace:** `/var/www/madrasah-dev`
- **Sifat:** READ-ONLY. Tidak ada file, database, migration, dependency, deployment, atau push yang diubah.
- **Konteks:** audit semua penggunaan tabel `attendance` bila kelak `attendance` menjadi **per sesi** (`schedule_id`) dengan baris lama tetap `schedule_id = NULL`.

---

## A. Daftar File yang Terdampak
- **Backend absensi:** `backend/src/modules/attendance/attendance.routes.ts` — GET per kelas, GET per siswa, rekap `SUM/COUNT`, dan `PUT` upsert.
- **Backend raport:** `backend/src/modules/reports/report.routes.ts` — query rekap absensi semester + `recorded_days` ke `snapshot_json`.
- **Backend import:** `backend/src/modules/imports/attendance-import.routes.ts` (baca/tulis `attendance`, dedup per `(student,date)`) dan `attendance-xlsx.ts` (template tanpa sesi).
- **Backend pendukung:** `backend/src/modules/support/operations.routes.ts` (guard periode `academic_years`), `backend/src/server.ts` (mount router), `backend/src/middleware/mutationAudit.ts` (audit).
- **Frontend & skema:** `AcademicEditor.tsx`, `AcademicPage.tsx`, `ReportPage.tsx`, `AttendanceImport.tsx`, `app/App.tsx`; skema `001_initial_schema.sql` (UNIQUE) dan `008_attendance_import_provenance.sql`.

## B. Query yang Akan Salah Jika Attendance Menjadi Per Sesi
- `GET /api/attendance/class/:classId` — daftar siswa LEFT JOIN `attendance` pada rentang tanggal; beberapa sesi/hari menghasilkan baris ganda dan status saling menimpa di UI.
- `GET /api/attendance/student/me` — daftar + rekap tanpa diskriminator sesi; satu hari bisa muncul berkali-kali.
- Rekap raport `SUM(status='H'...) / COUNT(*) recorded_days` (report.routes.ts) — menghitung **sesi**, bukan hari; "Hari tercatat" membengkak.
- `attendance-import.routes.ts` apply: `SELECT source FROM attendance WHERE student_id=? AND attendance_date=?` mengasumsikan satu baris per hari; pengecekan `MANUAL_ATTENDANCE_EXISTS` bisa salah sasaran bila ada sesi.
- Dedup/keunikan `UNIQUE(student_id, attendance_date)` (001) — akan gagal/konflik jika sesi ganda ditulis tanpa perluasan constraint.

## C. Yang Harus Menghitung SESI (per pertemuan)
- Tampilan/penyimpanan input absensi ketika user memilih `schedule_id` (satu baris = satu sesi per tanggal); ini yang membuat sesi ganda sah hidup berdampingan.
- Rekap per mata pelajaran/guru/pengampu jika kelak dibutuhkan (gabungan `schedules → teaching_assignments`).
- Deteksi duplikat di dalam satu konteks sesi (mis. mencegah menulis dua kali untuk `(student, schedule, date)`).
- Import Excel **hanya jika** template kelak memuat kolom sesi; saat ini belum, jadi tetap dianggap harian.
- Analitik kehadiran per jadwal (jam/mapel) atau audit perubahan per sesi.

## D. Yang Harus Menghitung HARI (distinct date)
- Rekap raport `recorded_days` dan `H/S/I/A` per semester (report.routes.ts) — pakai `COUNT(DISTINCT attendance_date)` agar tidak terpengaruh jumlah sesi; `attendanceStatus` READY tetap berdasar periode.
- Rekap `GET /api/attendance/student/me` — jumlah hari hadir/sakit/izin/alpa yang ditampilkan ke santri.
- Tampilan rekap di `AcademicPage.tsx` (read-only) agar konsisten dengan raport.
- Guard periode di `operations.routes.ts` (mengubah tanggal tahun ajaran) bersifat hari/kalender, bukan sesi.
- Statistik dashboard (bila ditambah kelak) yang menyatakan "hari efektif tercatat".

## E. Yang Harus Tetap Kompatibel dengan Attendance Lama `schedule_id = NULL`
- Semua baris `attendance` yang sudah ada (`schedule_id=NULL`) tetap satu baris per `(student, date)` dan tetap unik.
- `GET /api/attendance/class/:classId` dan `/student/me` default (tanpa `scheduleId`) harus mengembalikan mode harian lama tanpa perubahan kontrak.
- `PUT /api/attendance` tanpa `scheduleId` harus tetap menghasilkan `schedule_id=NULL` (menulis ke baris harian).
- `POST /api/imports/attendance/:batchId/apply` tetap menerapkan sebagai absensi harian (`schedule_id=NULL`), tidak boleh gagal karena constraint baru.
- `report.routes.ts` dan `AcademicEditor.tsx` harus tetap bekerja untuk data lama (tampilan "tanpa sesi").

## F. Perubahan Minimal yang Diperlukan
1. `report.routes.ts`: ganti `COUNT(*) recorded_days` menjadi `COUNT(DISTINCT attendance_date)` dan putuskan `H/S/I/A` (per hari vs per sesi) sebelum snapshot; versi snapshot `version` perlu dinaikkan bila semantik berubah.
2. `attendance.routes.ts`: pada rekap `/student/me`, gunakan `COUNT(DISTINCT attendance_date)`; pada daftar kelas, sediakan filter opsional `scheduleId` dan default tetap `schedule_id IS NULL` agar perilaku lama terjaga.
3. `attendance.routes.ts` (write): tambahkan `scheduleId` opsional dan sertakan pada upsert + validasi scope; pastikan konflik `(student, date, schedule_key)` tidak menimpa baris harian.
4. `attendance-import.routes.ts`: jaga `apply` tetap `schedule_id=NULL`; perbarui pengecekan `existing` agar cocok dengan constraint baru (mis. `schedule_id IS NULL`).
5. Skema (di luar audit ini, butuh persetujuan): kolom `schedule_id NULL` + kolom generated `schedule_key=COALESCE(schedule_id,0)` + `UNIQUE(student_id, attendance_date, schedule_key)`.

## G. Risiko Regresi
- **Angka raport berubah** bila rekap dihitung per sesi tanpa `DISTINCT`; snapshot `version` lama vs baru bisa tidak konsisten saat dibandingkan.
- **Baris ganda di UI** pada `AcademicPage`/`AcademicEditor` jika default query tidak dibatasi `schedule_id IS NULL`.
- **Upsert menimpa data lama** bila `schedule_id` tidak disertakan pada `ON DUPLICATE KEY UPDATE`.
- **Import berhenti bekerja** bila constraint baru tidak diikuti pada cek `existing` dan insert apply.
- **Scope guru melebar/berubah** bila validasi sesi memakai `teaching_assignment` sedangkan guru hanya wali kelas (mode harian), memicu `OUTSIDE_TEACHER_SCOPE` yang tidak terduga.

## H. Test yang Harus Ditambahkan
- Unit: `recorded_days` = jumlah hari unik meski ada beberapa sesi pada tanggal sama (attendance recap & report snapshot).
- Integrasi: `PUT /api/attendance` dengan `scheduleId` berbeda pada tanggal sama menghasilkan dua baris; tanpa `scheduleId` tetap satu baris `NULL`.
- Integrasi: `GET /api/attendance/class/:classId` default tidak menggandakan baris saat data sesi bertambah.
- Integrasi: import Excel `apply` tetap sukses menulis `schedule_id=NULL` dan menghormati `MANUAL_ATTENDANCE_EXISTS`.
- Regresi: snapshot raport lama (`version` lama) tetap dapat dibaca/ditampilkan `ReportPage` tanpa error.
