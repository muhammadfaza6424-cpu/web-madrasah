# FINAL PLAN REVIEW (SETELAH REVISI) — ABSENSI PER SESI

- **Tanggal:** 2 Oktober 2026
- **Workspace:** `/var/www/madrasah-dev`
- **Sifat:** REVIEW ONLY. Tidak ada source code, migration, database, dependency, deployment, atau push yang diubah.
- **Ditinjau:** `ATTENDANCE-IMPLEMENTATION-PLAN.md` (revisi final) + `ATTENDANCE-FINAL-PLAN-REVIEW.md`.

---

## 1. Status Migration 039
- Prefix migration tertinggi di repository = **038**; `039` **tidak ada** di `database/migrations`.
- Tidak ada referensi file `039_attendance_schedule_session.sql` di filesystem selain dokumen rencana.
- Kesimpulan: **nomor 039 benar, belum dibuat, dan belum dijalankan.**
- Verifikasi final saat eksekusi: operator memeriksa tabel `schema_migrations` (tidak dilakukan di sini karena tanpa akses DB).

## 2. Keputusan Produk yang Sudah Terpenuhi di Rencana
- Guru mengisi **per sesi**; hanya jadwal miliknya (validasi `teaching_assignment.teacher_id`).
- ADMIN/SUPER_ADMIN melihat & mengoreksi berdasarkan tanggal, kelas, sesi; koreksi diaudit.
- Excel tetap **absensi harian** `schedule_id=NULL`; data lama tanpa backfill.
- Istilah "hari" = **tanggal unik**; rekap sesi terpisah berlabel "sesi".
- Raport memakai **rekap harian**; snapshot terbit lama tidak dihitung ulang.

## 3. Semantik Rekap (Final)
- `recorded_days = COUNT(DISTINCT attendance_date)`.
- H/S/I/A raport dihitung setelah menggabungkan sesi per `attendance_date`, prioritas **A > I > S > H**.
- Jaminan: **H + S + I + A = recorded_days**.
- Rekap per sesi tetap ada tetapi **wajib berlabel "sesi"**, tidak boleh untuk raport.

## 4. Cakupan Test (Final)
- 3 sesi H = 1 hari H; H+H+S = 1 hari S; H+I+S = 1 hari I; H+S+A = 1 hari A.
- H+H+S **tidak** menghasilkan H=2,S=1 pada rekap harian; `recorded_days=1`.
- Dua sesi pada tanggal sama tetap tersimpan sebagai dua record SESI.
- Excel `schedule_id=NULL`; data lama `schedule_id=NULL` tetap kompatibel.

## 5. File Final yang Akan Diubah
- **Backend:** `attendance.routes.ts`, `reports/report.routes.ts`, `imports/attendance-import.routes.ts`.
- **Database:** `database/migrations/039_attendance_schedule_session.sql` (belum dijalankan).
- **Frontend:** `academic/AcademicEditor.tsx` (wajib); `academic/AcademicPage.tsx`, `production/AttendanceImport.tsx`, `reports/ReportPage.tsx` (opsional).
- **Tests:** `attendance-session.test.ts` + `attendance-recap.test.ts` (baru); `attendance-xlsx.test.ts` dipertahankan.

## 6. Ambiguitas yang Masih Tercatat
- Prioritas A>I>S>H sudah final dari produk; **definisi "sesi"** mengacu pada `schedules` (template mingguan) + `attendance_date` — bukan tabel pertemuan baru. Ini konsisten dengan desain sesi-ringan; bila kelak butuh instance pertemuan eksplisit, perlu keputusan baru.
- Status kelayakan snapshot version 8 lama tidak diubah; hanya draft baru memakai version 9.

## 7. Kesiapan
Rencana **siap implementasi setelah persetujuan eksplisit**. Tidak ada file aplikasi, migration, atau database yang diubah pada review ini.
