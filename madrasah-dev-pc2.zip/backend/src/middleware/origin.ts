import type { RequestHandler } from 'express';
import { env } from '../config/env.js';

const frontend = new URL(env.FRONTEND_ORIGIN);
export const trustedOrigins = [frontend.origin];
if (env.NODE_ENV === 'development' && ['localhost', '127.0.0.1'].includes(frontend.hostname)) {
  const alternate = new URL(frontend.origin);
  alternate.hostname = frontend.hostname === 'localhost' ? '127.0.0.1' : 'localhost';
  trustedOrigins.push(alternate.origin);
}

export const requireTrustedOrigin: RequestHandler = (req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) { next(); return; }
  const origin = req.get('origin');
  if (!origin || !trustedOrigins.includes(origin)) {
    res.status(403).json({ error: 'UNTRUSTED_ORIGIN' });
    return;
  }
  next();
};
