import {Router} from 'express';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcrypt';
import crypto from 'node:crypto';
import nodemailer from 'nodemailer';
import {z} from 'zod';
import {db} from '../../config/db.js';
import {env} from '../../config/env.js';
import {writeAudit} from '../audit/audit.service.js';

export const superRecoveryRouter=Router();
const username=z.object({username:z.string().trim().min(1).max(100)}).strict();
const confirm=username.extend({code:z.string().regex(/^\d{6}$/),newPassword:z.string().min(12).max(72).refine(v=>Buffer.byteLength(v,'utf8')<=72)}).strict();
const requestLimit=rateLimit({windowMs:15*60*1000,limit:5,standardHeaders:'draft-8',legacyHeaders:false});
const confirmLimit=rateLimit({windowMs:15*60*1000,limit:10,standardHeaders:'draft-8',legacyHeaders:false});
const generic={message:'Jika akun terdaftar, permintaan pemulihan telah diproses.'};
const invalid={error:'INVALID_OR_EXPIRED_CODE'};

function mailConfigured(){return Boolean(env.SMTP_HOST&&env.SUPER_ADMIN_RECOVERY_EMAIL&&(!env.SMTP_USER||env.SMTP_PASSWORD))}
function transporter(){
  if(!mailConfigured())throw new Error('SMTP_NOT_CONFIGURED');
  const loopback=['127.0.0.1','localhost','::1'].includes(env.SMTP_HOST!);
  if(!env.SMTP_USER&&!loopback)throw new Error('SMTP_AUTH_REQUIRED');
  if(env.SMTP_USER&&env.SMTP_USER.toLowerCase()!==env.SUPER_ADMIN_RECOVERY_EMAIL!.toLowerCase())throw new Error('SMTP_IDENTITY_MISMATCH');
  return nodemailer.createTransport({
    host:env.SMTP_HOST!,port:env.SMTP_PORT,secure:env.SMTP_PORT===465,
    requireTLS:env.SMTP_PORT!==465&&!loopback,
    auth:env.SMTP_USER?{user:env.SMTP_USER,pass:env.SMTP_PASSWORD!}:undefined,
    connectionTimeout:10000,greetingTimeout:10000,socketTimeout:15000,
  });
}
function codeHash(userId:number,code:string){return crypto.createHmac('sha256',env.AUTH_JWT_SECRET).update(`${userId}:${code}`).digest('hex')}

superRecoveryRouter.post('/request',requestLimit,async(req,res,next)=>{
  const parsed=username.safeParse(req.body);
  if(!parsed.success){res.status(400).json({error:'INVALID_RECOVERY_REQUEST'});return}
  if(!mailConfigured()){res.status(503).json({error:'EMAIL_RECOVERY_UNAVAILABLE'});return}
  const conn=await db.getConnection();let challengeId:number|undefined;let code:string|undefined;
  try{
    await conn.beginTransaction();
    const[users]:any=await conn.query("SELECT u.id FROM users u JOIN roles r ON r.id=u.role_id WHERE u.username=? AND u.status='ACTIVE' AND r.code='SUPER_ADMIN' FOR UPDATE",[parsed.data.username]);
    const user=users[0];
    if(!user){await conn.rollback();res.status(202).json(generic);return}
    const[recent]:any=await conn.query('SELECT id FROM super_admin_recovery_otp WHERE user_id=? AND created_at>DATE_SUB(NOW(),INTERVAL 60 SECOND) LIMIT 1',[user.id]);
    if(recent[0]){await conn.rollback();res.status(202).json(generic);return}
    code=crypto.randomInt(0,1000000).toString().padStart(6,'0');
    await conn.execute('UPDATE super_admin_recovery_otp SET used_at=NOW() WHERE user_id=? AND used_at IS NULL',[user.id]);
    const[result]:any=await conn.execute('INSERT INTO super_admin_recovery_otp(user_id,code_hash,expires_at) VALUES(?,?,DATE_ADD(NOW(),INTERVAL 10 MINUTE))',[user.id,codeHash(user.id,code)]);
    challengeId=result.insertId;
    await writeAudit(req,{userId:user.id,action:'AUTH.SUPER_ADMIN_OTP_REQUESTED',entityType:'user',entityId:user.id},conn);
    await conn.commit();
    try{
      await transporter().sendMail({from:env.SUPER_ADMIN_RECOVERY_EMAIL!,to:env.SUPER_ADMIN_RECOVERY_EMAIL!,subject:'Kode pemulihan akun Madrasah',text:`Kode pemulihan akun Super Admin: ${code}\nBerlaku selama 10 menit. Jika Anda tidak meminta kode ini, abaikan pesan ini.`});
    }catch(error){
      await db.execute('UPDATE super_admin_recovery_otp SET used_at=NOW() WHERE id=?',[challengeId!]);
      console.error('RECOVERY_MAIL_FAILED',error instanceof Error?error.message:'unknown');
      res.status(503).json({error:'EMAIL_RECOVERY_UNAVAILABLE'});return;
    }
    res.status(202).json(generic);
  }catch(e){await conn.rollback();next(e)}finally{conn.release()}
});

superRecoveryRouter.post('/confirm',confirmLimit,async(req,res,next)=>{
  const parsed=confirm.safeParse(req.body);
  if(!parsed.success){res.status(400).json({error:'INVALID_RECOVERY_CONFIRMATION'});return}
  const conn=await db.getConnection();
  try{
    await conn.beginTransaction();
    const[users]:any=await conn.query("SELECT u.id FROM users u JOIN roles r ON r.id=u.role_id WHERE u.username=? AND u.status='ACTIVE' AND r.code='SUPER_ADMIN' FOR UPDATE",[parsed.data.username]);
    const user=users[0];
    if(!user){await conn.rollback();res.status(400).json(invalid);return}
    const[challenges]:any=await conn.query('SELECT id,code_hash,attempts,expires_at>NOW() valid FROM super_admin_recovery_otp WHERE user_id=? AND used_at IS NULL ORDER BY id DESC LIMIT 1 FOR UPDATE',[user.id]);
    const challenge=challenges[0];
    if(!challenge||!challenge.valid||challenge.attempts>=5){await conn.rollback();res.status(400).json(invalid);return}
    const expected=Buffer.from(challenge.code_hash,'hex');const supplied=Buffer.from(codeHash(user.id,parsed.data.code),'hex');
    if(!crypto.timingSafeEqual(expected,supplied)){
      await conn.execute('UPDATE super_admin_recovery_otp SET attempts=attempts+1,used_at=IF(attempts>=4,NOW(),used_at) WHERE id=?',[challenge.id]);
      await conn.commit();res.status(400).json(invalid);return;
    }
    const hash=await bcrypt.hash(parsed.data.newPassword,12);
    await conn.execute('UPDATE users SET password_hash=?,must_change_password=0,session_version=session_version+1 WHERE id=?',[hash,user.id]);
    await conn.execute('UPDATE super_admin_recovery_otp SET used_at=NOW() WHERE user_id=? AND used_at IS NULL',[user.id]);
    await writeAudit(req,{userId:user.id,action:'AUTH.SUPER_ADMIN_RECOVERED',entityType:'user',entityId:user.id,metadata:{method:'email_otp'}},conn);
    await conn.commit();res.status(204).end();
  }catch(e){await conn.rollback();next(e)}finally{conn.release()}
});
