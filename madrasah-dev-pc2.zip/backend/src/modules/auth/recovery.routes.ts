import {Router} from 'express';
import rateLimit from 'express-rate-limit';
import {z} from 'zod';
import {db} from '../../config/db.js';
import {requireAuthentication} from '../../middleware/authentication.js';
import {requireRole} from '../../middleware/authorization.js';

export const recoveryRouter=Router();
const request=z.object({username:z.string().trim().min(1).max(100)}).strict();
const limiter=rateLimit({windowMs:15*60*1000,limit:5,standardHeaders:'draft-8',legacyHeaders:false});

recoveryRouter.post('/request',limiter,async(req,res,next)=>{try{
  const parsed=request.safeParse(req.body);
  if(!parsed.success){res.status(400).json({error:'INVALID_RECOVERY_REQUEST'});return}
  const[users]:any=await db.query("SELECT u.id,r.code role FROM users u JOIN roles r ON r.id=u.role_id WHERE u.username=? AND u.status='ACTIVE' LIMIT 1",[parsed.data.username]);
  if(users[0]&&users[0].role!=='SUPER_ADMIN')await db.execute(`INSERT INTO password_reset_requests(user_id) SELECT ? WHERE NOT EXISTS(SELECT 1 FROM password_reset_requests WHERE user_id=? AND status='OPEN')`,[users[0].id,users[0].id]);
  res.status(202).json({message:'Jika akun terdaftar, permintaan disampaikan kepada pengelola akun.'});
}catch(e){next(e)}});

recoveryRouter.get('/requests',requireAuthentication,requireRole('ADMIN','SUPER_ADMIN'),async(req,res,next)=>{try{
  const scope=req.auth!.role==='SUPER_ADMIN'?"r.code<>'SUPER_ADMIN'":"r.code IN('GURU','SANTRI')";
  const[rows]=await db.query(`SELECT pr.id,pr.user_id,u.username,r.code role,pr.requested_at FROM password_reset_requests pr JOIN users u ON u.id=pr.user_id JOIN roles r ON r.id=u.role_id WHERE pr.status='OPEN' AND ${scope} ORDER BY pr.requested_at DESC LIMIT 200`);
  res.json({requests:rows});
}catch(e){next(e)}});
