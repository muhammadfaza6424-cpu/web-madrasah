import {Router} from 'express';
import {z} from 'zod';
import {db} from '../../config/db.js';
import {requireAuthentication} from '../../middleware/authentication.js';
import {requirePermission,requireRole} from '../../middleware/authorization.js';
import {writeAudit} from '../audit/audit.service.js';

export const rolloverRouter=Router();
rolloverRouter.use(requireAuthentication,requireRole('SUPER_ADMIN','ADMIN'),requirePermission('settings.operational.manage'));

const decisions=z.object({targetYearId:z.number().int().positive(),students:z.array(z.object({studentId:z.number().int().positive(),outcome:z.enum(['PROMOTE','REPEAT','GRADUATE','WITHDRAW']),targetClassId:z.number().int().positive().nullable()}).strict()).min(1).max(5000)}).strict();

rolloverRouter.get('/preview',async(_req,res,next)=>{try{
  const[years]:any=await db.query('SELECT id,name,is_active,starts_on,ends_on FROM academic_years ORDER BY starts_on DESC');
  const source=years.filter((x:any)=>x.is_active);
  if(source.length!==1){res.status(409).json({error:'ONE_ACTIVE_YEAR_REQUIRED'});return}
  const[classes]:any=await db.query('SELECT id,code,name,level,active FROM classes ORDER BY level,code');
  const[students]:any=await db.query(`SELECT s.id student_id,s.nis,s.name,c.id class_id,c.code class_code,c.level,se.status FROM student_enrollments se JOIN students s ON s.id=se.student_id JOIN classes c ON c.id=se.class_id WHERE se.academic_year_id=? AND se.status='ACTIVE' AND s.status='ACTIVE' ORDER BY c.level,c.code,s.name`,[source[0].id]);
  res.json({sourceYear:source[0],targetYears:years.filter((x:any)=>!x.is_active),classes:classes.filter((x:any)=>x.active),students});
}catch(e){next(e)}});

rolloverRouter.post('/apply',async(req,res,next)=>{
  const parsed=decisions.safeParse(req.body);
  if(!parsed.success){res.status(400).json({error:'INVALID_ROLLOVER_PLAN'});return}
  const plan=parsed.data;
  const conn=await db.getConnection();
  try{
    await conn.beginTransaction();
    await conn.query("SELECT id FROM roles WHERE code='SUPER_ADMIN' FOR UPDATE");
    const[years]:any=await conn.query('SELECT id,name,is_active,starts_on FROM academic_years FOR UPDATE');
    const source=years.filter((x:any)=>x.is_active);
    const target=years.find((x:any)=>Number(x.id)===plan.targetYearId);
    if(source.length!==1||!target||target.is_active||new Date(target.starts_on)<=new Date(source[0].starts_on))throw Object.assign(new Error('INVALID_ROLLOVER_YEARS'),{status:409});
    const[enrollments]:any=await conn.query(`SELECT se.student_id,se.class_id,c.level,s.status student_status FROM student_enrollments se JOIN classes c ON c.id=se.class_id JOIN students s ON s.id=se.student_id WHERE se.academic_year_id=? AND se.status='ACTIVE' AND s.status='ACTIVE' FOR UPDATE`,[source[0].id]);
    const[existing]:any=await conn.query('SELECT id FROM student_enrollments WHERE academic_year_id=? LIMIT 1 FOR UPDATE',[target.id]);
    if(existing.length)throw Object.assign(new Error('TARGET_YEAR_HAS_ENROLLMENTS'),{status:409});
    const byStudent=new Map(plan.students.map(x=>[x.studentId,x]));
    if(byStudent.size!==plan.students.length||byStudent.size!==enrollments.length||enrollments.some((x:any)=>!byStudent.has(Number(x.student_id))))throw Object.assign(new Error('PLAN_MUST_COVER_ALL_ACTIVE_STUDENTS'),{status:409});
    const[classes]:any=await conn.query('SELECT id,level,active FROM classes FOR UPDATE');
    const classMap=new Map(classes.map((x:any)=>[Number(x.id),x]));
    for(const row of enrollments){
      const item=byStudent.get(Number(row.student_id))!;
      if(item.outcome==='GRADUATE'||item.outcome==='WITHDRAW'){
        if(item.targetClassId!==null)throw Object.assign(new Error('CLOSED_STUDENT_CANNOT_HAVE_TARGET_CLASS'),{status:409});
      }else{
        const dest:any=classMap.get(item.targetClassId!);
        const expected=Number(row.level)+(item.outcome==='PROMOTE'?1:0);
        if(!dest||!dest.active||Number(dest.level)!==expected||expected>6)throw Object.assign(new Error('INVALID_TARGET_CLASS'),{status:409});
      }
    }
    for(const row of enrollments){
      const item=byStudent.get(Number(row.student_id))!;
      const priorStatus={PROMOTE:'PROMOTED',REPEAT:'REPEATED',GRADUATE:'GRADUATED',WITHDRAW:'WITHDRAWN'}[item.outcome];
      await conn.execute('UPDATE student_enrollments SET status=?,ended_on=DATE_SUB(?,INTERVAL 1 DAY) WHERE student_id=? AND academic_year_id=?',[priorStatus,target.starts_on,row.student_id,source[0].id]);
      if(item.targetClassId){await conn.execute("INSERT INTO student_enrollments(student_id,academic_year_id,class_id,status,started_on) VALUES(?,?,?,'ACTIVE',?)",[row.student_id,target.id,item.targetClassId,target.starts_on]);}
      else await conn.execute('UPDATE students SET status=? WHERE id=?',[item.outcome==='GRADUATE'?'GRADUATED':'BOYONG',row.student_id]);
    }
    await conn.execute('UPDATE academic_years SET is_active=0 WHERE id=?',[source[0].id]);
    await conn.execute('UPDATE academic_years SET is_active=1 WHERE id=?',[target.id]);
    await writeAudit(req,{action:'ACADEMIC_YEAR.ROLLED_OVER',entityType:'academic_year',entityId:target.id,metadata:{sourceYearId:source[0].id,targetYearId:target.id,decisions:plan.students}},conn);
    await conn.commit();res.status(200).json({moved:enrollments.length,activeYear:target.name});
  }catch(e:any){await conn.rollback();if(e.status){res.status(e.status).json({error:e.message});return}next(e)}finally{conn.release()}
});
