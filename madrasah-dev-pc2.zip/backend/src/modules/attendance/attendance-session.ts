// Pure validation helpers for attendance-per-session.
// Kept free of DB/HTTP so ownership and mismatch rules can be unit tested and
// reused by both the single-write and bulk endpoints.
export type ScheduleContext = {
  schedule_id: number;
  schedule_active: boolean;
  assignment_active: boolean;
  teacher_id: number;
  class_id: number;
  academic_year_id: number;
  semester: 'GANJIL'|'GENAP';
};

export function scheduleActiveError(schedule: ScheduleContext|null):string|null{
  if(!schedule||!schedule.schedule_active||!schedule.assignment_active)return 'INVALID_SCHEDULE';
  return null;
}

// A teacher may only write to a schedule whose teaching assignment belongs to them.
export function scheduleOwnershipError(schedule: ScheduleContext,role:string,teacherId:number|undefined):string|null{
  if(role!=='GURU')return null;
  if(!teacherId||schedule.teacher_id!==teacherId)return 'OUTSIDE_TEACHER_SCOPE';
  return null;
}

export function scheduleClassError(schedule: ScheduleContext,classId:number):string|null{
  return schedule.class_id===classId?null:'SCHEDULE_CLASS_MISMATCH';
}

export function semesterPeriodError(term:{starts_on:string;ends_on:string}|null,date:string):string|null{
  if(!term)return null;
  const start=String(term.starts_on).slice(0,10),end=String(term.ends_on).slice(0,10);
  return date<start||date>end?'SEMESTER_PERIOD_MISMATCH':null;
}
