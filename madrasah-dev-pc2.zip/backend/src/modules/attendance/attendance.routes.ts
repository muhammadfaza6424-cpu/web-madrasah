import{writeAudit}from'../audit/audit.service.js';
import{Router}from'express';
import{z}from'zod';
import{db}from'../../config/db.js';
import{requireAuthentication}from'../../middleware/authentication.js';
import{requirePermission,requireRole}from'../../middleware/authorization.js';
import{dailyStatusCaseSql}from'./attendance-priority.js';
import{scheduleActiveError,scheduleOwnershipError,scheduleClassError,semesterPeriodError,type ScheduleContext}from'./attendance-session.js';

export const attendanceRouter=Router();
attendanceRouter.use(requireAuthentication);

const period=z.object({from:z.string().date(),to:z.string().date()}).refine(v=>v.to>=v.from);
const optionalScheduleId=z.coerce.number().int().positive().optional();

// Daily recap groups per attendance_date and applies status priority A > I > S > H.
// This guarantees H + S + I + A === recorded_days for labeled "hari" recaps.
const DAILY_RECAP=`SELECT SUM(day_status='H') H,SUM(day_status='S') S,SUM(day_status='I') I,SUM(day_status='A') A,COUNT(*) recorded_days FROM (SELECT attendance_date,${dailyStatusCaseSql()} day_status FROM attendance WHERE student_id=? AND attendance_date BETWEEN ? AND ? GROUP BY attendance_date) d`;

// A schedule is only usable when active and its teaching assignment is active.
async function loadSchedule(executor:any,scheduleId:number,lock=false):Promise<ScheduleContext|null>{
  const[rows]:any=await executor.query(`SELECT sc.id schedule_id,sc.active schedule_active,ta.id assignment_id,ta.teacher_id,ta.class_id,ta.subject_id,ta.academic_year_id,ta.semester,ta.active assignment_active FROM schedules sc JOIN teaching_assignments ta ON ta.id=sc.teaching_assignment_id WHERE sc.id=? LIMIT 1${lock?' FOR UPDATE':''}`,[scheduleId]);
  return rows[0]??null;
}

// Shared guard for endpoints that accept a scheduleId.
function scheduleGuard(schedule:ScheduleContext|null,role:string,teacherId:number|undefined):string|null{
  const active=scheduleActiveError(schedule);
  if(active)return active;
  return scheduleOwnershipError(schedule as ScheduleContext,role,teacherId);
}

// Validates the request date against the semester period when academic_terms is configured.
async function semesterDateError(executor:any,academicYearId:number,semester:string,date:string):Promise<string|null>{
  const[t]:any=await executor.query(`SELECT starts_on,ends_on FROM academic_terms WHERE academic_year_id=? AND semester=? LIMIT 1`,[academicYearId,semester]);
  return semesterPeriodError(t[0]??null,date);
}

async function attendanceLocked(executor:any,academicYearId:number,date:string):Promise<boolean>{
  const[l]:any=await executor.query(`SELECT 1 FROM calendar_events WHERE locks_attendance=1 AND (academic_year_id IS NULL OR academic_year_id=?) AND ? BETWEEN starts_on AND ends_on LIMIT 1`,[academicYearId,date]);
  return Boolean(l[0]);
}

attendanceRouter.get('/student/me',requireRole('SANTRI'),async(req,res,next)=>{
  try{
    if(!req.auth!.studentId){res.status(403).json({error:'STUDENT_PROFILE_REQUIRED'});return}
    const p=period.safeParse(req.query);
    if(!p.success){res.status(400).json({error:'INVALID_PERIOD'});return}
    const[rows]=await db.query(`SELECT a.attendance_date,a.status,a.schedule_id,c.code AS class_code,a.source FROM attendance a JOIN classes c ON c.id=a.class_id WHERE a.student_id=? AND a.attendance_date BETWEEN ? AND ? ORDER BY a.attendance_date,a.schedule_id`,[req.auth!.studentId,p.data.from,p.data.to]);
    const[r]:any=await db.query(DAILY_RECAP,[req.auth!.studentId,p.data.from,p.data.to]);
    const[sessions]:any=await db.query(`SELECT schedule_id,status,COUNT(*) sessions FROM attendance WHERE student_id=? AND attendance_date BETWEEN ? AND ? GROUP BY schedule_id,status ORDER BY schedule_id`,[req.auth!.studentId,p.data.from,p.data.to]);
    res.json({attendance:rows,recap:r[0],sessionRecap:sessions});
  }catch(e){next(e)}
});

attendanceRouter.get('/class/:classId',requireRole('SUPER_ADMIN','ADMIN','GURU'),requirePermission('attendance.manage'),async(req,res,next)=>{
  try{
    const classId=Number(req.params.classId),p=period.safeParse(req.query),sid=optionalScheduleId.safeParse(req.query.scheduleId);
    if(!Number.isSafeInteger(classId)||classId<=0||!p.success||!sid.success){res.status(400).json({error:'INVALID_QUERY'});return}
    let yearId:number,scheduleId:number|null=sid.data??null;
    if(scheduleId!==null){
      const sc=await loadSchedule(db,scheduleId);
      const guard=scheduleGuard(sc,req.auth!.role,req.auth!.teacherId);
      if(guard){res.status(guard==='OUTSIDE_TEACHER_SCOPE'?403:400).json({error:guard});return}
      const classErr=scheduleClassError(sc as ScheduleContext,classId);
      if(classErr){res.status(400).json({error:classErr});return}
      yearId=(sc as ScheduleContext).academic_year_id;
    }else{
      const[y]:any=await db.query(`SELECT id FROM academic_years WHERE ?<=ends_on AND ?>=starts_on ORDER BY is_active DESC,starts_on DESC LIMIT 1`,[p.data.from,p.data.to]);
      if(!y[0]){res.status(400).json({error:'PERIOD_OUTSIDE_ACADEMIC_YEAR'});return}
      yearId=y[0].id;
      if(req.auth!.role==='GURU'){
        if(!req.auth!.teacherId){res.status(403).json({error:'TEACHER_PROFILE_REQUIRED'});return}
        const[s]:any=await db.query(`SELECT 1 WHERE EXISTS(SELECT 1 FROM teaching_assignments WHERE teacher_id=? AND class_id=? AND academic_year_id=? AND active=1) OR EXISTS(SELECT 1 FROM homeroom_assignments WHERE teacher_id=? AND class_id=? AND academic_year_id=? AND active=1)`,[req.auth!.teacherId,classId,yearId,req.auth!.teacherId,classId,yearId]);
        if(!s[0]){res.status(403).json({error:'OUTSIDE_TEACHER_SCOPE'});return}
      }
    }
    // When no schedule is selected, only legacy/daily rows (schedule_id IS NULL) are returned.
    const scheduleFilter=scheduleId===null?'a.schedule_id IS NULL':'a.schedule_id=?';
    const params:any[]=scheduleId===null?[p.data.from,p.data.to,classId,yearId]:[p.data.from,p.data.to,scheduleId,classId,yearId];
    const[rows]=await db.query(`SELECT s.id student_id,s.nis,s.name,a.attendance_date,a.status,a.schedule_id,a.source FROM student_enrollments se JOIN students s ON s.id=se.student_id LEFT JOIN attendance a ON a.student_id=s.id AND a.academic_year_id=se.academic_year_id AND a.attendance_date BETWEEN ? AND ? AND ${scheduleFilter} WHERE se.class_id=? AND se.academic_year_id=? AND se.status IN('ACTIVE','PROMOTED','GRADUATED') ORDER BY s.name,a.attendance_date`,params);
    res.json({attendance:rows,scheduleId});
  }catch(e){next(e)}
});

const write=z.object({studentId:z.number().int().positive(),attendanceDate:z.string().date(),status:z.enum(['H','S','I','A']),scheduleId:z.number().int().positive().nullable().optional()});

attendanceRouter.put('/',requireRole('SUPER_ADMIN','ADMIN','GURU'),requirePermission('attendance.manage'),async(req,res,next)=>{
  const conn=await db.getConnection();
  try{
    await conn.beginTransaction();
    await conn.query("SELECT id FROM roles WHERE code='SUPER_ADMIN' FOR UPDATE");
    const x=write.safeParse(req.body);
    if(!x.success){res.status(400).json({error:'INVALID_ATTENDANCE'});return}
    const p=x.data,scheduleId=p.scheduleId??null;
    let classId:number,academicYearId:number;
    if(scheduleId!==null){
      const sc=await loadSchedule(conn,scheduleId,true);
      const guard=scheduleGuard(sc,req.auth!.role,req.auth!.teacherId);
      if(guard){res.status(guard==='OUTSIDE_TEACHER_SCOPE'?403:400).json({error:guard});return}
      const s=sc as ScheduleContext;
      const semErr=await semesterDateError(conn,s.academic_year_id,s.semester,p.attendanceDate);
      if(semErr){res.status(400).json({error:semErr});return}
      const[en]:any=await conn.query(`SELECT se.class_id,se.academic_year_id FROM student_enrollments se WHERE se.student_id=? AND se.academic_year_id=? AND se.class_id=? AND se.status IN('ACTIVE','PROMOTED','GRADUATED') LIMIT 1 FOR UPDATE`,[p.studentId,s.academic_year_id,s.class_id]);
      if(!en[0]){res.status(400).json({error:'STUDENT_NOT_IN_SCHEDULE_CLASS'});return}
      classId=s.class_id;academicYearId=s.academic_year_id;
    }else{
      const[en]:any=await conn.query(`SELECT se.class_id,se.academic_year_id FROM student_enrollments se JOIN academic_years ay ON ay.id=se.academic_year_id WHERE se.student_id=? AND ? BETWEEN ay.starts_on AND ay.ends_on AND se.status IN('ACTIVE','PROMOTED','GRADUATED') LIMIT 1 FOR UPDATE`,[p.studentId,p.attendanceDate]);
      if(!en[0]){res.status(400).json({error:'NO_ENROLLMENT_FOR_DATE'});return}
      classId=en[0].class_id;academicYearId=en[0].academic_year_id;
      if(req.auth!.role==='GURU'){
        if(!req.auth!.teacherId){res.status(403).json({error:'TEACHER_PROFILE_REQUIRED'});return}
        const[s]:any=await conn.query(`SELECT 1 WHERE EXISTS(SELECT 1 FROM teaching_assignments WHERE teacher_id=? AND class_id=? AND academic_year_id=? AND active=1) OR EXISTS(SELECT 1 FROM homeroom_assignments WHERE teacher_id=? AND class_id=? AND academic_year_id=? AND active=1)`,[req.auth!.teacherId,classId,academicYearId,req.auth!.teacherId,classId,academicYearId]);
        if(!s[0]){res.status(403).json({error:'OUTSIDE_TEACHER_SCOPE'});return}
      }
    }
    if(await attendanceLocked(conn,academicYearId,p.attendanceDate)){res.status(409).json({error:'ATTENDANCE_LOCKED'});return}
    await conn.execute(`INSERT INTO attendance(student_id,class_id,academic_year_id,attendance_date,status,source,schedule_id,recorded_by) VALUES(?,?,?,?,?,'MANUAL',?,?) ON DUPLICATE KEY UPDATE class_id=VALUES(class_id),academic_year_id=VALUES(academic_year_id),status=VALUES(status),source='MANUAL',recorded_by=VALUES(recorded_by)`,[p.studentId,classId,academicYearId,p.attendanceDate,p.status,scheduleId,req.auth!.userId]);
    await writeAudit(req,{action:'ATTENDANCE.UPDATED',entityType:'attendance',metadata:{changes:req.body}},conn);
    await conn.commit();
    res.status(204).end();
  }catch(e){await conn.rollback();next(e)}finally{conn.release()}
});

const bulkEntry=z.object({studentId:z.number().int().positive(),status:z.enum(['H','S','I','A'])});
const bulk=z.object({classId:z.number().int().positive(),attendanceDate:z.string().date(),scheduleId:z.number().int().positive(),entries:z.array(bulkEntry).min(1).max(500)});

attendanceRouter.put('/bulk',requireRole('SUPER_ADMIN','ADMIN','GURU'),requirePermission('attendance.manage'),async(req,res,next)=>{
  const conn=await db.getConnection();
  try{
    await conn.beginTransaction();
    await conn.query("SELECT id FROM roles WHERE code='SUPER_ADMIN' FOR UPDATE");
    const x=bulk.safeParse(req.body);
    if(!x.success){res.status(400).json({error:'INVALID_ATTENDANCE_BULK'});return}
    const p=x.data;
    const ids=p.entries.map(e=>e.studentId);
    if(new Set(ids).size!==ids.length){res.status(400).json({error:'DUPLICATE_STUDENT_ENTRY'});return}
    const sc=await loadSchedule(conn,p.scheduleId,true);
    const guard=scheduleGuard(sc,req.auth!.role,req.auth!.teacherId);
    if(guard){res.status(guard==='OUTSIDE_TEACHER_SCOPE'?403:400).json({error:guard});return}
    const s=sc as ScheduleContext;
    const classErr=scheduleClassError(s,p.classId);
    if(classErr){res.status(400).json({error:classErr});return}
    const semErr=await semesterDateError(conn,s.academic_year_id,s.semester,p.attendanceDate);
    if(semErr){res.status(400).json({error:semErr});return}
    const[enrolled]:any=await conn.query(`SELECT student_id FROM student_enrollments WHERE academic_year_id=? AND class_id=? AND status IN('ACTIVE','PROMOTED','GRADUATED') AND student_id IN (?)`,[s.academic_year_id,s.class_id,ids]);
    const enrolledSet=new Set(enrolled.map((r:any)=>r.student_id));
    if(ids.some(id=>!enrolledSet.has(id))){res.status(400).json({error:'STUDENT_NOT_IN_SCHEDULE_CLASS'});return}
    if(await attendanceLocked(conn,s.academic_year_id,p.attendanceDate)){res.status(409).json({error:'ATTENDANCE_LOCKED'});return}
    for(const entry of p.entries){
      await conn.execute(`INSERT INTO attendance(student_id,class_id,academic_year_id,attendance_date,status,source,schedule_id,recorded_by) VALUES(?,?,?,?,?,'MANUAL',?,?) ON DUPLICATE KEY UPDATE class_id=VALUES(class_id),academic_year_id=VALUES(academic_year_id),status=VALUES(status),source='MANUAL',recorded_by=VALUES(recorded_by)`,[entry.studentId,s.class_id,s.academic_year_id,p.attendanceDate,entry.status,p.scheduleId,req.auth!.userId]);
    }
    await writeAudit(req,{action:'ATTENDANCE.BULK_UPDATED',entityType:'attendance',entityId:p.scheduleId,metadata:{classId:p.classId,attendanceDate:p.attendanceDate,scheduleId:p.scheduleId,count:p.entries.length,entries:p.entries}},conn);
    await conn.commit();
    res.status(204).end();
  }catch(e){await conn.rollback();next(e)}finally{conn.release()}
});
