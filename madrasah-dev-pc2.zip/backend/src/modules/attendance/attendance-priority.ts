// Single source of truth for daily (per-date) attendance status derivation.
// Product rule: when several sessions exist on the same date, the day status is
// the highest priority present, ordered A > I > S > H.
export const DAILY_STATUS_PRIORITY = ['A','I','S','H'] as const;
export type AttendanceStatus = 'H'|'S'|'I'|'A';

// Builds a SQL CASE that collapses rows grouped by attendance_date into one
// daily status using the priority above. Kept here so the recap SQL and the
// TypeScript helper can never drift apart.
export function dailyStatusCaseSql(column='status'):string{
  const branches=DAILY_STATUS_PRIORITY.slice(0,-1).map(s=>`WHEN MAX(${column}='${s}')=1 THEN '${s}'`).join(' ');
  return `CASE ${branches} ELSE 'H' END`;
}

// Pure derivation used for verification/tests and any future consumer.
export function dailyStatus(statuses:readonly string[]):AttendanceStatus{
  for(const candidate of DAILY_STATUS_PRIORITY){
    if(statuses.includes(candidate))return candidate;
  }
  return 'H';
}

// Groups raw attendance rows by date and returns the daily recap where
// H + S + I + A === recorded_days.
export function dailyRecap(rows:readonly {attendance_date:string;status:string}[]):{H:number;S:number;I:number;A:number;recorded_days:number}{
  const byDate=new Map<string,string[]>();
  for(const row of rows){
    const list=byDate.get(row.attendance_date)??[];
    list.push(row.status);
    byDate.set(row.attendance_date,list);
  }
  const recap={H:0,S:0,I:0,A:0,recorded_days:byDate.size};
  for(const statuses of byDate.values())recap[dailyStatus(statuses)]++;
  return recap;
}
