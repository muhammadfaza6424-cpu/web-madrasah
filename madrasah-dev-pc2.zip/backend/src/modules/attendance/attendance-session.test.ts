import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { scheduleActiveError, scheduleOwnershipError, scheduleClassError, semesterPeriodError, type ScheduleContext } from './attendance-session.js';

const schedule: ScheduleContext = { schedule_id: 10, schedule_active: true, assignment_active: true, teacher_id: 7, class_id: 3, academic_year_id: 2, semester: 'GANJIL' };

describe('attendance session validation (teacher ownership)', () => {
  it('accepts an active schedule with an active assignment', () => {
    assert.equal(scheduleActiveError(schedule), null);
  });

  it('rejects missing, inactive schedule, or inactive assignment', () => {
    assert.equal(scheduleActiveError(null), 'INVALID_SCHEDULE');
    assert.equal(scheduleActiveError({ ...schedule, schedule_active: false }), 'INVALID_SCHEDULE');
    assert.equal(scheduleActiveError({ ...schedule, assignment_active: false }), 'INVALID_SCHEDULE');
  });

  it('teacher may only use their own schedule', () => {
    assert.equal(scheduleOwnershipError(schedule, 'GURU', 7), null);
  });

  it('teacher is rejected when using another teacher schedule', () => {
    assert.equal(scheduleOwnershipError(schedule, 'GURU', 8), 'OUTSIDE_TEACHER_SCOPE');
    assert.equal(scheduleOwnershipError(schedule, 'GURU', undefined), 'OUTSIDE_TEACHER_SCOPE');
  });

  it('admin and super admin may correct any schedule', () => {
    assert.equal(scheduleOwnershipError(schedule, 'ADMIN', 999), null);
    assert.equal(scheduleOwnershipError(schedule, 'SUPER_ADMIN', undefined), null);
  });

  it('rejects class mismatch and accepts matching class', () => {
    assert.equal(scheduleClassError(schedule, 3), null);
    assert.equal(scheduleClassError(schedule, 4), 'SCHEDULE_CLASS_MISMATCH');
  });

  it('enforces the semester period when configured, allows when not configured', () => {
    const term = { starts_on: '2026-01-01', ends_on: '2026-06-30' };
    assert.equal(semesterPeriodError(term, '2026-03-15'), null);
    assert.equal(semesterPeriodError(term, '2026-07-01'), 'SEMESTER_PERIOD_MISMATCH');
    assert.equal(semesterPeriodError(null, '2026-07-01'), null);
  });
});

describe('migration 039 definition (static)', () => {
  it('adds schedule_id, generated schedule_key, FK, and the new unique index without backfill', async () => {
    const sql = await readFile(fileURLToPath(new URL('../../../../database/migrations/039_attendance_schedule_session.sql', import.meta.url)), 'utf8');
    assert.match(sql, /ADD COLUMN schedule_id BIGINT UNSIGNED NULL/);
    assert.match(sql, /schedule_key BIGINT UNSIGNED GENERATED ALWAYS AS \(COALESCE\(schedule_id, 0\)\) STORED/);
    assert.match(sql, /FOREIGN KEY \(schedule_id\) REFERENCES schedules\(id\)/);
    assert.match(sql, /DROP INDEX uq_attendance_student_date/);
    assert.match(sql, /UNIQUE KEY uq_attendance_student_date_schedule \(student_id, attendance_date, schedule_key\)/);
    assert.match(sql, /INDEX idx_attendance_schedule_date \(schedule_id, attendance_date\)/);
    assert.doesNotMatch(sql, /UPDATE\s+attendance/i, 'must not backfill historical data');
  });
});

describe('excel import stays daily (schedule_id = NULL)', () => {
  it('import apply inserts without schedule_id and only inspects daily rows for conflicts', async () => {
    const source = await readFile(fileURLToPath(new URL('../imports/attendance-import.routes.ts', import.meta.url)), 'utf8');
    assert.match(source, /attendance WHERE student_id=\? AND attendance_date=\? AND schedule_id IS NULL FOR UPDATE/);
    assert.match(source, /INSERT INTO attendance\(student_id,class_id,academic_year_id,attendance_date,status,source,import_row_id,recorded_by\)/);
    assert.doesNotMatch(source, /INSERT INTO attendance\([^)]*schedule_id/);
  });
});

describe('legacy daily compatibility', () => {
  it('class listing defaults to schedule_id IS NULL and supports an optional scheduleId', async () => {
    const source = await readFile(fileURLToPath(new URL('./attendance.routes.ts', import.meta.url)), 'utf8');
    assert.match(source, /a\.schedule_id IS NULL/);
    assert.match(source, /optionalScheduleId/);
    assert.match(source, /put\('\/bulk'/);
  });

  it('report snapshot uses the daily priority recap and bumps version to 9', async () => {
    const source = await readFile(fileURLToPath(new URL('../reports/report.routes.ts', import.meta.url)), 'utf8');
    assert.match(source, /GROUP BY attendance_date/);
    assert.match(source, /version:9/);
  });
});
