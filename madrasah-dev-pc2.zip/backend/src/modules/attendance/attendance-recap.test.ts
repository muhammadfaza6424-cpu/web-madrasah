import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { DAILY_STATUS_PRIORITY, dailyStatus, dailyStatusCaseSql, dailyRecap } from './attendance-priority.js';

type Row = { attendance_date: string; status: string; schedule_id?: number | null };

describe('daily attendance priority A > I > S > H', () => {
  it('exposes the agreed priority order', () => {
    assert.deepEqual([...DAILY_STATUS_PRIORITY], ['A', 'I', 'S', 'H']);
  });

  it('3 sessions H on the same date = 1 day H', () => {
    const recap = dailyRecap([{ attendance_date: '2026-01-05', status: 'H' }, { attendance_date: '2026-01-05', status: 'H' }, { attendance_date: '2026-01-05', status: 'H' }]);
    assert.deepEqual(recap, { H: 1, S: 0, I: 0, A: 0, recorded_days: 1 });
  });

  it('H + H + S = 1 day S', () => {
    const recap = dailyRecap([{ attendance_date: '2026-01-05', status: 'H' }, { attendance_date: '2026-01-05', status: 'H' }, { attendance_date: '2026-01-05', status: 'S' }]);
    assert.deepEqual(recap, { H: 0, S: 1, I: 0, A: 0, recorded_days: 1 });
  });

  it('H + I + S = 1 day I', () => {
    const recap = dailyRecap([{ attendance_date: '2026-01-05', status: 'H' }, { attendance_date: '2026-01-05', status: 'I' }, { attendance_date: '2026-01-05', status: 'S' }]);
    assert.deepEqual(recap, { H: 0, S: 0, I: 1, A: 0, recorded_days: 1 });
  });

  it('H + S + A = 1 day A', () => {
    const recap = dailyRecap([{ attendance_date: '2026-01-05', status: 'H' }, { attendance_date: '2026-01-05', status: 'S' }, { attendance_date: '2026-01-05', status: 'A' }]);
    assert.deepEqual(recap, { H: 0, S: 0, I: 0, A: 1, recorded_days: 1 });
  });

  it('H + H + S must NOT produce H=2, S=1 on the daily recap', () => {
    const recap = dailyRecap([{ attendance_date: '2026-01-05', status: 'H' }, { attendance_date: '2026-01-05', status: 'H' }, { attendance_date: '2026-01-05', status: 'S' }]);
    assert.notDeepEqual(recap, { H: 2, S: 1, I: 0, A: 0, recorded_days: 3 });
    assert.equal(recap.H, 0);
    assert.equal(recap.S, 1);
  });

  it('H + H + S has recorded_days = 1', () => {
    const recap = dailyRecap([{ attendance_date: '2026-01-05', status: 'H' }, { attendance_date: '2026-01-05', status: 'H' }, { attendance_date: '2026-01-05', status: 'S' }]);
    assert.equal(recap.recorded_days, 1);
  });

  it('keeps H + S + I + A equal to recorded_days across many dates', () => {
    const rows: Row[] = [
      { attendance_date: '2026-01-05', status: 'H' }, { attendance_date: '2026-01-05', status: 'A' },
      { attendance_date: '2026-01-06', status: 'H' }, { attendance_date: '2026-01-06', status: 'H' }, { attendance_date: '2026-01-06', status: 'S' },
      { attendance_date: '2026-01-07', status: 'I' }, { attendance_date: '2026-01-07', status: 'S' },
      { attendance_date: '2026-01-08', status: 'H' },
      { attendance_date: '2026-01-09', status: 'S' }, { attendance_date: '2026-01-09', status: 'S' },
    ];
    const recap = dailyRecap(rows);
    assert.equal(recap.H + recap.S + recap.I + recap.A, recap.recorded_days);
    assert.equal(recap.recorded_days, 5);
  });

  it('derives the daily status directly', () => {
    assert.equal(dailyStatus(['H', 'H', 'S']), 'S');
    assert.equal(dailyStatus(['S', 'I']), 'I');
    assert.equal(dailyStatus(['I', 'A']), 'A');
    assert.equal(dailyStatus(['H']), 'H');
  });

  it('generated SQL CASE encodes the same priority order', () => {
    assert.equal(
      dailyStatusCaseSql(),
      "CASE WHEN MAX(status='A')=1 THEN 'A' WHEN MAX(status='I')=1 THEN 'I' WHEN MAX(status='S')=1 THEN 'S' ELSE 'H' END",
    );
  });
});
