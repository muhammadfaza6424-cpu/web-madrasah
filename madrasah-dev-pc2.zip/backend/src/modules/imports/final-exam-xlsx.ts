import ExcelJS from 'exceljs';
import { headerKey, textCell } from './xlsx-cell-helpers.js';

export const FINAL_EXAM_SUBJECT_CODES = [
  'TASAWWUF',
  'FIQIH',
  'TAUHID',
  'ASWAJA',
  'BACA_KITAB',
  'BACA_AL_QURAN',
  'MUHAFADLOH',
] as const;
export type FinalExamSubjectCode = typeof FINAL_EXAM_SUBJECT_CODES[number];

export type FinalExamSourceRow = {
  sourceRowNumber: number;
  sourceNis: string;
  sourceName: string | null;
  sourceClass: string | null;
  subjectCode: FinalExamSubjectCode;
  score: number;
};

const REQUIRED_HEADERS = ['nis', 'nama', 'kelas', 'kodemapel', 'nilai'];
const VALID_SUBJECT_CODES = new Set<string>(FINAL_EXAM_SUBJECT_CODES);

function fail(code: string): never {
  throw Object.assign(new Error(code), { status: 400, code });
}

function scoreValue(value: ExcelJS.CellValue): number | null {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value === 'string' && /^\d+(?:\.\d{1,2})?$/.test(value.trim())) return Number(value.trim());
  return null;
}

export async function parseFinalExamWorkbook(bytes: Buffer): Promise<FinalExamSourceRow[]> {
  let workbook: ExcelJS.Workbook;
  try {
    workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(bytes as never);
  } catch {
    return fail('INVALID_FINAL_EXAM_XLSX');
  }
  if (workbook.worksheets.length !== 1) return fail('FINAL_EXAM_WORKBOOK_MUST_HAVE_ONE_SHEET');
  const worksheet = workbook.worksheets[0];
  if (!worksheet || worksheet.rowCount < 1) return fail('FINAL_EXAM_HEADER_INVALID');

  const headerRow = worksheet.getRow(1);
  const headers = Array.from({ length: headerRow.cellCount }, (_, index) => headerKey(headerRow.getCell(index + 1).value));
  if (headers.length !== REQUIRED_HEADERS.length ||
      new Set(headers).size !== REQUIRED_HEADERS.length ||
      REQUIRED_HEADERS.some(header => !headers.includes(header))) {
    return fail('FINAL_EXAM_HEADER_INVALID');
  }
  const columnByHeader = new Map(headers.map((header, index) => [header, index + 1]));
  const rows: FinalExamSourceRow[] = [];
  const seenTargets = new Set<string>();

  for (let rowNumber = 2; rowNumber <= worksheet.rowCount; rowNumber++) {
    const row = worksheet.getRow(rowNumber);
    const cells = Object.fromEntries(
      REQUIRED_HEADERS.map(header => [header, row.getCell(columnByHeader.get(header)!).value]),
    );
    if (Object.values(cells).every(value => value == null || value === '')) continue;

    const nisCell = row.getCell(columnByHeader.get('nis')!);
    const sourceNis = typeof nisCell.value === 'string' ? textCell(nisCell) : null;
    const sourceName = textCell(row.getCell(columnByHeader.get('nama')!));
    const sourceClass = textCell(row.getCell(columnByHeader.get('kelas')!));
    const subjectCode = textCell(row.getCell(columnByHeader.get('kodemapel')!));
    const score = scoreValue(row.getCell(columnByHeader.get('nilai')!).value);
    if (!sourceNis || sourceNis.length > 100 ||
        (sourceName && sourceName.length > 255) ||
        (sourceClass && sourceClass.length > 50) ||
        !subjectCode || !VALID_SUBJECT_CODES.has(subjectCode) ||
        score === null || score < 0 || score > 100 ||
        seenTargets.has(`${sourceNis}:${subjectCode}`)) {
      return fail('FINAL_EXAM_ROW_INVALID');
    }
    seenTargets.add(`${sourceNis}:${subjectCode}`);
    rows.push({
      sourceRowNumber: rowNumber,
      sourceNis,
      sourceName,
      sourceClass,
      subjectCode: subjectCode as FinalExamSubjectCode,
      score,
    });
  }
  if (!rows.length) return fail('FINAL_EXAM_HAS_NO_DATA_ROWS');
  return rows;
}

export async function createFinalExamTemplate(): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Ujian Akhir');
  worksheet.columns = [
    { header: 'NIS', key: 'nis', width: 20 },
    { header: 'Nama', key: 'nama', width: 32 },
    { header: 'Kelas', key: 'kelas', width: 16 },
    { header: 'Kode_Mapel', key: 'subjectCode', width: 24 },
    { header: 'Nilai', key: 'score', width: 14 },
  ];
  worksheet.views = [{ state: 'frozen', ySplit: 1 }];
  worksheet.autoFilter = { from: 'A1', to: 'E1' };
  worksheet.getRow(1).font = { bold: true };
  worksheet.getColumn(1).numFmt = '@';
  worksheet.getColumn(4).numFmt = '@';
  for (let rowNumber = 2; rowNumber <= 501; rowNumber++) {
    worksheet.getCell(`E${rowNumber}`).dataValidation = {
      type: 'decimal',
      operator: 'between',
      allowBlank: false,
      formulae: [0, 100],
    };
  }
  return Buffer.from(await workbook.xlsx.writeBuffer());
}
