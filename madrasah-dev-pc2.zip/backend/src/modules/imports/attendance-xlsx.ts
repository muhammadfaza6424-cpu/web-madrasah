import ExcelJS from 'exceljs';
import { headerKey, textCell } from './xlsx-cell-helpers.js';

export type AttendanceSourceRow = {
  sourceRowNumber: number;
  sourceNis: string | null;
  sourceName: string | null;
  sourceClass: string | null;
  attendanceDate: string;
  attendanceStatus: 'H' | 'S' | 'I' | 'A';
};

const REQUIRED_HEADERS = ['nis', 'nama', 'kelas', 'tanggal', 'status'];
const VALID_STATUSES = new Set(['H', 'S', 'I', 'A']);

function fail(code: string): never {
  throw Object.assign(new Error(code), { status: 400, code });
}

function dateString(year: number, month: number, day: number): string | null {
  const date = new Date(Date.UTC(year, month - 1, day));
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) return null;
  return `${String(year).padStart(4, '0')}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

function attendanceDate(value: unknown): string | null {
  if (value instanceof Date) {
    if (!Number.isFinite(value.getTime()) || value.getHours() !== 0 || value.getMinutes() !== 0 || value.getSeconds() !== 0 || value.getMilliseconds() !== 0) return null;
    return dateString(value.getFullYear(), value.getMonth() + 1, value.getDate());
  }
  if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)) {
    const [year, month, day] = value.split('-').map(Number);
    return dateString(year!, month!, day!);
  }
  return null;
}

export async function parseAttendanceWorkbook(bytes: Buffer): Promise<AttendanceSourceRow[]> {
  let workbook: ExcelJS.Workbook;
  try {
    workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(bytes as never);
  } catch {
    return fail('INVALID_ATTENDANCE_XLSX');
  }
  if (workbook.worksheets.length !== 1) return fail('ATTENDANCE_WORKBOOK_MUST_HAVE_ONE_SHEET');
  const worksheet = workbook.worksheets[0];
  if (!worksheet || worksheet.rowCount < 1) return fail('ATTENDANCE_HEADER_INVALID');

  const headerRow = worksheet.getRow(1);
  const headerCount = headerRow.cellCount;
  const headers = Array.from({ length: headerCount }, (_, index) => headerKey(headerRow.getCell(index + 1).value));
  if (headers.length !== REQUIRED_HEADERS.length || new Set(headers).size !== REQUIRED_HEADERS.length || REQUIRED_HEADERS.some((header) => !headers.includes(header))) {
    return fail('ATTENDANCE_HEADER_INVALID');
  }
  const columnByHeader = new Map(headers.map((header, index) => [header, index + 1]));
  const sourceRows: AttendanceSourceRow[] = [];

  for (let rowNumber = 2; rowNumber <= worksheet.rowCount; rowNumber++) {
    const row = worksheet.getRow(rowNumber);
    const cells = Object.fromEntries(REQUIRED_HEADERS.map((header) => [header, row.getCell(columnByHeader.get(header)!).value]));
    if (Object.values(cells).every((value) => value == null || value === '')) continue;

    const nisCell = row.getCell(columnByHeader.get('nis')!);
    const sourceNis = typeof nisCell.value === 'string' ? textCell(nisCell) : null;
    const sourceName = textCell(row.getCell(columnByHeader.get('nama')!));
    const sourceClass = textCell(row.getCell(columnByHeader.get('kelas')!));
    const date = attendanceDate(row.getCell(columnByHeader.get('tanggal')!).value);
    const statusText = textCell(row.getCell(columnByHeader.get('status')!))?.toUpperCase() ?? '';
    if (!date || !VALID_STATUSES.has(statusText) || (sourceNis && sourceNis.length > 100) || (sourceName && sourceName.length > 255) || (sourceClass && sourceClass.length > 50)) {
      return fail('ATTENDANCE_ROW_INVALID');
    }

    sourceRows.push({
      sourceRowNumber: rowNumber,
      sourceNis,
      sourceName,
      sourceClass,
      attendanceDate: date,
      attendanceStatus: statusText as AttendanceSourceRow['attendanceStatus'],
    });
  }

  if (!sourceRows.length) return fail('ATTENDANCE_HAS_NO_DATA_ROWS');
  return sourceRows;
}

export async function createAttendanceTemplate(): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Attendance');
  worksheet.columns = [
    { header: 'NIS', key: 'nis', width: 20 },
    { header: 'Nama', key: 'nama', width: 32 },
    { header: 'Kelas', key: 'kelas', width: 16 },
    { header: 'Tanggal', key: 'tanggal', width: 16 },
    { header: 'Status', key: 'status', width: 14 },
  ];
  worksheet.views = [{ state: 'frozen', ySplit: 1 }];
  worksheet.autoFilter = { from: 'A1', to: 'E1' };
  worksheet.getRow(1).font = { bold: true };
  worksheet.getColumn(1).numFmt = '@';
  worksheet.getColumn(4).numFmt = 'yyyy-mm-dd';
  for (let rowNumber = 2; rowNumber <= 501; rowNumber++) {
    worksheet.getCell(`E${rowNumber}`).dataValidation = { type: 'list', allowBlank: false, formulae: ['"H,S,I,A"'] };
  }
  return Buffer.from(await workbook.xlsx.writeBuffer());
}
