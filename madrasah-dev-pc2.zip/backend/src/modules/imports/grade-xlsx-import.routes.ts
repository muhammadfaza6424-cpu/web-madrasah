import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { db } from '../../config/db.js';
import { requireAuthentication } from '../../middleware/authentication.js';
import { requirePermission } from '../../middleware/authorization.js';
import { writeAudit } from '../audit/audit.service.js';
import { digest, validOffice } from '../storage/integrity.js';
import { createGradeTemplate, parseGradeWorkbook, type GradeSourceRow } from './grade-xlsx.js';

export const gradeXlsxImportRouter = Router();
gradeXlsxImportRouter.use(requireAuthentication, requirePermission('grades.import.manage'));

const upload = multer({ storage: multer.memoryStorage(), limits: { files: 1, fileSize: 10 * 1024 * 1024 } });
const id = z.coerce.number().int().positive();
const resolution = z.object({
  studentId: z.number().int().positive().nullable(),
  subjectId: z.number().int().positive().nullable(),
  note: z.string().trim().max(500).nullable().optional(),
}).strict();

function safeFilename(value: unknown): string {
  const original = String(value || 'grades.xlsx').replace(/\\/g, '/');
  return (original.split('/').pop() || 'grades.xlsx').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 255) || 'grades.xlsx';
}

function normalized(value: unknown): string {
  return String(value ?? '').normalize('NFKC').trim().replace(/\s+/g, ' ').toLocaleLowerCase('id-ID');
}

async function matchStudent(executor: any, nis: string): Promise<{ id: number | null; ambiguous: boolean }> {
  const [rows]: any = await executor.query('SELECT id FROM students WHERE nis=? LIMIT 2', [nis]);
  return rows.length === 1
    ? { id: Number(rows[0].id), ambiguous: false }
    : { id: null, ambiguous: rows.length > 1 };
}

async function matchSubject(executor: any, subjectKey: string): Promise<{ id: number | null; ambiguous: boolean }> {
  const [rows]: any = await executor.query('SELECT id FROM subjects WHERE code=? OR name=? LIMIT 2', [subjectKey, subjectKey]);
  return rows.length === 1
    ? { id: Number(rows[0].id), ambiguous: false }
    : { id: null, ambiguous: rows.length > 1 };
}

async function insertGradeRow(executor: any, batchId: number, row: GradeSourceRow): Promise<boolean> {
  const student = await matchStudent(executor, row.sourceNis);
  const subject = await matchSubject(executor, row.sourceSubject);
  const matchStatus = student.ambiguous || subject.ambiguous
    ? 'AMBIGUOUS'
    : student.id && subject.id ? 'EXACT_OFFICIAL' : 'UNMATCHED';
  const reviewNote = student.ambiguous
    ? 'OFFICIAL_NIS_NOT_UNIQUE'
    : subject.ambiguous
      ? 'SOURCE_SUBJECT_MATCHES_MULTIPLE_MASTERS'
      : !student.id
        ? 'OFFICIAL_NIS_NOT_FOUND'
        : !subject.id
          ? 'OFFICIAL_SUBJECT_NOT_FOUND'
          : null;
  await executor.execute(
    `INSERT INTO import_grade_rows(
       batch_id,source_row_number,source_nis,source_name,source_class,source_subject,semester,score,notes,
       matched_student_id,matched_subject_id,match_status,review_note
     ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [
      batchId, row.sourceRowNumber, row.sourceNis, row.sourceName, row.sourceClass, row.sourceSubject,
      row.semester, row.score, row.notes, student.id, subject.id, matchStatus, reviewNote,
    ],
  );
  return Boolean(student.id && subject.id && !student.ambiguous && !subject.ambiguous);
}

gradeXlsxImportRouter.get('/template', async (_req, res, next) => {
  try {
    const template = await createGradeTemplate();
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="grade-template.xlsx"');
    res.send(template);
  } catch (error) { next(error); }
});

gradeXlsxImportRouter.get('/', async (_req, res, next) => {
  try {
    const [batches] = await db.query(
      `SELECT b.id,b.source_name,b.source_checksum,b.academic_year_id,b.status,b.created_at,b.approved_at,
              COUNT(r.id) total_rows,COALESCE(SUM(r.matched_student_id IS NULL OR r.matched_subject_id IS NULL),0) unresolved_rows
       FROM import_batches b LEFT JOIN import_grade_rows r ON r.batch_id=b.id
       WHERE b.source_type='GRADES' GROUP BY b.id ORDER BY b.created_at DESC,b.id DESC`,
    );
    res.json({ batches });
  } catch (error) { next(error); }
});

gradeXlsxImportRouter.post('/stage', upload.single('file'), async (req, res, next) => {
  try {
    if (!req.file) return void res.status(400).json({ error: 'FILE_REQUIRED' });
    if (!req.file.originalname.toLowerCase().endsWith('.xlsx') ||
        req.file.mimetype !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
        !(await validOffice(req.file.buffer, 'xl'))) {
      return void res.status(400).json({ error: 'INVALID_GRADE_XLSX' });
    }
    const academicYearId = id.safeParse(req.body.academicYearId);
    if (!academicYearId.success) return void res.status(400).json({ error: 'ACADEMIC_YEAR_REQUIRED_FOR_GRADE_IMPORT' });
    const rows = await parseGradeWorkbook(req.file.buffer);
    const checksum = digest(req.file.buffer);
    const conn = await db.getConnection();
    const lockName = `grade-import:${checksum.slice(0, 47)}`;
    let lockAcquired = false;
    try {
      const [locks]: any = await conn.query('SELECT GET_LOCK(?,10) acquired', [lockName]);
      lockAcquired = Number(locks[0]?.acquired) === 1;
      if (!lockAcquired) return void res.status(409).json({ error: 'IMPORT_SOURCE_STAGING_IN_PROGRESS' });
      await conn.beginTransaction();
      const [years]: any = await conn.query('SELECT id FROM academic_years WHERE id=? FOR UPDATE', [academicYearId.data]);
      if (!years[0]) { await conn.rollback(); return void res.status(404).json({ error: 'ACADEMIC_YEAR_NOT_FOUND' }); }
      const [existing]: any = await conn.query(
        `SELECT id FROM import_batches WHERE source_type='GRADES' AND source_checksum=?
         AND status IN('STAGED','REVIEW_REQUIRED','APPROVED','IMPORTED') LIMIT 1 FOR UPDATE`,
        [checksum],
      );
      if (existing[0]) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_SOURCE_ALREADY_STAGED' }); }
      const sourceName = safeFilename(req.file.originalname);
      const [insertBatch]: any = await conn.execute(
        `INSERT INTO import_batches(source_type,source_name,source_checksum,academic_year_id,status,created_by)
         VALUES('GRADES',?,?,?,'STAGED',?)`,
        [sourceName, checksum, academicYearId.data, req.auth!.userId],
      );
      const batchId = Number(insertBatch.insertId);
      let matchedCount = 0;
      for (const row of rows) {
        if (await insertGradeRow(conn, batchId, row)) matchedCount++;
      }
      await writeAudit(req, {
        action: 'GRADE_IMPORT.STAGED',
        entityType: 'import_batch',
        entityId: batchId,
        metadata: { sourceName, checksum, academicYearId: academicYearId.data, rowCount: rows.length, matchedCount },
      }, conn);
      await conn.commit();
      res.status(201).json({
        batchId, sourceName, checksum, academicYearId: academicYearId.data,
        rowCount: rows.length, matchedCount, unresolvedCount: rows.length - matchedCount,
      });
    } catch (error) {
      await conn.rollback();
      throw error;
    } finally {
      if (lockAcquired) await conn.query('SELECT RELEASE_LOCK(?)', [lockName]);
      conn.release();
    }
  } catch (error: any) {
    if (error?.status === 400 && (
      error?.code === 'INVALID_GRADE_XLSX' ||
      (typeof error?.code === 'string' && error.code.startsWith('GRADE_'))
    )) return void res.status(400).json({ error: error.code });
    next(error);
  }
});

gradeXlsxImportRouter.get('/candidates', async (req, res, next) => {
  const rowId = id.safeParse(req.query.rowId);
  const batchId = id.safeParse(req.query.batchId);
  if (!rowId.success || !batchId.success) return void res.status(400).json({ error: 'INVALID_IMPORT_REVIEW_ID' });
  try {
    const [rows]: any = await db.query(
      `SELECT source_nis,source_name,source_class,source_subject FROM import_grade_rows
       WHERE id=? AND batch_id=?`,
      [rowId.data, batchId.data],
    );
    if (!rows[0]) return void res.status(404).json({ error: 'IMPORT_ROW_NOT_FOUND' });
    const [students] = await db.query(
      `SELECT id,nis,name,status FROM students
       WHERE nis=? OR (? IS NOT NULL AND name LIKE ?) ORDER BY (nis=?) DESC,name LIMIT 25`,
      [rows[0].source_nis, rows[0].source_name, `%${rows[0].source_name ?? ''}%`, rows[0].source_nis],
    );
    const [subjects] = await db.query(
      `SELECT id,code,name,book_name FROM subjects
       WHERE code=? OR name=? OR name LIKE ? ORDER BY (code=?) DESC,(name=?) DESC,name LIMIT 25`,
      [rows[0].source_subject, rows[0].source_subject, `%${rows[0].source_subject}%`, rows[0].source_subject, rows[0].source_subject],
    );
    res.json({ students, subjects });
  } catch (error) { next(error); }
});

gradeXlsxImportRouter.put('/:batchId/review/:rowId', async (req, res, next) => {
  const batchId = id.safeParse(req.params.batchId);
  const rowId = id.safeParse(req.params.rowId);
  const input = resolution.safeParse(req.body);
  if (!batchId.success || !rowId.success) return void res.status(400).json({ error: 'INVALID_IMPORT_REVIEW_ID' });
  if (!input.success) return void res.status(400).json({ error: 'INVALID_GRADE_REVIEW' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batches]: any = await conn.query(
      `SELECT status FROM import_batches WHERE id=? AND source_type='GRADES' FOR UPDATE`,
      [batchId.data],
    );
    if (!batches[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (!['STAGED', 'REVIEW_REQUIRED'].includes(batches[0].status)) {
      await conn.rollback();
      return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_REVIEWABLE' });
    }
    const [rows]: any = await conn.query(
      'SELECT * FROM import_grade_rows WHERE id=? AND batch_id=? FOR UPDATE',
      [rowId.data, batchId.data],
    );
    if (!rows[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_ROW_NOT_FOUND' }); }
    let matchStatus = 'UNMATCHED';
    let reviewNote = input.data.note ?? null;
    let studentId = input.data.studentId;
    let subjectId = input.data.subjectId;
    let exactStudent = false;
    let exactSubject = false;
    if (studentId !== null) {
      const [students]: any = await conn.query('SELECT id,nis FROM students WHERE id=? FOR UPDATE', [studentId]);
      if (!students[0]) { await conn.rollback(); return void res.status(404).json({ error: 'MATCHED_STUDENT_NOT_FOUND' }); }
      exactStudent = String(students[0].nis) === String(rows[0].source_nis);
      if (!exactStudent && !reviewNote) {
        await conn.rollback();
        return void res.status(400).json({ error: 'GRADE_STUDENT_OVERRIDE_NOTE_REQUIRED' });
      }
    }
    if (subjectId !== null) {
      const [subjects]: any = await conn.query('SELECT id,code,name FROM subjects WHERE id=? FOR UPDATE', [subjectId]);
      if (!subjects[0]) { await conn.rollback(); return void res.status(404).json({ error: 'MATCHED_SUBJECT_NOT_FOUND' }); }
      exactSubject = normalized(subjects[0].code) === normalized(rows[0].source_subject) ||
        normalized(subjects[0].name) === normalized(rows[0].source_subject);
      if (!exactSubject && !reviewNote) {
        await conn.rollback();
        return void res.status(400).json({ error: 'GRADE_SUBJECT_OVERRIDE_NOTE_REQUIRED' });
      }
    }
    if (studentId !== null && subjectId !== null) {
      matchStatus = exactStudent && exactSubject ? 'EXACT_OFFICIAL' : 'APPROVED';
    }
    await conn.execute(
      `UPDATE import_grade_rows SET matched_student_id=?,matched_subject_id=?,match_status=?,review_note=?
       WHERE id=? AND batch_id=?`,
      [studentId, subjectId, matchStatus, reviewNote, rowId.data, batchId.data],
    );
    await conn.execute(`UPDATE import_batches SET status='REVIEW_REQUIRED' WHERE id=? AND status='STAGED'`, [batchId.data]);
    await writeAudit(req, {
      action: 'GRADE_IMPORT.ROW_REVIEWED',
      entityType: 'import_grade_row',
      entityId: rowId.data,
      metadata: { batchId: batchId.data, studentId, subjectId, matchStatus },
    }, conn);
    await conn.commit();
    res.json({ studentId, subjectId, matchStatus, reviewNote });
  } catch (error) {
    await conn.rollback();
    next(error);
  } finally {
    conn.release();
  }
});
