import type { PoolConnection } from 'mysql2/promise';
import { Router } from 'express';
import { z } from 'zod';
import { db } from '../../config/db.js';
import { requireAuthentication } from '../../middleware/authentication.js';
import { requirePermission, requireSuperAdmin } from '../../middleware/authorization.js';
import { writeAudit } from '../audit/audit.service.js';
import multer from 'multer';
import { digest, validOffice } from '../storage/integrity.js';
import { createMuhafadlohTemplate, MUHAFADLOH_PERIODS, parseMuhafadlohWorkbook, type MuhafadlohSourceRow } from './muhafadloh-xlsx.js';

export const muhafadlohImportRouter = Router();
muhafadlohImportRouter.use(requireAuthentication, requirePermission('muhafadloh.import.manage'), requireSuperAdmin);

const id = z.coerce.number().int().positive();
const approval = z.object({ academicYearId: z.coerce.number().int().positive() }).strict();
const upload = multer({ storage: multer.memoryStorage(), limits: { files: 1, fileSize: 10 * 1024 * 1024 } });
const resolution = z.discriminatedUnion('decision', [
  z.object({ decision: z.literal('MATCH'), studentId: z.number().int().positive(), academicYearId: z.number().int().positive(), note: z.string().trim().max(1000).nullable().optional() }).strict(),
  z.object({ decision: z.literal('CLEAR'), note: z.string().trim().max(1000).nullable().optional() }).strict(),
]);
const unresolvedSql = `(r.matched_student_id IS NULL OR r.match_status IN('UNMATCHED','NAME_CLASS_REVIEW','AMBIGUOUS'))`;

muhafadlohImportRouter.get('/template', async (_req, res, next) => {
  try {
    const template = await createMuhafadlohTemplate();
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="muhafadloh-template.xlsx"');
    res.send(template);
  } catch (error) { next(error); }
});

muhafadlohImportRouter.post('/stage', upload.single('file'), async (req, res, next) => {
  try {
    if (!req.file) return void res.status(400).json({ error: 'FILE_REQUIRED' });
    if (!req.file.originalname.toLowerCase().endsWith('.xlsx') ||
        req.file.mimetype !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
        !(await validOffice(req.file.buffer, 'xl'))) {
      return void res.status(400).json({ error: 'INVALID_MUHAFADLOH_XLSX' });
    }
    const rows = await parseMuhafadlohWorkbook(req.file.buffer);
    const checksum = digest(req.file.buffer);
    const original = String(req.file.originalname || 'muhafadloh.xlsx').replace(/\\/g, '/');
    const sourceName = (original.split('/').pop() || 'muhafadloh.xlsx').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 255) || 'muhafadloh.xlsx';
    const conn = await db.getConnection();
    const lockName = `muhafadloh-import:${checksum.slice(0, 41)}`;
    let lockAcquired = false;
    try {
      const [locks]: any = await conn.query('SELECT GET_LOCK(?,10) acquired', [lockName]);
      lockAcquired = Number(locks[0]?.acquired) === 1;
      if (!lockAcquired) return void res.status(409).json({ error: 'IMPORT_SOURCE_STAGING_IN_PROGRESS' });
      await conn.beginTransaction();
      const [existing]: any = await conn.query(
        `SELECT id FROM import_batches WHERE source_type='MUHAFADLOH' AND source_checksum=?
         AND status IN('STAGED','REVIEW_REQUIRED','APPROVED','IMPORTED') LIMIT 1 FOR UPDATE`,
        [checksum],
      );
      if (existing[0]) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_SOURCE_ALREADY_STAGED' }); }

      const [insertBatch]: any = await conn.execute(
        `INSERT INTO import_batches(source_type,source_name,source_checksum,status,created_by)
         VALUES('MUHAFADLOH',?,?,'STAGED',?)`,
        [sourceName, checksum, req.auth!.userId],
      );
      const batchId = Number(insertBatch.insertId);
      let matchedCount = 0;
      for (const row of rows) {
        const [matches]: any = await conn.query('SELECT id FROM students WHERE nis=? LIMIT 2', [row.sourceNis]);
        const studentId = matches.length === 1 ? Number(matches[0].id) : null;
        const matchStatus = studentId ? 'EXACT_OFFICIAL_NIS' : matches.length > 1 ? 'AMBIGUOUS' : 'UNMATCHED';
        const reviewNote = studentId ? null : matches.length > 1 ? 'OFFICIAL_NIS_NOT_UNIQUE' : 'OFFICIAL_NIS_NOT_FOUND';
        if (studentId) matchedCount++;
        await insertMuhafadlohRow(conn, batchId, row, studentId, matchStatus, reviewNote);
      }
      await writeAudit(req, {
        action: 'MUHAFADLOH_IMPORT.STAGED',
        entityType: 'import_batch',
        entityId: batchId,
        metadata: { sourceName, checksum, rowCount: rows.length, matchedCount, unresolvedCount: rows.length - matchedCount },
      }, conn);
      await conn.commit();
      res.status(201).json({
        batchId, sourceName, checksum, rowCount: rows.length,
        matchedCount, unresolvedCount: rows.length - matchedCount,
      });
    } catch (error) {
      await conn.rollback();
      throw error;
    } finally {
      if (lockAcquired) await conn.query('SELECT RELEASE_LOCK(?)', [lockName]);
      conn.release();
    }
  } catch (error: any) {
    if (error?.status === 400 && (
      error?.code === 'INVALID_MUHAFADLOH_XLSX' ||
      (typeof error?.code === 'string' && error.code.startsWith('MUHAFADLOH_'))
    )) return void res.status(400).json({ error: error.code });
    next(error);
  }
});

muhafadlohImportRouter.get('/', async (_req, res, next) => {
  try {
    const [rows] = await db.query(`SELECT b.id,b.source_name,b.source_checksum,b.academic_year_id,b.status,b.created_at,b.approved_at,COUNT(r.id) total_rows,COALESCE(SUM(${unresolvedSql}),0) unresolved_rows,COALESCE(SUM(NOT ${unresolvedSql}),0) resolved_rows FROM import_batches b LEFT JOIN import_muhafadloh_rows r ON r.batch_id=b.id WHERE b.source_type='MUHAFADLOH' GROUP BY b.id ORDER BY b.created_at DESC,b.id DESC`);
    res.json({ batches: rows });
  } catch (e) { next(e); }
});

muhafadlohImportRouter.get('/:batchId/review', async (req, res, next) => {
  try {
    const b = id.safeParse(req.params.batchId);
    if (!b.success) return void res.status(400).json({ error: 'INVALID_IMPORT_BATCH' });
    const [batch]: any = await db.query(`SELECT id,source_type,source_name,source_checksum,academic_year_id,status,created_at,approved_at FROM import_batches WHERE id=? AND source_type='MUHAFADLOH' LIMIT 1`, [b.data]);
    if (!batch[0]) return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' });
    const periods = MUHAFADLOH_PERIODS.join(',');
    const [rows] = await db.query(`SELECT r.id,r.source_row_number,r.source_nis,r.source_name,r.source_class,${periods.split(',').map(period => `r.${period}`).join(',')},r.matched_student_id,r.match_status,r.review_note,s.nis official_nis,s.name official_name,s.status student_status,c.code official_class FROM import_muhafadloh_rows r LEFT JOIN students s ON s.id=r.matched_student_id LEFT JOIN student_enrollments se ON se.student_id=s.id AND se.academic_year_id=? LEFT JOIN classes c ON c.id=se.class_id WHERE r.batch_id=? ORDER BY r.source_row_number`, [batch[0].academic_year_id, b.data]);
    const [candidates] = await db.query(`SELECT DISTINCT s.id,s.nis,s.name,s.status,c.code class_code,se.academic_year_id FROM students s LEFT JOIN student_enrollments se ON se.student_id=s.id AND se.academic_year_id=COALESCE(?,(SELECT id FROM academic_years WHERE is_active=1 LIMIT 1)) LEFT JOIN classes c ON c.id=se.class_id ORDER BY s.name,s.nis`, [batch[0].academic_year_id]);
    res.json({ batch: batch[0], rows, candidates, openExecution: 'm1' });
  } catch (e) { next(e); }
});

async function insertMuhafadlohRow(
  executor: any,
  batchId: number,
  row: MuhafadlohSourceRow,
  studentId: number | null,
  matchStatus: string,
  reviewNote: string | null,
) {
  const columns = MUHAFADLOH_PERIODS.join(',');
  const placeholders = MUHAFADLOH_PERIODS.map(() => '?').join(',');
  await executor.execute(
    `INSERT INTO import_muhafadloh_rows(batch_id,source_row_number,source_nis,source_name,source_class,${columns},matched_student_id,match_status,review_note)
     VALUES(?,?,?,?,?,${placeholders},?,?,?)`,
    [
      batchId, row.sourceRowNumber, row.sourceNis, row.sourceName, row.sourceClass,
      ...MUHAFADLOH_PERIODS.map(period => row.scores[period]), studentId, matchStatus, reviewNote,
    ],
  );
}

async function assertResolutionTarget(conn: PoolConnection, studentId: number, academicYearId: number, sourceClass: string | null) {
  const [year]: any = await conn.query('SELECT id FROM academic_years WHERE id=? LIMIT 1 FOR UPDATE', [academicYearId]);
  if (!year[0]) throw Object.assign(new Error('ACADEMIC_YEAR_NOT_FOUND'), { status: 400 });
  const [students]: any = await conn.query(`SELECT s.id,s.nis,s.name,s.status,se.class_id,se.status enrollment_status,c.code class_code FROM students s LEFT JOIN student_enrollments se ON se.student_id=s.id AND se.academic_year_id=? LEFT JOIN classes c ON c.id=se.class_id WHERE s.id=? FOR UPDATE`, [academicYearId, studentId]);
  if (!students[0]) throw Object.assign(new Error('MATCHED_STUDENT_NOT_FOUND'), { status: 404 });
  if (!students[0].class_id || !['ACTIVE','PROMOTED','GRADUATED','WITHDRAWN'].includes(students[0].enrollment_status)) throw Object.assign(new Error('STUDENT_NOT_ENROLLED_FOR_MUHAFADLOH'), { status: 409 });
  const expectedClass = String(sourceClass ?? '').trim().toUpperCase(), actualClass = String(students[0].class_code ?? '').trim().toUpperCase();
  if (expectedClass && expectedClass !== actualClass) throw Object.assign(new Error('SOURCE_CLASS_MUHAFADLOH_ENROLLMENT_MISMATCH'), { status: 409 });
  return students[0];
}

muhafadlohImportRouter.put('/:batchId/review/:rowId', requireSuperAdmin, async (req, res, next) => {
  const b = id.safeParse(req.params.batchId), row = id.safeParse(req.params.rowId), x = resolution.safeParse(req.body);
  if (!b.success || !row.success) return void res.status(400).json({ error: 'INVALID_IMPORT_REVIEW_ID' });
  if (!x.success) return void res.status(400).json({ error: 'INVALID_MUHAFADLOH_REVIEW_DECISION' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batches]: any = await conn.query(`SELECT id,status,academic_year_id FROM import_batches WHERE id=? AND source_type='MUHAFADLOH' FOR UPDATE`, [b.data]);
    if (!batches[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (!['STAGED','REVIEW_REQUIRED'].includes(batches[0].status)) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_REVIEWABLE' }); }
    const [rows]: any = await conn.query(`SELECT id,source_nis,source_name,source_class,matched_student_id,match_status,review_note FROM import_muhafadloh_rows WHERE id=? AND batch_id=? FOR UPDATE`, [row.data, b.data]);
    if (!rows[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_ROW_NOT_FOUND' }); }
    const before = { matchedStudentId: rows[0].matched_student_id ?? null, matchStatus: rows[0].match_status, note: rows[0].review_note ?? null };
    let after: Record<string, unknown>;
    if (x.data.decision === 'CLEAR') {
      await conn.execute(`UPDATE import_muhafadloh_rows SET matched_student_id=NULL,match_status='UNMATCHED',review_note=? WHERE id=?`, [x.data.note ?? null, row.data]);
      after = { matchedStudentId: null, matchStatus: 'UNMATCHED', note: x.data.note ?? null };
    } else {
      if (batches[0].academic_year_id != null && Number(batches[0].academic_year_id) !== x.data.academicYearId) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_ACADEMIC_YEAR_ALREADY_BOUND' }); }
      const student = await assertResolutionTarget(conn, x.data.studentId, x.data.academicYearId, rows[0].source_class);
      const [duplicate]: any = await conn.query(`SELECT id FROM import_muhafadloh_rows WHERE batch_id=? AND id<>? AND matched_student_id=? LIMIT 1 FOR UPDATE`, [b.data, row.data, x.data.studentId]);
      if (duplicate[0]) { await conn.rollback(); return void res.status(409).json({ error: 'DUPLICATE_STUDENT_M1_IN_BATCH' }); }
      await conn.execute(`UPDATE import_batches SET academic_year_id=?,status='REVIEW_REQUIRED' WHERE id=?`, [x.data.academicYearId, b.data]);
      await conn.execute(`UPDATE import_muhafadloh_rows SET matched_student_id=?,match_status='APPROVED',review_note=? WHERE id=?`, [x.data.studentId, x.data.note ?? null, row.data]);
      after = { matchedStudentId: x.data.studentId, matchedStudentNis: student.nis, matchedStudentName: student.name, matchStatus: 'APPROVED', note: x.data.note ?? null };
    }
    await conn.execute(`UPDATE import_batches SET status='REVIEW_REQUIRED' WHERE id=? AND status='STAGED'`, [b.data]);
    await writeAudit(req, { action: 'MUHAFADLOH_IMPORT.REVIEW_RESOLVED', entityType: 'import_muhafadloh_row', entityId: row.data, metadata: { batchId: b.data, decision: x.data.decision, sourceNis: rows[0].source_nis, sourceName: rows[0].source_name, before, after } }, conn);
    await conn.commit(); res.status(204).end();
  } catch (e: any) {
    await conn.rollback();
    if (e?.status && ['ACADEMIC_YEAR_NOT_FOUND','MATCHED_STUDENT_NOT_FOUND','STUDENT_NOT_ENROLLED_FOR_MUHAFADLOH','SOURCE_CLASS_MUHAFADLOH_ENROLLMENT_MISMATCH'].includes(e?.message)) return void res.status(e.status).json({ error: e.message });
    next(e);
  } finally { conn.release(); }
});

muhafadlohImportRouter.post('/:batchId/approve', requireSuperAdmin, async (req, res, next) => {
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const b = id.safeParse(req.params.batchId), a = approval.safeParse(req.body);
    if (!b.success || !a.success) { await conn.rollback(); return void res.status(400).json({ error: 'INVALID_IMPORT_APPROVAL' }); }
    const [batch]: any = await conn.query(`SELECT status,academic_year_id FROM import_batches WHERE id=? AND source_type='MUHAFADLOH' FOR UPDATE`, [b.data]);
    if (!batch[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (!['STAGED','REVIEW_REQUIRED'].includes(batch[0].status)) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_REVIEWABLE' }); }
    if (batch[0].academic_year_id != null && Number(batch[0].academic_year_id) !== a.data.academicYearId) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_ACADEMIC_YEAR_ALREADY_BOUND' }); }
    const [ay]: any = await conn.query(`SELECT id FROM academic_years WHERE id=? LIMIT 1`, [a.data.academicYearId]);
    if (!ay[0]) { await conn.rollback(); return void res.status(400).json({ error: 'ACADEMIC_YEAR_NOT_FOUND' }); }
    const scoreChecks = MUHAFADLOH_PERIODS.map(period => `${period}<0 OR ${period}>100`).join(' OR ');
    const emptyScores = MUHAFADLOH_PERIODS.map(period => `${period} IS NULL`).join(' AND ');
    const [bad]: any = await conn.query(
      `SELECT COUNT(*) n FROM import_muhafadloh_rows
       WHERE batch_id=? AND (
         matched_student_id IS NULL OR match_status IN('UNMATCHED','NAME_CLASS_REVIEW','AMBIGUOUS')
         OR (${scoreChecks}) OR (${emptyScores})
       )`,
      [b.data],
    );
    if (Number(bad[0].n) > 0) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_REVIEW_INCOMPLETE' }); }
    const [dup]: any = await conn.query(`SELECT matched_student_id FROM import_muhafadloh_rows WHERE batch_id=? GROUP BY matched_student_id HAVING COUNT(*)>1 LIMIT 1`, [b.data]);
    if (dup[0]) { await conn.rollback(); return void res.status(409).json({ error: 'DUPLICATE_STUDENT_M1_IN_BATCH' }); }
    const [result]: any = await conn.execute(`UPDATE import_batches SET academic_year_id=?,status='APPROVED',approved_by=?,approved_at=NOW() WHERE id=? AND status IN('STAGED','REVIEW_REQUIRED')`, [a.data.academicYearId, req.auth!.userId, b.data]);
    if (result.affectedRows !== 1) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_STATE_CHANGED' }); }
    await writeAudit(req, { action: 'MUHAFADLOH_IMPORT.APPROVED', entityType: 'import_batch', entityId: b.data, metadata: { academicYearId: a.data.academicYearId } }, conn);
    await conn.commit();
    res.status(204).end();
  } catch (e) { await conn.rollback(); next(e); }
  finally { conn.release(); }
});

muhafadlohImportRouter.post('/:batchId/apply', requireSuperAdmin, async (req, res, next) => {
  const b = id.safeParse(req.params.batchId);
  if (!b.success) return void res.status(400).json({ error: 'INVALID_IMPORT_APPLY' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batch]: any = await conn.query(`SELECT status,academic_year_id FROM import_batches WHERE id=? AND source_type='MUHAFADLOH' FOR UPDATE`, [b.data]);
    if (!batch[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (batch[0].status !== 'APPROVED' || !batch[0].academic_year_id) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_APPROVED' }); }
    const academicYearId = Number(batch[0].academic_year_id);
    const importPeriods = MUHAFADLOH_PERIODS.join(',');
    const [rows]: any = await conn.query(`SELECT id,source_class,matched_student_id,match_status,${importPeriods} FROM import_muhafadloh_rows WHERE batch_id=? ORDER BY source_row_number FOR UPDATE`, [b.data]);
    if (!rows.length) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_EMPTY' }); }
    const seen = new Set<number>();
    for (const r of rows) {
      if (!r.matched_student_id || ['UNMATCHED','NAME_CLASS_REVIEW','AMBIGUOUS'].includes(r.match_status)) throw new Error('UNMATCHED_MUHAFADLOH_ROW');
      if (MUHAFADLOH_PERIODS.every(period => r[period] == null)) throw new Error('EMPTY_MUHAFADLOH_ROW');
      for (const period of MUHAFADLOH_PERIODS) {
        if (r[period] != null && (Number(r[period]) < 0 || Number(r[period]) > 100)) {
          throw new Error('INVALID_MUHAFADLOH_SCORE');
        }
      }
      const studentId = Number(r.matched_student_id);
      if (seen.has(studentId)) throw new Error('DUPLICATE_STUDENT_M1_IN_BATCH');
      seen.add(studentId);
      const [en]: any = await conn.query(`SELECT se.class_id,c.code class_code FROM student_enrollments se JOIN classes c ON c.id=se.class_id WHERE se.student_id=? AND se.academic_year_id=? AND se.status IN('ACTIVE','PROMOTED','GRADUATED','WITHDRAWN') FOR UPDATE`, [studentId, academicYearId]);
      if (en.length === 0) throw new Error('STUDENT_NOT_ENROLLED_FOR_MUHAFADLOH');
      if (en.length !== 1) throw new Error('AMBIGUOUS_MUHAFADLOH_ENROLLMENT');
      const sourceClass = String(r.source_class ?? '').trim();
      if (sourceClass && sourceClass.toUpperCase() !== String(en[0].class_code ?? '').trim().toUpperCase()) throw new Error('SOURCE_CLASS_MUHAFADLOH_ENROLLMENT_MISMATCH');
      const provenanceColumns = MUHAFADLOH_PERIODS.map(period => `${period}_import_row_id`);
      const existingColumns = MUHAFADLOH_PERIODS.flatMap((period, index) => [period, provenanceColumns[index]!]).join(',');
      const [existing]: any = await conn.query(
        `SELECT ${existingColumns} FROM muhafadloh WHERE student_id=? AND academic_year_id=? FOR UPDATE`,
        [studentId, academicYearId],
      );
      if (existing[0]) {
        for (const period of MUHAFADLOH_PERIODS) {
          if (r[period] != null && existing[0][period] != null) {
            throw new Error(`OFFICIAL_${period.toUpperCase()}_ALREADY_EXISTS`);
          }
        }
      }
      const officialColumns = MUHAFADLOH_PERIODS.flatMap(period => [period, `${period}_import_row_id`]);
      const insertColumns = ['student_id', 'class_id', 'academic_year_id', ...officialColumns, 'recorded_by'];
      const values = MUHAFADLOH_PERIODS.flatMap(period => [r[period], r[period] == null ? null : r.id]);
      const updateValues = MUHAFADLOH_PERIODS.flatMap(period => [
        `${period}=COALESCE(${period},VALUES(${period}))`,
        `${period}_import_row_id=COALESCE(${period}_import_row_id,VALUES(${period}_import_row_id))`,
      ]);
      await conn.execute(
        `INSERT INTO muhafadloh(${insertColumns.join(',')}) VALUES(${insertColumns.map(() => '?').join(',')})
         ON DUPLICATE KEY UPDATE class_id=VALUES(class_id),${updateValues.join(',')},recorded_by=VALUES(recorded_by)`,
        [studentId, en[0].class_id, academicYearId, ...values, req.auth!.userId],
      );
    }
    const [result]: any = await conn.execute(`UPDATE import_batches SET status='IMPORTED' WHERE id=? AND status='APPROVED'`, [b.data]);
    if (result.affectedRows !== 1) throw new Error('IMPORT_BATCH_STATE_CHANGED');
    await writeAudit(req, { action: 'IMPORT.APPLIED', entityType: 'import_batch', entityId: b.data, metadata: { rows: rows.length } }, conn);
    await conn.commit(); res.status(204).end();
  } catch (e: any) {
    await conn.rollback();
    if (['UNMATCHED_MUHAFADLOH_ROW','EMPTY_MUHAFADLOH_ROW','INVALID_MUHAFADLOH_SCORE','DUPLICATE_STUDENT_M1_IN_BATCH','STUDENT_NOT_ENROLLED_FOR_MUHAFADLOH','AMBIGUOUS_MUHAFADLOH_ENROLLMENT','SOURCE_CLASS_MUHAFADLOH_ENROLLMENT_MISMATCH','IMPORT_BATCH_STATE_CHANGED'].includes(e?.message) ||
        (typeof e?.message === 'string' && /^OFFICIAL_M[1-8]_ALREADY_EXISTS$/.test(e.message))) return void res.status(409).json({ error: e.message });
    next(e);
  } finally { conn.release(); }
});
