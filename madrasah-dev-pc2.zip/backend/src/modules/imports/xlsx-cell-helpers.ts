import ExcelJS from 'exceljs';

export function headerKey(value: unknown): string {
  return typeof value === 'string'
    ? value.normalize('NFKC').trim().toLocaleLowerCase('id-ID').replace(/[\s_-]+/g, '')
    : '';
}

export function textCell(cell: ExcelJS.Cell): string | null {
  const value = cell.value;
  if (typeof value === 'string') return value.normalize('NFKC').replace(/\s+/g, ' ').trim() || null;
  if (value && typeof value === 'object' && 'richText' in value) {
    const text = value.richText.map((part) => part.text).join('');
    return text.normalize('NFKC').replace(/\s+/g, ' ').trim() || null;
  }
  return null;
}
