import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';
import { createGradeTemplate, parseGradeWorkbook } from './grade-xlsx.js';

async function makeWorkbook(headers: string[], rows: unknown[][]): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Synthetic');
  worksheet.addRow(headers);
  for (const row of rows) worksheet.addRow(row);
  return Buffer.from(await workbook.xlsx.writeBuffer());
}

const headers = ['NIS', 'Nama', 'Kelas', 'Mata_Pelajaran', 'Semester', 'Nilai', 'Catatan'];

describe('parseGradeWorkbook', () => {
  it('parses explicit semester, text NIS, scores and optional notes', async () => {
    const rows = await parseGradeWorkbook(await makeWorkbook(headers, [
      ['000123', 'Synthetic Student', 'A1', 'Fiqih', 'ganjil', 87.5, 'Exam 1'],
    ]));
    assert.deepEqual(rows, [{
      sourceRowNumber: 2,
      sourceNis: '000123',
      sourceName: 'Synthetic Student',
      sourceClass: 'A1',
      sourceSubject: 'Fiqih',
      semester: 'GANJIL',
      score: 87.5,
      notes: 'Exam 1',
    }]);
  });

  it('requires a text NIS and does not infer a missing semester', async () => {
    await assert.rejects(
      parseGradeWorkbook(await makeWorkbook(headers, [
        [123, 'Synthetic Student', 'A1', 'Fiqih', 'GENAP', 80, ''],
      ])),
      /GRADE_ROW_INVALID/,
    );
    await assert.rejects(
      parseGradeWorkbook(await makeWorkbook(headers, [
        ['000123', 'Synthetic Student', 'A1', 'Fiqih', '', 80, ''],
      ])),
      /GRADE_ROW_INVALID/,
    );
  });

  it('rejects invalid semester and out-of-range or over-precision scores', async () => {
    for (const [semester, score] of [['GANJIL', -1], ['GENAP', 101], ['UNKNOWN', 80], ['GENAP', '80.123']]) {
      await assert.rejects(
        parseGradeWorkbook(await makeWorkbook(headers, [
          ['000123', 'Synthetic Student', 'A1', 'Fiqih', semester, score, ''],
        ])),
        /GRADE_ROW_INVALID/,
      );
    }
  });

  it('rejects unexpected headers, empty worksheets and malformed workbooks', async () => {
    await assert.rejects(
      parseGradeWorkbook(await makeWorkbook([...headers.slice(0, 6), 'Extra'], [])),
      /GRADE_HEADER_INVALID/,
    );
    await assert.rejects(parseGradeWorkbook(await makeWorkbook(headers, [])), /GRADE_HAS_NO_DATA_ROWS/);
    await assert.rejects(parseGradeWorkbook(Buffer.from('not an xlsx')), /INVALID_GRADE_XLSX/);
  });

  it('creates a template that requires an explicit semester and bounds the score', async () => {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(await createGradeTemplate() as never);
    const sheet = workbook.getWorksheet('Grades');
    assert.deepEqual(
      Array.from({ length: 7 }, (_, index) => sheet?.getCell(1, index + 1).value),
      ['NIS', 'Nama', 'Kelas', 'Mata_Pelajaran', 'Semester', 'Nilai', 'Catatan'],
    );
    assert.deepEqual(sheet?.getCell('E2').dataValidation.formulae, ['"GANJIL,GENAP"']);
    assert.deepEqual(sheet?.getCell('F2').dataValidation.formulae, [0, 100]);
    assert.equal(sheet?.getCell('E2').value, null, 'template does not infer a semester');
  });
});
