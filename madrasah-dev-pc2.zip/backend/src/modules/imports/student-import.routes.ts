import { writeAudit } from '../audit/audit.service.js';
import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { db } from '../../config/db.js';
import { requireAuthentication } from '../../middleware/authentication.js';
import { requirePermission, requireSuperAdmin } from '../../middleware/authorization.js';
import { digest, validOffice } from '../storage/integrity.js';
import { extractWordStudentRowsFromDocx } from './word-student-docx.js';
import { studentRosterImportRouter } from './student-roster-import.routes.js';

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { files: 1, fileSize: 5 * 1024 * 1024 },
});

export const studentImportRouter = Router();
studentImportRouter.use(requireAuthentication, requirePermission('students.import.manage'), requireSuperAdmin);
studentImportRouter.use('/roster', studentRosterImportRouter);

const id = z.coerce.number().int().positive();
const nisCorrection=z.object({reviewedNis:z.string().trim().min(1).max(50).nullable(),note:z.string().trim().max(1000).nullable().optional()}).strict();
const resolution = z.object({
  decision: z.enum(['MATCH_EXISTING', 'CREATE_NEW', 'KEEP_HISTORICAL', 'REVIEW']),
  studentId: z.number().int().positive().nullable().optional(),
  note: z.string().trim().max(1000).nullable().optional(),
}).strict();
const bulkReview = z.object({
  decision: z.enum(['CREATE_NEW', 'KEEP_HISTORICAL']),
  rowIds: z.array(z.number().int().positive()).min(1).max(500),
  note: z.string().trim().max(1000).nullable().optional(),
}).strict().superRefine((value, context) => {
  if (new Set(value.rowIds).size !== value.rowIds.length) context.addIssue({ code: 'custom', message: 'ROW_IDS_MUST_BE_UNIQUE' });
});

async function validateBulkReviewSelection(executor: any, batchId: number, selection: z.infer<typeof bulkReview>, lockRows = false) {
  const [rows]: any = await executor.query(`SELECT id,source_nis,reviewed_nis,source_name,source_class,source_status,matched_student_id,match_status FROM import_student_rows WHERE batch_id=? AND id IN (?) ORDER BY source_row_number${lockRows ? ' FOR UPDATE' : ''}`, [batchId, selection.rowIds]);
  if (rows.length !== selection.rowIds.length) throw Object.assign(new Error('BULK_ROW_SELECTION_INVALID'), { status: 409 });
  const expectedStatus = selection.decision === 'CREATE_NEW' ? 'AKTIF' : 'BOYONG';
  const effectiveNis = rows.map((row: any) => String(row.reviewed_nis ?? row.source_nis ?? '').trim());
  if (rows.some((row: any) => row.source_status !== expectedStatus || row.match_status !== 'UNMATCHED' || row.matched_student_id != null)) {
    throw Object.assign(new Error('BULK_SELECTION_NOT_ELIGIBLE'), { status: 409 });
  }
  if (rows.some((row: any, index: number) => !effectiveNis[index] || !String(row.source_name ?? '').trim() || !String(row.source_class ?? '').trim())) {
    throw Object.assign(new Error('BULK_SELECTION_HAS_MISSING_FIELDS'), { status: 409 });
  }
  const [classes]: any = await executor.query(`SELECT UPPER(TRIM(code)) code_key,COUNT(*) matches FROM classes WHERE active=1 AND UPPER(TRIM(code)) IN (?) GROUP BY UPPER(TRIM(code))`, [[...new Set(rows.map((row: any) => String(row.source_class).trim().toUpperCase()))]]);
  const classCounts = new Map(classes.map((row: any) => [String(row.code_key), Number(row.matches)]));
  if (rows.some((row: any) => classCounts.get(String(row.source_class).trim().toUpperCase()) !== 1)) {
    throw Object.assign(new Error('BULK_SELECTION_CLASS_REQUIRES_REVIEW'), { status: 409 });
  }
  const [studentOwners]: any = await executor.query('SELECT nis FROM students WHERE nis IN (?) FOR UPDATE', [effectiveNis]);
  if (studentOwners.length) throw Object.assign(new Error('BULK_SELECTION_NIS_ALREADY_USED'), { status: 409 });
  const [duplicates]: any = await executor.query(`SELECT TRIM(COALESCE(reviewed_nis,source_nis)) source_nis FROM import_student_rows WHERE batch_id=? AND TRIM(COALESCE(reviewed_nis,source_nis)) IN (?) GROUP BY TRIM(COALESCE(reviewed_nis,source_nis)) HAVING COUNT(*)>1`, [batchId, effectiveNis]);
  if (duplicates.length) throw Object.assign(new Error('BULK_SELECTION_DUPLICATE_NIS'), { status: 409 });
  return { rows, sourceStatus: expectedStatus, effectiveNis };
}

studentImportRouter.post('/stage', upload.single('file'), async (req, res, next) => {
  try {
    if (!req.file) return void res.status(400).json({ error: 'FILE_REQUIRED' });
    if (req.file.mimetype !== 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') return void res.status(400).json({ error: 'INVALID_WORD_DOCX' });
    if (!(await validOffice(req.file.buffer, 'word'))) return void res.status(400).json({ error: 'INVALID_WORD_DOCX' });
    const checksum = digest(req.file.buffer);
    const rows = await extractWordStudentRowsFromDocx(req.file.buffer);
    if (!rows.length) return void res.status(400).json({ error: 'INVALID_WORD_DOCX_CONTENT' });

    const conn = await db.getConnection();
    const lockName = `student-import:${checksum.slice(0, 48)}`;
    let checksumLockAcquired = false;
    try {
      const [lockRows]: any = await conn.query('SELECT GET_LOCK(?, 10) acquired', [lockName]);
      checksumLockAcquired = Number(lockRows[0]?.acquired) === 1;
      if (!checksumLockAcquired) return void res.status(409).json({ error: 'IMPORT_SOURCE_STAGING_IN_PROGRESS' });
      await conn.beginTransaction();
      const [existing]: any = await conn.query(`SELECT id,status FROM import_batches WHERE source_type='WORD_STUDENT_MASTER' AND source_checksum=? AND status IN('STAGED','REVIEW_REQUIRED','APPROVED','IMPORTED') LIMIT 1 FOR UPDATE`, [checksum]);
      if (existing[0]) {
        await conn.rollback();
        return void res.status(409).json({ error: 'IMPORT_SOURCE_ALREADY_STAGED' });
      }

      const originalName = String(req.file.originalname || 'word-master.docx').replace(/\\/g, '/');
      const sourceName = (originalName.split('/').pop() || 'word-master.docx')
        .replace(/[\u0000-\u001f\u007f]/g, '')
        .trim()
        .slice(0, 255) || 'word-master.docx';
      const [result]: any = await conn.execute(`INSERT INTO import_batches(source_type,source_name,source_checksum,status,created_by) VALUES('WORD_STUDENT_MASTER',?,?, 'STAGED', ?)`, [sourceName, checksum, req.auth!.userId]);
      const batchId = Number(result.insertId);
      const counts = { aktif: 0, boyong: 0 };
      for (const row of rows) {
        if (row.sourceStatus === 'AKTIF') counts.aktif++;
        if (row.sourceStatus === 'BOYONG') counts.boyong++;
        await conn.execute(`INSERT INTO import_student_rows(batch_id,source_row_number,source_nis,source_name,source_class,source_status,matched_student_id,match_status) VALUES(?,?,?,?,?,?,NULL,'UNMATCHED')`, [batchId, row.sourceRowNumber, row.sourceNis ?? null, row.sourceName, row.sourceClass ?? null, row.sourceStatus]);
      }
      await writeAudit(req, { action: 'STUDENT_IMPORT.STAGED', entityType: 'import_batch', entityId: batchId, metadata: { sourceName, checksum, rowCount: rows.length, activeCount: counts.aktif, boyongCount: counts.boyong } }, conn);
      await conn.commit();
      res.status(201).json({ batchId, sourceName, checksum, rowCount: rows.length, activeCount: counts.aktif, boyongCount: counts.boyong });
    } catch (e) {
      await conn.rollback();
      throw e;
    } finally {
      if (checksumLockAcquired) await conn.query('SELECT RELEASE_LOCK(?)', [lockName]);
      conn.release();
    }
  } catch (e) {
    const parserError = e as { status?: number; code?: string };
    if (parserError.status === 400 && ['INVALID_WORD_DOCX', 'INVALID_WORD_DOCX_CONTENT'].includes(parserError.code ?? '')) {
      return void res.status(400).json({ error: parserError.code });
    }
    next(e);
  }
});

studentImportRouter.get('/', async (_req, res, next) => {
  try {
    const [rows] = await db.query(`
      SELECT b.id,b.source_name,b.source_checksum,b.status,b.created_at,b.approved_at,
             COUNT(r.id) total_rows,
             COALESCE(SUM(r.match_status IN('AMBIGUOUS','EXACT_NAME_REVIEW','REVIEW','RESOLVED_HISTORICAL')),0) unresolved_rows,
             COALESCE(SUM(r.match_status NOT IN('AMBIGUOUS','EXACT_NAME_REVIEW','REVIEW','RESOLVED_HISTORICAL')),0) resolved_rows
      FROM import_batches b
      LEFT JOIN import_student_rows r ON r.batch_id=b.id
      WHERE b.source_type='WORD_STUDENT_MASTER'
      GROUP BY b.id
      ORDER BY b.created_at DESC,b.id DESC
    `);
    res.json({ batches: rows });
  } catch (e) { next(e); }
});

studentImportRouter.get('/:batchId/review', async (req, res, next) => {
  try {
    const b = id.safeParse(req.params.batchId);
    if (!b.success) return void res.status(400).json({ error: 'INVALID_IMPORT_BATCH' });
    const [batch]: any = await db.query(`SELECT id,source_type,source_name,source_checksum,status,created_at,approved_at FROM import_batches WHERE id=? AND source_type='WORD_STUDENT_MASTER' LIMIT 1`, [b.data]);
    if (!batch[0]) return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' });
    const [rows] = await db.query(`SELECT r.id,r.source_row_number,r.source_nis,r.reviewed_nis,r.source_name,r.source_class,r.source_status,r.birth_place,r.birth_date,r.matched_student_id,r.match_status,r.review_note,r.reviewed_by,r.reviewed_at,c.id matched_class_id,c.code matched_class_code,s.nis matched_student_nis,s.name matched_student_name,s.status matched_student_status FROM import_student_rows r LEFT JOIN classes c ON UPPER(TRIM(c.code))=UPPER(TRIM(r.source_class)) AND c.active=1 LEFT JOIN students s ON s.id=r.matched_student_id WHERE r.batch_id=? ORDER BY r.source_row_number`, [b.data]);
    res.json({ batch: batch[0], rows });
  } catch (e) { next(e); }
});

studentImportRouter.put('/:batchId/review/:rowId/nis', async (req,res,next)=>{const b=id.safeParse(req.params.batchId),row=id.safeParse(req.params.rowId),x=nisCorrection.safeParse(req.body);if(!b.success||!row.success)return void res.status(400).json({error:'INVALID_IMPORT_REVIEW_ID'});if(!x.success)return void res.status(400).json({error:'INVALID_REVIEWED_NIS'});const conn=await db.getConnection();try{await conn.beginTransaction();const[batch]:any=await conn.query(`SELECT status FROM import_batches WHERE id=? AND source_type='WORD_STUDENT_MASTER' FOR UPDATE`,[b.data]);if(!batch[0]){await conn.rollback();return void res.status(404).json({error:'IMPORT_BATCH_NOT_FOUND'})}if(!['STAGED','REVIEW_REQUIRED'].includes(batch[0].status)){await conn.rollback();return void res.status(409).json({error:'IMPORT_BATCH_NOT_REVIEWABLE'})}const[rows]:any=await conn.query(`SELECT id,source_nis,reviewed_nis FROM import_student_rows WHERE id=? AND batch_id=? FOR UPDATE`,[row.data,b.data]);if(!rows[0]){await conn.rollback();return void res.status(404).json({error:'IMPORT_ROW_NOT_FOUND'})}const reviewed=x.data.reviewedNis?.trim()||null;if(reviewed){const[dup]:any=await conn.query(`SELECT id FROM import_student_rows WHERE batch_id=? AND id<>? AND TRIM(COALESCE(reviewed_nis,source_nis))=? LIMIT 1 FOR UPDATE`,[b.data,row.data,reviewed]);if(dup[0]){await conn.rollback();return void res.status(409).json({error:'REVIEWED_NIS_DUPLICATE_IN_BATCH'})}const[owner]:any=await conn.query(`SELECT id,name,status FROM students WHERE nis=? LIMIT 1 FOR UPDATE`,[reviewed]);if(owner[0]){await conn.rollback();return void res.status(409).json({error:'REVIEWED_NIS_ALREADY_USED',studentId:owner[0].id})}}await conn.execute(`UPDATE import_student_rows SET reviewed_nis=?,match_status='REVIEW',review_note=?,reviewed_by=?,reviewed_at=NOW() WHERE id=?`,[reviewed,x.data.note??null,req.auth!.userId,row.data]);await conn.execute(`UPDATE import_batches SET status='REVIEW_REQUIRED' WHERE id=? AND status='STAGED'`,[b.data]);const ip=(req.ip||'').slice(0,45),ua=(req.get('user-agent')||'').slice(0,500);await conn.execute(`INSERT INTO audit_logs(user_id,action,entity_type,entity_id,metadata,ip_address,user_agent) VALUES(?,?,?,?,?,?,?)`,[req.auth!.userId,'STUDENT_IMPORT.NIS_CORRECTED','import_student_row',String(row.data),JSON.stringify({batchId:b.data,sourceNis:rows[0].source_nis,beforeReviewedNis:rows[0].reviewed_nis??null,reviewedNis:reviewed,note:x.data.note??null}),ip||null,ua||null]);await conn.commit();res.status(204).end()}catch(e){await conn.rollback();next(e)}finally{conn.release()}});

studentImportRouter.put('/:batchId/review/:rowId', requireSuperAdmin, async (req, res, next) => {
  const b = id.safeParse(req.params.batchId), row = id.safeParse(req.params.rowId), x = resolution.safeParse(req.body);
  if (!b.success || !row.success) return void res.status(400).json({ error: 'INVALID_IMPORT_REVIEW_ID' });
  if (!x.success) return void res.status(400).json({ error: 'INVALID_IMPORT_REVIEW_DECISION' });
  if (x.data.decision === 'MATCH_EXISTING' && !x.data.studentId) return void res.status(400).json({ error: 'MATCH_EXISTING_REQUIRES_STUDENT' });
  if (x.data.decision !== 'MATCH_EXISTING' && x.data.studentId) return void res.status(400).json({ error: 'STUDENT_ONLY_ALLOWED_FOR_MATCH' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batch]: any = await conn.query(`SELECT status FROM import_batches WHERE id=? AND source_type='WORD_STUDENT_MASTER' FOR UPDATE`, [b.data]);
    if (!batch[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (!['STAGED', 'REVIEW_REQUIRED'].includes(batch[0].status)) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_REVIEWABLE' }); }
    const [rows]: any = await conn.query(`SELECT id,source_nis,reviewed_nis,source_name,source_status,matched_student_id FROM import_student_rows WHERE id=? AND batch_id=? FOR UPDATE`, [row.data, b.data]);
    if (!rows[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_ROW_NOT_FOUND' }); }
    if (x.data.decision === 'KEEP_HISTORICAL' && rows[0].source_status !== 'BOYONG') { await conn.rollback(); return void res.status(409).json({ error: 'HISTORICAL_REQUIRES_BOYONG_SOURCE' }); }
    if (rows[0].source_status === 'BOYONG' && !['MATCH_EXISTING', 'KEEP_HISTORICAL'].includes(x.data.decision)) { await conn.rollback(); return void res.status(409).json({ error: 'BOYONG_REQUIRES_HISTORICAL_OR_EXISTING_MATCH' }); }
    if (x.data.decision === 'KEEP_HISTORICAL') {
      if (rows[0].matched_student_id) { await conn.rollback(); return void res.status(409).json({ error: 'BOYONG_ALREADY_MATCHED_REQUIRES_EXISTING_MATCH' }); }
      const nis = String(rows[0].reviewed_nis ?? rows[0].source_nis ?? '').trim();
      if (!nis) { await conn.rollback(); return void res.status(409).json({ error: 'BOYONG_NIS_REQUIRED_FOR_HISTORICAL_CREATE' }); }
      const [existing]: any = await conn.query(`SELECT id FROM students WHERE nis=? LIMIT 1 FOR UPDATE`, [nis]);
      if (existing[0]) { await conn.rollback(); return void res.status(409).json({ error: 'BOYONG_NIS_ALREADY_EXISTS_REQUIRES_MATCH' }); }
    }
    let matchStatus = 'REVIEW', matchedStudentId: null | number = null;
    if (x.data.decision === 'MATCH_EXISTING') {
      const [students]: any = await conn.query(`SELECT id,nis,name,status FROM students WHERE id=? FOR UPDATE`, [x.data.studentId]);
      if (!students[0]) { await conn.rollback(); return void res.status(404).json({ error: 'MATCHED_STUDENT_NOT_FOUND' }); }
      matchedStudentId = students[0].id; matchStatus = 'RESOLVED_MATCH';
    } else if (x.data.decision === 'CREATE_NEW') matchStatus = 'RESOLVED_NEW';
    else if (x.data.decision === 'KEEP_HISTORICAL') matchStatus = 'RESOLVED_HISTORICAL';
    await conn.execute(`UPDATE import_student_rows SET matched_student_id=?,match_status=?,review_note=?,reviewed_by=?,reviewed_at=NOW() WHERE id=?`, [matchedStudentId, matchStatus, x.data.note ?? null, req.auth!.userId, row.data]);
    await conn.execute(`UPDATE import_batches SET status='REVIEW_REQUIRED' WHERE id=? AND status='STAGED'`, [b.data]);
    const ip = (req.ip || '').slice(0, 45), ua = (req.get('user-agent') || '').slice(0, 500);
    await conn.execute(`INSERT INTO audit_logs(user_id,action,entity_type,entity_id,metadata,ip_address,user_agent) VALUES(?,?,?,?,?,?,?)`, [req.auth!.userId, 'STUDENT_IMPORT.REVIEW_RESOLVED', 'import_student_row', String(row.data), JSON.stringify({ batchId: b.data, decision: x.data.decision, matchedStudentId, note: x.data.note ?? null }), ip || null, ua || null]);
    await writeAudit(req,{action:'STUDENT_IMPORT.MUTATED',entityType:'import_batch',entityId:b.data,metadata:{path:req.path}},conn);
    await conn.commit(); res.status(204).end();
  } catch (e) { await conn.rollback(); next(e); } finally { conn.release(); }
});

studentImportRouter.post('/:batchId/approve', requireSuperAdmin, async (req, res, next) => {
  const b = id.safeParse(req.params.batchId);
  if (!b.success) return void res.status(400).json({ error: 'INVALID_IMPORT_BATCH' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batch]: any = await conn.query(`SELECT status FROM import_batches WHERE id=? AND source_type='WORD_STUDENT_MASTER' FOR UPDATE`, [b.data]);
    if (!batch[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (!['STAGED', 'REVIEW_REQUIRED'].includes(batch[0].status)) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_REVIEWABLE' }); }

    const [duplicates]: any = await conn.query(`SELECT TRIM(COALESCE(reviewed_nis,source_nis)) source_nis FROM import_student_rows WHERE batch_id=? AND COALESCE(reviewed_nis,source_nis) IS NOT NULL AND TRIM(COALESCE(reviewed_nis,source_nis))<>'' GROUP BY TRIM(COALESCE(reviewed_nis,source_nis)) HAVING COUNT(*)>1`, [b.data]);
    if (duplicates.length) {
      const duplicateNis = duplicates.map((d: any) => String(d.source_nis));
      const placeholders = duplicateNis.map(() => '?').join(',');
      await conn.execute(`UPDATE import_student_rows SET match_status='REVIEW',review_note=CASE WHEN review_note IS NULL OR TRIM(review_note)='' THEN 'Duplicate official NIS in source batch; requires Admin/Super Admin verification.' ELSE review_note END,reviewed_by=NULL,reviewed_at=NULL WHERE batch_id=? AND TRIM(COALESCE(reviewed_nis,source_nis)) IN (${placeholders})`, [b.data, ...duplicateNis]);
      await conn.execute(`UPDATE import_batches SET status='REVIEW_REQUIRED' WHERE id=?`, [b.data]);
      const ip = (req.ip || '').slice(0, 45), ua = (req.get('user-agent') || '').slice(0, 500);
      await conn.execute(`INSERT INTO audit_logs(user_id,action,entity_type,entity_id,metadata,ip_address,user_agent) VALUES(?,?,?,?,?,?,?)`, [req.auth!.userId, 'STUDENT_IMPORT.DUPLICATE_NIS_REVIEW_REQUIRED', 'import_batch', String(b.data), JSON.stringify({ duplicateNis }), ip || null, ua || null]);
      await conn.commit();
      return void res.status(409).json({ error: 'DUPLICATE_OFFICIAL_NIS_REQUIRES_REVIEW', duplicateNis });
    }

    const [bad]: any = await conn.query(`SELECT COUNT(*) n FROM import_student_rows r WHERE r.batch_id=? AND (r.source_status IS NULL OR r.source_status NOT IN('AKTIF','BOYONG') OR COALESCE(r.reviewed_nis,r.source_nis) IS NULL OR TRIM(COALESCE(r.reviewed_nis,r.source_nis))='' OR TRIM(r.source_name)='' OR r.source_class IS NULL OR TRIM(r.source_class)='' OR (r.source_status='AKTIF' AND r.match_status NOT IN('RESOLVED_MATCH','RESOLVED_NEW','APPROVED')) OR (r.source_status='BOYONG' AND r.match_status NOT IN('RESOLVED_MATCH','RESOLVED_HISTORICAL','APPROVED')) OR (SELECT COUNT(*) FROM classes c WHERE UPPER(TRIM(c.code))=UPPER(TRIM(r.source_class)) AND c.active=1)<>1)`, [b.data]);
    if (Number(bad[0].n) > 0) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_REVIEW_INCOMPLETE' }); }
    const [years]:any=await conn.query('SELECT id FROM academic_years WHERE is_active=1 FOR UPDATE');
    if(years.length!==1){await conn.rollback();return void res.status(409).json({error:'EXACTLY_ONE_ACTIVE_ACADEMIC_YEAR_REQUIRED'})}
    const [result]: any = await conn.execute(`UPDATE import_batches SET academic_year_id=?,status='APPROVED',approved_by=?,approved_at=NOW() WHERE id=? AND status IN('STAGED','REVIEW_REQUIRED')`, [years[0].id,req.auth!.userId, b.data]);
    if (result.affectedRows !== 1) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_STATE_CHANGED' }); }
    await writeAudit(req,{action:'STUDENT_IMPORT.MUTATED',entityType:'import_batch',entityId:b.data,metadata:{path:req.path}},conn);
    await conn.commit(); res.status(204).end();
  } catch (e) { await conn.rollback(); next(e); } finally { conn.release(); }
});

studentImportRouter.post('/:batchId/bulk-review/preview', requireSuperAdmin, async (req, res, next) => {
  const b = id.safeParse(req.params.batchId), selection = bulkReview.safeParse(req.body);
  if (!b.success) return void res.status(400).json({ error: 'INVALID_IMPORT_BATCH' });
  if (!selection.success) return void res.status(400).json({ error: 'INVALID_BULK_REVIEW_SELECTION' });
  try {
    const [batches]: any = await db.query(`SELECT status FROM import_batches WHERE id=? AND source_type='WORD_STUDENT_MASTER' LIMIT 1`, [b.data]);
    if (!batches[0]) return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' });
    if (!['STAGED', 'REVIEW_REQUIRED'].includes(batches[0].status)) return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_REVIEWABLE' });
    const { rows, sourceStatus } = await validateBulkReviewSelection(db, b.data, selection.data);
    const classCounts = rows.reduce((counts: Record<string, number>, row: any) => {
      const key = String(row.source_class).trim();
      counts[key] = (counts[key] ?? 0) + 1;
      return counts;
    }, {});
    res.json({ batchId: b.data, decision: selection.data.decision, sourceStatus, rowCount: rows.length, rowIds: selection.data.rowIds, classCounts });
  } catch (e: any) {
    if (e?.status === 409 && String(e.message).startsWith('BULK_')) return void res.status(409).json({ error: e.message });
    next(e);
  }
});

studentImportRouter.post('/:batchId/bulk-review', requireSuperAdmin, async (req, res, next) => {
  const b = id.safeParse(req.params.batchId), selection = bulkReview.safeParse(req.body);
  if (!b.success) return void res.status(400).json({ error: 'INVALID_IMPORT_BATCH' });
  if (!selection.success) return void res.status(400).json({ error: 'INVALID_BULK_REVIEW_SELECTION' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batches]: any = await conn.query(`SELECT status FROM import_batches WHERE id=? AND source_type='WORD_STUDENT_MASTER' LIMIT 1 FOR UPDATE`, [b.data]);
    if (!batches[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (!['STAGED', 'REVIEW_REQUIRED'].includes(batches[0].status)) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_REVIEWABLE' }); }
    const { rows, sourceStatus } = await validateBulkReviewSelection(conn, b.data, selection.data, true);
    const matchStatus = selection.data.decision === 'CREATE_NEW' ? 'RESOLVED_NEW' : 'RESOLVED_HISTORICAL';
    for (const row of rows) {
      await conn.execute(`UPDATE import_student_rows SET match_status=?,review_note=?,reviewed_by=?,reviewed_at=NOW() WHERE id=? AND batch_id=?`, [matchStatus, selection.data.note ?? null, req.auth!.userId, row.id, b.data]);
    }
    await conn.execute(`UPDATE import_batches SET status='REVIEW_REQUIRED' WHERE id=? AND status='STAGED'`, [b.data]);
    const rowIds = rows.map((row: any) => Number(row.id));
    await writeAudit(req, { action: 'STUDENT_IMPORT.BULK_REVIEW_RESOLVED', entityType: 'import_batch', entityId: b.data, metadata: { batchId: b.data, decision: selection.data.decision, rowCount: rows.length, rowIds, sourceStatus } }, conn);
    await writeAudit(req, { action: 'STUDENT_IMPORT.MUTATED', entityType: 'import_batch', entityId: b.data, metadata: { path: req.path } }, conn);
    await conn.commit();
    res.json({ batchId: b.data, decision: selection.data.decision, sourceStatus, rowCount: rows.length, rowIds, matchStatus });
  } catch (e: any) {
    await conn.rollback();
    if (e?.status === 409 && String(e.message).startsWith('BULK_')) return void res.status(409).json({ error: e.message });
    next(e);
  } finally { conn.release(); }
});

studentImportRouter.post('/:batchId/apply', requireSuperAdmin, async (req, res, next) => {
  const b = id.safeParse(req.params.batchId);
  if (!b.success) return void res.status(400).json({ error: 'INVALID_IMPORT_BATCH' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batch]: any = await conn.query(`SELECT id,status,academic_year_id FROM import_batches WHERE id=? AND source_type='WORD_STUDENT_MASTER' FOR UPDATE`, [b.data]);
    if (!batch[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (batch[0].status !== 'APPROVED') { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_APPROVED' }); }
    const [years]: any = await conn.query(`SELECT id FROM academic_years WHERE is_active=1 FOR UPDATE`);
    if (years.length !== 1) throw new Error('EXACTLY_ONE_ACTIVE_ACADEMIC_YEAR_REQUIRED');
    const academicYearId = years[0].id;
    if(Number(batch[0].academic_year_id)!==Number(academicYearId))throw new Error('APPROVED_ACADEMIC_YEAR_CHANGED');
    const [rows]: any = await conn.query(`SELECT id,source_nis,reviewed_nis,source_name,source_class,source_status,birth_place,birth_date,matched_student_id,match_status FROM import_student_rows WHERE batch_id=? ORDER BY source_row_number FOR UPDATE`, [b.data]);
    if (!rows.length) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_EMPTY' }); }
    const seenNis = new Set<string>();
    const historicalSourceRows: number[] = [];
    for (const r of rows) {
      const nis = String(r.reviewed_nis ?? r.source_nis ?? '').trim(), name = String(r.source_name ?? '').trim(), sourceClass = String(r.source_class ?? '').trim();
      if (!nis || !name || !sourceClass) throw new Error('INVALID_OFFICIAL_WORD_ROW');
      if (seenNis.has(nis)) throw new Error('DUPLICATE_OFFICIAL_NIS_REQUIRES_REVIEW');
      seenNis.add(nis);
      const sourceStatus = String(r.source_status ?? '').trim().toUpperCase();
      if (!['AKTIF', 'BOYONG'].includes(sourceStatus)) throw new Error('INVALID_SOURCE_STATUS');
      if (sourceStatus === 'BOYONG') {
        const [classes]: any = await conn.query(`SELECT id FROM classes WHERE UPPER(TRIM(code))=UPPER(?) AND active=1 FOR UPDATE`, [sourceClass]);
        if (classes.length !== 1) throw new Error('OFFICIAL_CLASS_REQUIRES_REVIEW');
        if (r.match_status === 'RESOLVED_HISTORICAL') {
          if (r.matched_student_id) throw new Error('HISTORICAL_ROW_MUST_NOT_HAVE_MATCHED_STUDENT');
          const [existing]: any = await conn.query(`SELECT id FROM students WHERE nis=? FOR UPDATE`, [nis]);
          if (existing[0]) throw new Error('BOYONG_NIS_ALREADY_EXISTS_REQUIRES_MATCH');
          const [created]: any = await conn.execute(`INSERT INTO students(nis,name,birth_place,birth_date,status,source_reference,official_source_batch_id) VALUES(?,?,?,?, 'BOYONG','WORD_STUDENT_MASTER',?)`, [nis, name, r.birth_place ?? null, r.birth_date ?? null, b.data]);
          await conn.execute(`UPDATE import_student_rows SET matched_student_id=?,match_status='APPROVED' WHERE id=?`, [created.insertId, r.id]);
          historicalSourceRows.push(Number(r.source_row_number));
          continue;
        }
        if (!r.matched_student_id || !['RESOLVED_MATCH', 'APPROVED'].includes(r.match_status)) throw new Error('BOYONG_ROW_REQUIRES_HISTORICAL_OR_EXISTING_MATCH');
        const [student]: any = await conn.query(`SELECT id FROM students WHERE id=? FOR UPDATE`, [r.matched_student_id]);
        if (!student[0]) throw new Error('MATCHED_STUDENT_NOT_FOUND');
        await conn.execute(`UPDATE import_student_rows SET matched_student_id=?,match_status='APPROVED' WHERE id=?`, [r.matched_student_id, r.id]);
        continue;
      }
      if (!['RESOLVED_MATCH', 'RESOLVED_NEW', 'APPROVED'].includes(r.match_status)) throw new Error('IMPORT_ROW_REQUIRES_REVIEW');
      const [classes]: any = await conn.query(`SELECT id FROM classes WHERE UPPER(TRIM(code))=UPPER(?) AND active=1`, [sourceClass]);
      if (classes.length !== 1) throw new Error('OFFICIAL_CLASS_REQUIRES_REVIEW');
      const classId = classes[0].id;
      let studentId = r.matched_student_id;
      if (r.match_status === 'RESOLVED_NEW' && studentId) throw new Error('RESOLVED_NEW_MUST_NOT_HAVE_STUDENT');
      if (studentId) {
        const [s]: any = await conn.query(`SELECT id,nis,status FROM students WHERE id=? FOR UPDATE`, [studentId]);
        if (!s[0]) throw new Error('MATCHED_STUDENT_NOT_FOUND');
        if (s[0].status !== 'ACTIVE') throw new Error('STUDENT_REACTIVATION_REQUIRES_REVIEW');
        const [nisOwner]: any = await conn.query(`SELECT id FROM students WHERE nis=? AND id<>? LIMIT 1 FOR UPDATE`, [nis, studentId]);
        if (nisOwner[0]) throw new Error('OFFICIAL_NIS_CONFLICT');
        await conn.execute(`UPDATE students SET nis=?,name=?,birth_place=?,birth_date=?,source_reference='WORD_STUDENT_MASTER',official_source_batch_id=? WHERE id=?`, [nis, name, r.birth_place ?? null, r.birth_date ?? null, b.data, studentId]);
      } else {
        const [existing]: any = await conn.query(`SELECT id,status FROM students WHERE nis=? FOR UPDATE`, [nis]);
        if (existing[0]) {
          if (r.match_status === 'RESOLVED_NEW') throw new Error('RESOLVED_NEW_NIS_ALREADY_EXISTS');
          studentId = existing[0].id;
          if (existing[0].status !== 'ACTIVE') throw new Error('STUDENT_REACTIVATION_REQUIRES_REVIEW');
          await conn.execute(`UPDATE students SET name=?,birth_place=?,birth_date=?,source_reference='WORD_STUDENT_MASTER',official_source_batch_id=? WHERE id=?`, [name, r.birth_place ?? null, r.birth_date ?? null, b.data, studentId]);
        } else {
          const [x]: any = await conn.execute(`INSERT INTO students(nis,name,birth_place,birth_date,status,source_reference,official_source_batch_id) VALUES(?,?,?,?,'ACTIVE','WORD_STUDENT_MASTER',?)`, [nis, name, r.birth_place ?? null, r.birth_date ?? null, b.data]);
          studentId = x.insertId;
        }
      }
      const [enrollments]: any = await conn.query(`SELECT id,class_id,status,ended_on FROM student_enrollments WHERE student_id=? AND academic_year_id=? FOR UPDATE`, [studentId, academicYearId]);
      const enrollment = enrollments[0];
      if (enrollment) {
        if (enrollment.status !== 'ACTIVE') throw new Error('ENROLLMENT_STATUS_REQUIRES_REVIEW');
        if (enrollment.ended_on != null) throw new Error('ENDED_ACTIVE_ENROLLMENT_REQUIRES_REVIEW');
        if (enrollment.class_id !== classId) throw new Error('ACTIVE_ENROLLMENT_CLASS_CONFLICT');
      } else await conn.execute(`INSERT INTO student_enrollments(student_id,class_id,academic_year_id,status,started_on,ended_on) VALUES(?,?,?,'ACTIVE',NULL,NULL)`, [studentId, classId, academicYearId]);
      await conn.execute(`UPDATE import_student_rows SET matched_student_id=?,match_status='APPROVED' WHERE id=?`, [studentId, r.id]);
    }
    const [result]: any = await conn.execute(`UPDATE import_batches SET status='IMPORTED' WHERE id=? AND status='APPROVED'`, [b.data]);
    if (result.affectedRows !== 1) throw new Error('IMPORT_BATCH_STATE_CHANGED');
    if (historicalSourceRows.length) await writeAudit(req, { action: 'STUDENT_IMPORT.HISTORICAL_CREATED', entityType: 'import_batch', entityId: b.data, metadata: { rowCount: historicalSourceRows.length, sourceRowNumbers: historicalSourceRows } }, conn);
    await writeAudit(req,{action:'STUDENT_IMPORT.MUTATED',entityType:'import_batch',entityId:b.data,metadata:{path:req.path}},conn);
    await conn.commit(); res.status(204).end();
  } catch (e: any) {
    await conn.rollback();
    if (['APPROVED_ACADEMIC_YEAR_CHANGED','INVALID_OFFICIAL_WORD_ROW','INVALID_SOURCE_STATUS','MATCHED_STUDENT_NOT_FOUND','OFFICIAL_NIS_CONFLICT','OFFICIAL_CLASS_REQUIRES_REVIEW','EXACTLY_ONE_ACTIVE_ACADEMIC_YEAR_REQUIRED','ACTIVE_ENROLLMENT_CLASS_CONFLICT','IMPORT_BATCH_STATE_CHANGED','STUDENT_REACTIVATION_REQUIRES_REVIEW','ENROLLMENT_STATUS_REQUIRES_REVIEW','ENDED_ACTIVE_ENROLLMENT_REQUIRES_REVIEW','IMPORT_ROW_REQUIRES_REVIEW','RESOLVED_NEW_MUST_NOT_HAVE_STUDENT','RESOLVED_NEW_NIS_ALREADY_EXISTS','DUPLICATE_OFFICIAL_NIS_REQUIRES_REVIEW','HISTORICAL_ROW_MUST_NOT_HAVE_MATCHED_STUDENT','BOYONG_NIS_ALREADY_EXISTS_REQUIRES_MATCH'].includes(e?.message)) return void res.status(409).json({ error: e.message });
    if (e?.code === 'ER_DUP_ENTRY') return void res.status(409).json({ error: 'OFFICIAL_NIS_OR_ENROLLMENT_CONFLICT' });
    next(e);
  } finally { conn.release(); }
});
