import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';
import { parseStudentRosterWorkbook } from './student-roster-xlsx.js';

async function makeWorkbook(headers: string[], rows: unknown[][]): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Synthetic');
  worksheet.addRow(headers);
  for (const row of rows) worksheet.addRow(row);
  return Buffer.from(await workbook.xlsx.writeBuffer());
}

describe('parseStudentRosterWorkbook', () => {
  it('parses strict headers, preserves row numbers and text NIS', async () => {
    const buffer = await makeWorkbook([' status ', 'Nama', 'NIS', 'Kelas'], [
      ['aktif', 'Synthetic Active', '000123', 'A1'],
      ['Boyong', 'Synthetic Historical', '000124', 'A1'],
    ]);
    assert.deepEqual(await parseStudentRosterWorkbook(buffer), [
      { sourceRowNumber: 2, sourceNis: '000123', sourceName: 'Synthetic Active', sourceClass: 'A1', sourceStatus: 'AKTIF', validationErrorCode: null },
      { sourceRowNumber: 3, sourceNis: '000124', sourceName: 'Synthetic Historical', sourceClass: 'A1', sourceStatus: 'BOYONG', validationErrorCode: null },
    ]);
  });

  it('preserves header normalization and rich-text cell behavior', async () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Synthetic');
    worksheet.addRow([' ＮＩＳ ', 'Ｎａｍａ', 'Kelas', 'Status']);
    worksheet.addRow(['000126', { richText: [{ text: 'Synthetic' }, { text: ' Student' }] }, 'A1', 'Aktif']);
    const rows = await parseStudentRosterWorkbook(Buffer.from(await workbook.xlsx.writeBuffer()));
    assert.equal(rows[0]?.sourceNis, '000126');
    assert.equal(rows[0]?.sourceName, 'Synthetic Student');
    assert.equal(rows[0]?.validationErrorCode, null);
  });

  it('stages invalid cells as row validation errors and rejects numeric NIS', async () => {
    const buffer = await makeWorkbook(['NIS', 'Nama', 'Kelas', 'Status'], [
      [123, 'Synthetic Numeric NIS', 'A1', 'Aktif'],
      ['000125', '', '', 'Tidak diketahui'],
    ]);
    const rows = await parseStudentRosterWorkbook(buffer);
    assert.equal(rows[0]?.validationErrorCode, 'NIS_REQUIRED_TEXT');
    assert.equal(rows[1]?.validationErrorCode, 'NAME_REQUIRED|CLASS_REQUIRED|STATUS_INVALID');
  });

  it('rejects unexpected and duplicate headers', async () => {
    await assert.rejects(parseStudentRosterWorkbook(await makeWorkbook(['NIS', 'Nama', 'Kelas', 'Catatan'], [])), /ROSTER_HEADER_INVALID/);
    await assert.rejects(parseStudentRosterWorkbook(await makeWorkbook(['NIS', 'NIS', 'Kelas', 'Status'], [])), /ROSTER_HEADER_INVALID/);
  });

  it('rejects malformed XLSX bytes', async () => {
    await assert.rejects(parseStudentRosterWorkbook(Buffer.from('not an xlsx')), /INVALID_ROSTER_XLSX/);
  });
});
