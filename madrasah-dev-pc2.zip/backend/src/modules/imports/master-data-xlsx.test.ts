import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';
import { createMasterDataTemplate, parseMasterDataWorkbook } from './master-data-xlsx.js';

async function makeWorkbook(headers: string[], rows: unknown[][]): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Synthetic');
  worksheet.addRow(headers);
  for (const row of rows) worksheet.addRow(row);
  return Buffer.from(await workbook.xlsx.writeBuffer());
}

describe('parseMasterDataWorkbook', () => {
  it('parses teacher identifiers as text and normalizes supported status values', async () => {
    const rows = await parseMasterDataWorkbook(await makeWorkbook(
      ['Status', 'Name', 'NIP_or_Identifier', 'Code'],
      [['active', 'Synthetic Teacher', '0000123', 'G-01']],
    ), 'TEACHERS');
    assert.deepEqual(rows, [{
      sourceRowNumber: 2,
      sourceCode: 'G-01',
      sourceIdentifier: '0000123',
      sourceName: 'Synthetic Teacher',
      sourceStatus: 'ACTIVE',
      sourceBookName: null,
      sourceActive: null,
      validationErrorCode: null,
    }]);
  });

  it('parses subject status and optional book name', async () => {
    const rows = await parseMasterDataWorkbook(await makeWorkbook(
      ['Code', 'Name', 'Book_Name', 'Active'],
      [['S-01', 'Synthetic Subject', 'Book One', 'FALSE']],
    ), 'SUBJECTS');
    assert.equal(rows[0]?.sourceActive, false);
    assert.equal(rows[0]?.sourceBookName, 'Book One');
    assert.equal(rows[0]?.validationErrorCode, null);
  });

  it('reports required-field and non-text identifier errors per row', async () => {
    const rows = await parseMasterDataWorkbook(await makeWorkbook(
      ['Code', 'NIP_or_Identifier', 'Name', 'Status'],
      [[null, 123, 'Synthetic Teacher', 'UNKNOWN'], ['G-02', null, '', 'ACTIVE']],
    ), 'TEACHERS');
    assert.equal(rows[0]?.sourceIdentifier, null);
    assert.equal(rows[0]?.validationErrorCode, 'IDENTIFIER_REQUIRED_TEXT|TEACHER_IDENTIFIER_REQUIRED|STATUS_INVALID');
    assert.equal(rows[1]?.validationErrorCode, 'NAME_REQUIRED');
  });

  it('rejects numeric optional identity and book fields instead of silently dropping them', async () => {
    const teachers = await parseMasterDataWorkbook(await makeWorkbook(
      ['Code', 'NIP_or_Identifier', 'Name', 'Status'],
      [[123, 'NIP-01', 'Synthetic Teacher', 'ACTIVE']],
    ), 'TEACHERS');
    assert.equal(teachers[0]?.validationErrorCode, 'CODE_REQUIRED_TEXT');

    const subjects = await parseMasterDataWorkbook(await makeWorkbook(
      ['Code', 'Name', 'Book_Name', 'Active'],
      [[123, 'Synthetic Subject', 456, 'TRUE']],
    ), 'SUBJECTS');
    assert.equal(subjects[0]?.validationErrorCode, 'CODE_REQUIRED_TEXT|BOOK_NAME_REQUIRED_TEXT');
  });

  it('marks repeated teacher identity and duplicate subject code or name', async () => {
    const teachers = await parseMasterDataWorkbook(await makeWorkbook(
      ['Code', 'NIP_or_Identifier', 'Name', 'Status'],
      [['G-01', null, 'Synthetic One', 'ACTIVE'], ['g-01', null, 'Synthetic Two', 'ACTIVE']],
    ), 'TEACHERS');
    assert.equal(teachers[0]?.validationErrorCode, 'DUPLICATE_IDENTITY_IN_SOURCE');
    assert.equal(teachers[1]?.validationErrorCode, 'DUPLICATE_IDENTITY_IN_SOURCE');

    const subjects = await parseMasterDataWorkbook(await makeWorkbook(
      ['Code', 'Name', 'Book_Name', 'Active'],
      [['S-01', 'Synthetic Subject', '', 'TRUE'], ['S-02', ' synthetic  subject ', '', 'TRUE']],
    ), 'SUBJECTS');
    assert.equal(subjects[0]?.validationErrorCode, 'DUPLICATE_IDENTITY_IN_SOURCE');
    assert.equal(subjects[1]?.validationErrorCode, 'DUPLICATE_IDENTITY_IN_SOURCE');
  });

  it('rejects missing/duplicate headers, empty data and malformed workbook bytes', async () => {
    await assert.rejects(
      parseMasterDataWorkbook(await makeWorkbook(['Code', 'Name', 'Book_Name', 'Notes'], []), 'SUBJECTS'),
      /MASTER_DATA_HEADER_INVALID/,
    );
    await assert.rejects(
      parseMasterDataWorkbook(await makeWorkbook(['Code', 'Name', 'Book_Name', 'Active'], []), 'SUBJECTS'),
      /MASTER_DATA_HAS_NO_DATA_ROWS/,
    );
    await assert.rejects(
      parseMasterDataWorkbook(Buffer.from('not an xlsx'), 'TEACHERS'),
      /INVALID_MASTER_DATA_XLSX/,
    );
  });

  it('creates XLSX templates with strict headers and status validation', async () => {
    const teachers = new ExcelJS.Workbook();
    await teachers.xlsx.load(await createMasterDataTemplate('TEACHERS') as never);
    assert.deepEqual(
      Array.from({ length: 4 }, (_, index) => teachers.getWorksheet('Teachers')?.getCell(1, index + 1).value),
      ['Code', 'NIP_or_Identifier', 'Name', 'Status'],
    );
    assert.deepEqual(teachers.getWorksheet('Teachers')?.getCell('D2').dataValidation.formulae, ['"ACTIVE,INACTIVE"']);

    const subjects = new ExcelJS.Workbook();
    await subjects.xlsx.load(await createMasterDataTemplate('SUBJECTS') as never);
    assert.deepEqual(
      Array.from({ length: 4 }, (_, index) => subjects.getWorksheet('Subjects')?.getCell(1, index + 1).value),
      ['Code', 'Name', 'Book_Name', 'Active'],
    );
    assert.deepEqual(subjects.getWorksheet('Subjects')?.getCell('D2').dataValidation.formulae, ['"TRUE,FALSE"']);
  });
});
