import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import yazl from 'yazl';
import { extractWordStudentRowsFromDocx, parseWordStudentDocumentXml } from './word-student-docx.js';

const WORD_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';

function cell(text: string): string {
  return `<w:tc><w:p><w:r><w:t>${text}</w:t></w:r></w:p></w:tc>`;
}

function row(cells: string[]): string {
  return `<w:tr>${cells.map(cell).join('')}</w:tr>`;
}

function documentXml(rows: string[]): string {
  return `<w:document xmlns:w="${WORD_NS}"><w:body><w:tbl>${rows.join('')}</w:tbl></w:body></w:document>`;
}

function createSyntheticDocx(xml: string): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const archive = new yazl.ZipFile();
    const chunks: Buffer[] = [];
    archive.outputStream.on('data', (chunk: Buffer) => chunks.push(chunk));
    archive.outputStream.on('end', () => resolve(Buffer.concat(chunks)));
    archive.outputStream.on('error', reject);
    archive.addBuffer(Buffer.from(xml), 'word/document.xml');
    archive.addBuffer(Buffer.from('<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>'), '[Content_Types].xml');
    archive.end();
  });
}

const HEADER_ROW = row(['Kelas', 'NIS', 'Nama', 'Keterangan']);

describe('parseWordStudentDocumentXml', () => {
  it('parses a valid synthetic DOCX and preserves duplicate NIS for review', async () => {
    const xml = documentXml([
      HEADER_ROW,
      row(['1A', '26050', 'Muhammad Nail Attuqo', 'Aktif']),
      row(['1B', '26050', 'Ahmad', 'Boyong']),
    ]);
    const rows = await extractWordStudentRowsFromDocx(await createSyntheticDocx(xml));
    assert.equal(rows.length, 2);
    assert.deepEqual(rows[0], {
      sourceRowNumber: 1,
      sourceClass: '1A',
      sourceNis: '26050',
      sourceName: 'Muhammad Nail Attuqo',
      sourceStatus: 'AKTIF',
    });
    assert.deepEqual(rows[1], {
      sourceRowNumber: 2,
      sourceClass: '1B',
      sourceNis: '26050',
      sourceName: 'Ahmad',
      sourceStatus: 'BOYONG',
    });
  });

  it('recognizes the exact extracted header only', () => {
    const badHeader = documentXml([row(['Kelas', 'NIS', 'Nama', 'Catatan'])]);
    const extraColumn = documentXml([row(['Kelas', 'NIS', 'Nama', 'Keterangan', 'Catatan'])]);
    assert.throws(() => parseWordStudentDocumentXml(badHeader), /HEADER_INVALID/);
    assert.throws(() => parseWordStudentDocumentXml(extraColumn), /HEADER_INVALID/);
  });

  it('combines multiple text runs and decodes XML entities', () => {
    const xml = documentXml([
      HEADER_ROW,
      `<w:tr>${cell('<w:p><w:r><w:t>1</w:t></w:r><w:r><w:t>A</w:t></w:r></w:p>')}<w:tc><w:p><w:r><w:t>26060</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Ali &amp; Budi</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Aktif</w:t></w:r></w:p></w:tc></w:tr>`,
    ]);
    assert.deepEqual(parseWordStudentDocumentXml(xml), [{
      sourceRowNumber: 1,
      sourceClass: '1A',
      sourceNis: '26060',
      sourceName: 'Ali & Budi',
      sourceStatus: 'AKTIF',
    }]);
  });

  it('rejects missing fields, invalid status, and malformed XML', () => {
    const missingField = documentXml([HEADER_ROW, row(['1A', '26061', '', 'Aktif'])]);
    const badStatus = documentXml([HEADER_ROW, row(['1A', '26062', 'Ali', 'Aktif sekali'])]);
    assert.throws(() => parseWordStudentDocumentXml(missingField), /ROW_INVALID/);
    assert.throws(() => parseWordStudentDocumentXml(badStatus), /STATUS_INVALID/);
    assert.throws(() => parseWordStudentDocumentXml('<w:document><w:body>'), /XML_INVALID/);
  });

  it('rejects malformed DOCX archives', async () => {
    await assert.rejects(extractWordStudentRowsFromDocx(Buffer.from('not a zip')), /INVALID_WORD_DOCX/);
  });
});
