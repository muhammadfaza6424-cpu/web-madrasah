import ExcelJS from 'exceljs';
import { headerKey, textCell } from './xlsx-cell-helpers.js';

export type GradeSourceRow = {
  sourceRowNumber: number;
  sourceNis: string;
  sourceName: string | null;
  sourceClass: string | null;
  sourceSubject: string;
  semester: 'GANJIL' | 'GENAP';
  score: number;
  notes: string | null;
};

const REQUIRED_HEADERS = ['nis', 'nama', 'kelas', 'matapelajaran', 'semester', 'nilai', 'catatan'];

function fail(code: string): never {
  throw Object.assign(new Error(code), { status: 400, code });
}

function scoreValue(value: ExcelJS.CellValue): number | null {
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value === 'string' && /^\d+(?:\.\d{1,2})?$/.test(value.trim())) return Number(value.trim());
  return null;
}

export async function parseGradeWorkbook(bytes: Buffer): Promise<GradeSourceRow[]> {
  let workbook: ExcelJS.Workbook;
  try {
    workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(bytes as never);
  } catch {
    return fail('INVALID_GRADE_XLSX');
  }
  if (workbook.worksheets.length !== 1) return fail('GRADE_WORKBOOK_MUST_HAVE_ONE_SHEET');
  const worksheet = workbook.worksheets[0];
  if (!worksheet || worksheet.rowCount < 1) return fail('GRADE_HEADER_INVALID');
  const headerRow = worksheet.getRow(1);
  const headers = Array.from({ length: headerRow.cellCount }, (_, index) => headerKey(headerRow.getCell(index + 1).value));
  if (headers.length !== REQUIRED_HEADERS.length ||
      new Set(headers).size !== REQUIRED_HEADERS.length ||
      REQUIRED_HEADERS.some(header => !headers.includes(header))) {
    return fail('GRADE_HEADER_INVALID');
  }
  const columnByHeader = new Map(headers.map((header, index) => [header, index + 1]));
  const rows: GradeSourceRow[] = [];

  for (let rowNumber = 2; rowNumber <= worksheet.rowCount; rowNumber++) {
    const row = worksheet.getRow(rowNumber);
    const cells = Object.fromEntries(
      REQUIRED_HEADERS.map(header => [header, row.getCell(columnByHeader.get(header)!).value]),
    );
    if (Object.values(cells).every(value => value == null || value === '')) continue;

    const nisCell = row.getCell(columnByHeader.get('nis')!);
    const sourceNis = typeof nisCell.value === 'string' ? textCell(nisCell) : null;
    const sourceName = textCell(row.getCell(columnByHeader.get('nama')!));
    const sourceClass = textCell(row.getCell(columnByHeader.get('kelas')!));
    const sourceSubject = textCell(row.getCell(columnByHeader.get('matapelajaran')!));
    const semesterText = textCell(row.getCell(columnByHeader.get('semester')!))?.toUpperCase();
    const score = scoreValue(row.getCell(columnByHeader.get('nilai')!).value);
    const notes = textCell(row.getCell(columnByHeader.get('catatan')!));
    if (!sourceNis || sourceNis.length > 100 ||
        (sourceName && sourceName.length > 255) ||
        (sourceClass && sourceClass.length > 50) ||
        !sourceSubject || sourceSubject.length > 150 ||
        (semesterText !== 'GANJIL' && semesterText !== 'GENAP') ||
        score === null || score < 0 || score > 100 ||
        (notes && notes.length > 10000)) {
      return fail('GRADE_ROW_INVALID');
    }
    rows.push({
      sourceRowNumber: rowNumber,
      sourceNis,
      sourceName,
      sourceClass,
      sourceSubject,
      semester: semesterText,
      score,
      notes,
    });
  }
  if (!rows.length) return fail('GRADE_HAS_NO_DATA_ROWS');
  return rows;
}

export async function createGradeTemplate(): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Grades');
  worksheet.columns = [
    { header: 'NIS', key: 'nis', width: 20 },
    { header: 'Nama', key: 'nama', width: 32 },
    { header: 'Kelas', key: 'kelas', width: 16 },
    { header: 'Mata_Pelajaran', key: 'mata_pelajaran', width: 28 },
    { header: 'Semester', key: 'semester', width: 16 },
    { header: 'Nilai', key: 'nilai', width: 14 },
    { header: 'Catatan', key: 'catatan', width: 40 },
  ];
  worksheet.views = [{ state: 'frozen', ySplit: 1 }];
  worksheet.autoFilter = { from: 'A1', to: 'G1' };
  worksheet.getRow(1).font = { bold: true };
  worksheet.getColumn(1).numFmt = '@';
  worksheet.getColumn(7).numFmt = '@';
  for (let rowNumber = 2; rowNumber <= 501; rowNumber++) {
    worksheet.getCell(`E${rowNumber}`).dataValidation = {
      type: 'list',
      allowBlank: false,
      formulae: ['"GANJIL,GENAP"'],
    };
    worksheet.getCell(`F${rowNumber}`).dataValidation = {
      type: 'decimal',
      operator: 'between',
      allowBlank: false,
      formulae: [0, 100],
    };
  }
  return Buffer.from(await workbook.xlsx.writeBuffer());
}
