import type { PoolConnection } from 'mysql2/promise';
import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { db } from '../../config/db.js';
import { requireAuthentication } from '../../middleware/authentication.js';
import { requirePermission, requireSuperAdmin } from '../../middleware/authorization.js';
import { writeAudit } from '../audit/audit.service.js';
import { digest, validOffice } from '../storage/integrity.js';
import { createFinalExamTemplate, parseFinalExamWorkbook, type FinalExamSourceRow } from './final-exam-xlsx.js';

export const finalExamImportRouter = Router();
finalExamImportRouter.use(requireAuthentication, requirePermission('certificates.import.manage'), requireSuperAdmin);

const id = z.coerce.number().int().positive();
const upload = multer({ storage: multer.memoryStorage(), limits: { files: 1, fileSize: 10 * 1024 * 1024 } });
const stageInput = z.object({ academicYearId: z.coerce.number().int().positive() }).strict();
const approval = z.object({ academicYearId: z.number().int().positive() }).strict();
const resolution = z.discriminatedUnion('decision', [
  z.object({
    decision: z.literal('MATCH'),
    studentId: z.number().int().positive(),
    note: z.string().trim().min(1).max(500).nullable().optional(),
  }).strict(),
  z.object({
    decision: z.literal('CLEAR'),
    note: z.string().trim().max(500).nullable().optional(),
  }).strict(),
]);
const unresolvedSql = `(r.matched_student_id IS NULL OR r.match_status IN('UNMATCHED','AMBIGUOUS'))`;

finalExamImportRouter.get('/template', async (_req, res, next) => {
  try {
    const template = await createFinalExamTemplate();
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="final-exam-template.xlsx"');
    res.send(template);
  } catch (error) {
    next(error);
  }
});

finalExamImportRouter.post('/stage', upload.single('file'), async (req, res, next) => {
  try {
    const input = stageInput.safeParse(req.body);
    if (!input.success) return void res.status(400).json({ error: 'ACADEMIC_YEAR_REQUIRED_FOR_FINAL_EXAM_IMPORT' });
    if (!req.file) return void res.status(400).json({ error: 'FILE_REQUIRED' });
    if (!req.file.originalname.toLowerCase().endsWith('.xlsx') ||
        req.file.mimetype !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
        !(await validOffice(req.file.buffer, 'xl'))) {
      return void res.status(400).json({ error: 'INVALID_FINAL_EXAM_XLSX' });
    }
    const rows = await parseFinalExamWorkbook(req.file.buffer);
    const checksum = digest(req.file.buffer);
    const original = String(req.file.originalname || 'final-exam.xlsx').replace(/\\/g, '/');
    const sourceName = (original.split('/').pop() || 'final-exam.xlsx')
      .replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 255) || 'final-exam.xlsx';
    const conn = await db.getConnection();
    const lockName = `final-exam-import:${checksum.slice(0, 43)}`;
    let lockAcquired = false;
    try {
      const [locks]: any = await conn.query('SELECT GET_LOCK(?,10) acquired', [lockName]);
      lockAcquired = Number(locks[0]?.acquired) === 1;
      if (!lockAcquired) return void res.status(409).json({ error: 'IMPORT_SOURCE_STAGING_IN_PROGRESS' });
      await conn.beginTransaction();
      const [years]: any = await conn.query('SELECT id FROM academic_years WHERE id=? LIMIT 1 FOR UPDATE', [input.data.academicYearId]);
      if (!years[0]) {
        await conn.rollback();
        return void res.status(404).json({ error: 'ACADEMIC_YEAR_NOT_FOUND' });
      }
      const [existing]: any = await conn.query(
        `SELECT id FROM import_batches WHERE source_type='EXCEL_FINAL_EXAM' AND source_checksum=?
         AND status IN('STAGED','REVIEW_REQUIRED','APPROVED','IMPORTED') LIMIT 1 FOR UPDATE`,
        [checksum],
      );
      if (existing[0]) {
        await conn.rollback();
        return void res.status(409).json({ error: 'IMPORT_SOURCE_ALREADY_STAGED' });
      }
      const [insertBatch]: any = await conn.execute(
        `INSERT INTO import_batches(source_type,source_name,source_checksum,academic_year_id,status,created_by)
         VALUES('EXCEL_FINAL_EXAM',?,?,?,'STAGED',?)`,
        [sourceName, checksum, input.data.academicYearId, req.auth!.userId],
      );
      const batchId = Number(insertBatch.insertId);
      let matchedCount = 0;
      for (const row of rows) {
        const [matches]: any = await conn.query('SELECT id FROM students WHERE nis=? LIMIT 2', [row.sourceNis]);
        const studentId = matches.length === 1 ? Number(matches[0].id) : null;
        const matchStatus = studentId ? 'EXACT_OFFICIAL_NIS' : matches.length > 1 ? 'AMBIGUOUS' : 'UNMATCHED';
        const note = studentId ? null : matches.length > 1 ? 'OFFICIAL_NIS_NOT_UNIQUE' : 'OFFICIAL_NIS_NOT_FOUND';
        if (studentId) matchedCount++;
        await insertRow(conn, batchId, row, studentId, matchStatus, note);
      }
      await writeAudit(req, {
        action: 'FINAL_EXAM_IMPORT.STAGED',
        entityType: 'import_batch',
        entityId: batchId,
        metadata: { sourceName, checksum, academicYearId: input.data.academicYearId, rowCount: rows.length, matchedCount },
      }, conn);
      await conn.commit();
      res.status(201).json({ batchId, sourceName, checksum, rowCount: rows.length, matchedCount, unresolvedCount: rows.length - matchedCount });
    } catch (error) {
      await conn.rollback();
      throw error;
    } finally {
      if (lockAcquired) await conn.query('SELECT RELEASE_LOCK(?)', [lockName]);
      conn.release();
    }
  } catch (error: any) {
    if (error?.status === 400 && typeof error?.code === 'string' && error.code.startsWith('FINAL_EXAM_')) {
      return void res.status(400).json({ error: error.code });
    }
    next(error);
  }
});

finalExamImportRouter.get('/', async (_req, res, next) => {
  try {
    const [batches] = await db.query(
      `SELECT b.id,b.source_name,b.source_checksum,b.academic_year_id,b.status,b.created_at,b.approved_at,
       COUNT(r.id) total_rows,COALESCE(SUM(${unresolvedSql}),0) unresolved_rows,
       COALESCE(SUM(NOT ${unresolvedSql}),0) resolved_rows
       FROM import_batches b LEFT JOIN import_final_exam_rows r ON r.batch_id=b.id
       WHERE b.source_type='EXCEL_FINAL_EXAM' GROUP BY b.id ORDER BY b.created_at DESC,b.id DESC`,
    );
    res.json({ batches });
  } catch (error) {
    next(error);
  }
});

finalExamImportRouter.get('/:batchId/review', async (req, res, next) => {
  try {
    const batchId = id.safeParse(req.params.batchId);
    if (!batchId.success) return void res.status(400).json({ error: 'INVALID_IMPORT_BATCH' });
    const [batches]: any = await db.query(
      `SELECT id,source_type,source_name,source_checksum,academic_year_id,status,created_at,approved_at
       FROM import_batches WHERE id=? AND source_type='EXCEL_FINAL_EXAM' LIMIT 1`,
      [batchId.data],
    );
    if (!batches[0]) return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' });
    const [rows] = await db.query(
      `SELECT r.id,r.source_row_number,r.source_nis,r.source_name,r.source_class,r.subject_code,r.score,
       r.matched_student_id,r.match_status,r.review_note,s.nis official_nis,s.name official_name,c.code official_class
       FROM import_final_exam_rows r
       LEFT JOIN students s ON s.id=r.matched_student_id
       LEFT JOIN student_enrollments se ON se.student_id=s.id AND se.academic_year_id=?
       LEFT JOIN classes c ON c.id=se.class_id
       WHERE r.batch_id=? ORDER BY r.source_row_number`,
      [batches[0].academic_year_id, batchId.data],
    );
    const [candidates] = await db.query(
      `SELECT DISTINCT s.id,s.nis,s.name,c.code class_code
       FROM students s JOIN student_enrollments se ON se.student_id=s.id AND se.academic_year_id=?
       JOIN classes c ON c.id=se.class_id AND c.level=6
       WHERE se.status IN('ACTIVE','PROMOTED','GRADUATED')
       ORDER BY s.name,s.nis`,
      [batches[0].academic_year_id],
    );
    res.json({ batch: batches[0], rows, candidates });
  } catch (error) {
    next(error);
  }
});

async function insertRow(
  conn: PoolConnection,
  batchId: number,
  row: FinalExamSourceRow,
  studentId: number | null,
  matchStatus: string,
  reviewNote: string | null,
) {
  await conn.execute(
    `INSERT INTO import_final_exam_rows
     (batch_id,source_row_number,source_nis,source_name,source_class,subject_code,score,matched_student_id,match_status,review_note)
     VALUES(?,?,?,?,?,?,?,?,?,?)`,
    [batchId, row.sourceRowNumber, row.sourceNis, row.sourceName, row.sourceClass, row.subjectCode, row.score, studentId, matchStatus, reviewNote],
  );
}

async function assertFinalExamTarget(
  conn: PoolConnection,
  studentId: number,
  academicYearId: number,
  sourceClass: string | null,
  sourceNis: string,
  note: string | null,
) {
  const [students]: any = await conn.query(
    `SELECT s.id,s.nis,s.name,se.class_id,se.status enrollment_status,c.code class_code,c.level
     FROM students s
     LEFT JOIN student_enrollments se ON se.student_id=s.id AND se.academic_year_id=?
     LEFT JOIN classes c ON c.id=se.class_id
     WHERE s.id=? FOR UPDATE`,
    [academicYearId, studentId],
  );
  const student = students[0];
  if (!student) throw Object.assign(new Error('MATCHED_STUDENT_NOT_FOUND'), { status: 404 });
  if (!student.class_id || student.level !== 6 || !['ACTIVE', 'PROMOTED', 'GRADUATED'].includes(student.enrollment_status)) {
    throw Object.assign(new Error('FINAL_CLASS_ENROLLMENT_REQUIRED'), { status: 409 });
  }
  const expectedClass = String(sourceClass ?? '').trim().toUpperCase();
  const actualClass = String(student.class_code ?? '').trim().toUpperCase();
  if (expectedClass && expectedClass !== actualClass) {
    throw Object.assign(new Error('SOURCE_CLASS_FINAL_EXAM_ENROLLMENT_MISMATCH'), { status: 409 });
  }
  if (student.nis !== sourceNis && !note?.trim()) {
    throw Object.assign(new Error('IDENTITY_OVERRIDE_NOTE_REQUIRED'), { status: 400 });
  }
  const [certificates]: any = await conn.query(
    `SELECT id,status FROM certificates WHERE student_id=? AND academic_year_id=? AND status IN('ISSUED','VOID') FOR UPDATE`,
    [studentId, academicYearId],
  );
  if (certificates[0]) throw Object.assign(new Error('ISSUED_CERTIFICATE_IMMUTABLE'), { status: 409 });
  return student;
}

finalExamImportRouter.put('/:batchId/review/:rowId', async (req, res, next) => {
  const batchId = id.safeParse(req.params.batchId);
  const rowId = id.safeParse(req.params.rowId);
  const input = resolution.safeParse(req.body);
  if (!batchId.success || !rowId.success) return void res.status(400).json({ error: 'INVALID_IMPORT_REVIEW_ID' });
  if (!input.success) return void res.status(400).json({ error: 'INVALID_FINAL_EXAM_REVIEW_DECISION' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batches]: any = await conn.query(
      `SELECT id,status,academic_year_id FROM import_batches WHERE id=? AND source_type='EXCEL_FINAL_EXAM' FOR UPDATE`,
      [batchId.data],
    );
    if (!batches[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (!['STAGED', 'REVIEW_REQUIRED'].includes(batches[0].status)) {
      await conn.rollback();
      return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_REVIEWABLE' });
    }
    const [rows]: any = await conn.query(
      `SELECT id,source_nis,source_name,source_class,subject_code,matched_student_id,match_status,review_note
       FROM import_final_exam_rows WHERE id=? AND batch_id=? FOR UPDATE`,
      [rowId.data, batchId.data],
    );
    if (!rows[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_ROW_NOT_FOUND' }); }
    const current = rows[0];
    const before = { matchedStudentId: current.matched_student_id ?? null, matchStatus: current.match_status, note: current.review_note ?? null };
    let after: Record<string, unknown>;
    if (input.data.decision === 'CLEAR') {
      await conn.execute(
        `UPDATE import_final_exam_rows SET matched_student_id=NULL,match_status='UNMATCHED',review_note=? WHERE id=?`,
        [input.data.note ?? null, rowId.data],
      );
      after = { matchedStudentId: null, matchStatus: 'UNMATCHED', note: input.data.note ?? null };
    } else {
      const student = await assertFinalExamTarget(
        conn, input.data.studentId, Number(batches[0].academic_year_id),
        current.source_class, current.source_nis, input.data.note ?? null,
      );
      const [duplicates]: any = await conn.query(
        `SELECT id FROM import_final_exam_rows
         WHERE batch_id=? AND id<>? AND matched_student_id=? AND subject_code=? LIMIT 1 FOR UPDATE`,
        [batchId.data, rowId.data, input.data.studentId, current.subject_code],
      );
      if (duplicates[0]) { await conn.rollback(); return void res.status(409).json({ error: 'DUPLICATE_STUDENT_SUBJECT_IN_BATCH' }); }
      await conn.execute(`UPDATE import_batches SET status='REVIEW_REQUIRED' WHERE id=? AND status='STAGED'`, [batchId.data]);
      await conn.execute(
        `UPDATE import_final_exam_rows SET matched_student_id=?,match_status='APPROVED',review_note=? WHERE id=?`,
        [input.data.studentId, input.data.note ?? null, rowId.data],
      );
      after = {
        matchedStudentId: input.data.studentId,
        matchedStudentNis: student.nis,
        matchedStudentName: student.name,
        matchStatus: 'APPROVED',
        note: input.data.note ?? null,
      };
    }
    await writeAudit(req, {
      action: 'FINAL_EXAM_IMPORT.REVIEW_RESOLVED',
      entityType: 'import_final_exam_row',
      entityId: rowId.data,
      metadata: { batchId: batchId.data, decision: input.data.decision, sourceNis: current.source_nis, sourceName: current.source_name, before, after },
    }, conn);
    await conn.commit();
    res.status(204).end();
  } catch (error: any) {
    await conn.rollback();
    if (error?.status && [
      'MATCHED_STUDENT_NOT_FOUND',
      'FINAL_CLASS_ENROLLMENT_REQUIRED',
      'SOURCE_CLASS_FINAL_EXAM_ENROLLMENT_MISMATCH',
      'IDENTITY_OVERRIDE_NOTE_REQUIRED',
      'ISSUED_CERTIFICATE_IMMUTABLE',
    ].includes(error.message)) return void res.status(error.status).json({ error: error.message });
    next(error);
  } finally {
    conn.release();
  }
});

async function loadAndValidateRows(conn: PoolConnection, batchId: number, academicYearId: number) {
  const [rows]: any = await conn.query(
    `SELECT id,source_nis,source_class,subject_code,score,matched_student_id,match_status,review_note
     FROM import_final_exam_rows WHERE batch_id=? ORDER BY matched_student_id,subject_code,source_row_number FOR UPDATE`,
    [batchId],
  );
  if (!rows.length) throw Object.assign(new Error('IMPORT_BATCH_EMPTY'), { status: 409 });
  const seen = new Set<string>();
  for (const row of rows) {
    if (!row.matched_student_id || !['EXACT_OFFICIAL_NIS', 'APPROVED'].includes(row.match_status)) {
      throw Object.assign(new Error('IMPORT_REVIEW_INCOMPLETE'), { status: 409 });
    }
    const key = `${row.matched_student_id}:${row.subject_code}`;
    if (seen.has(key)) throw Object.assign(new Error('DUPLICATE_STUDENT_SUBJECT_IN_BATCH'), { status: 409 });
    seen.add(key);
    await assertFinalExamTarget(
      conn, Number(row.matched_student_id), academicYearId, row.source_class, row.source_nis,
      row.review_note ?? null,
    );
  }
  return rows;
}

finalExamImportRouter.post('/:batchId/approve', async (req, res, next) => {
  const batchId = id.safeParse(req.params.batchId);
  const input = approval.safeParse(req.body);
  if (!batchId.success || !input.success) return void res.status(400).json({ error: 'INVALID_IMPORT_APPROVAL' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batches]: any = await conn.query(
      `SELECT status,academic_year_id FROM import_batches WHERE id=? AND source_type='EXCEL_FINAL_EXAM' FOR UPDATE`,
      [batchId.data],
    );
    if (!batches[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (!['STAGED', 'REVIEW_REQUIRED'].includes(batches[0].status)) {
      await conn.rollback();
      return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_REVIEWABLE' });
    }
    if (Number(batches[0].academic_year_id) !== input.data.academicYearId) {
      await conn.rollback();
      return void res.status(409).json({ error: 'IMPORT_ACADEMIC_YEAR_MISMATCH' });
    }
    await loadAndValidateRows(conn, batchId.data, input.data.academicYearId);
    const [result]: any = await conn.execute(
      `UPDATE import_batches SET status='APPROVED',approved_by=?,approved_at=NOW()
       WHERE id=? AND status IN('STAGED','REVIEW_REQUIRED')`,
      [req.auth!.userId, batchId.data],
    );
    if (result.affectedRows !== 1) throw Object.assign(new Error('IMPORT_BATCH_STATE_CHANGED'), { status: 409 });
    await writeAudit(req, {
      action: 'FINAL_EXAM_IMPORT.APPROVED',
      entityType: 'import_batch',
      entityId: batchId.data,
      metadata: { academicYearId: input.data.academicYearId },
    }, conn);
    await conn.commit();
    res.status(204).end();
  } catch (error: any) {
    await conn.rollback();
    if (error?.status) return void res.status(error.status).json({ error: error.message });
    next(error);
  } finally {
    conn.release();
  }
});

finalExamImportRouter.post('/:batchId/apply', async (req, res, next) => {
  const batchId = id.safeParse(req.params.batchId);
  if (!batchId.success) return void res.status(400).json({ error: 'INVALID_IMPORT_APPLY' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batches]: any = await conn.query(
      `SELECT status,academic_year_id FROM import_batches WHERE id=? AND source_type='EXCEL_FINAL_EXAM' FOR UPDATE`,
      [batchId.data],
    );
    if (!batches[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (batches[0].status !== 'APPROVED') {
      await conn.rollback();
      return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_APPROVED' });
    }
    const yearId = Number(batches[0].academic_year_id);
    const rows = await loadAndValidateRows(conn, batchId.data, yearId);
    for (const row of rows) {
      const [existing]: any = await conn.query(
        `SELECT id,score,import_row_id FROM certificate_final_exam_scores
         WHERE student_id=? AND academic_year_id=? AND subject_code=? FOR UPDATE`,
        [row.matched_student_id, yearId, row.subject_code],
      );
      if (existing[0]) {
        if (existing[0].score !== null || existing[0].import_row_id !== null) {
          throw Object.assign(new Error('FINAL_EXAM_SCORE_ALREADY_EXISTS'), { status: 409 });
        }
        const [updated]: any = await conn.execute(
          `UPDATE certificate_final_exam_scores SET score=?,import_row_id=?,updated_by=?
           WHERE id=? AND score IS NULL AND import_row_id IS NULL`,
          [row.score, row.id, req.auth!.userId, existing[0].id],
        );
        if (updated.affectedRows !== 1) throw Object.assign(new Error('FINAL_EXAM_SCORE_ALREADY_EXISTS'), { status: 409 });
      } else {
        await conn.execute(
          `INSERT INTO certificate_final_exam_scores
           (student_id,academic_year_id,subject_code,score,created_by,updated_by,import_row_id)
           VALUES(?,?,?,?,?,?,?)`,
          [row.matched_student_id, yearId, row.subject_code, row.score, req.auth!.userId, req.auth!.userId, row.id],
        );
      }
    }
    const [result]: any = await conn.execute(
      `UPDATE import_batches SET status='IMPORTED' WHERE id=? AND status='APPROVED'`,
      [batchId.data],
    );
    if (result.affectedRows !== 1) throw Object.assign(new Error('IMPORT_BATCH_STATE_CHANGED'), { status: 409 });
    await writeAudit(req, {
      action: 'FINAL_EXAM_IMPORT.APPLIED',
      entityType: 'import_batch',
      entityId: batchId.data,
      metadata: { academicYearId: yearId, rowCount: rows.length },
    }, conn);
    await conn.commit();
    res.status(204).end();
  } catch (error: any) {
    await conn.rollback();
    if (error?.status) return void res.status(error.status).json({ error: error.message });
    next(error);
  } finally {
    conn.release();
  }
});
