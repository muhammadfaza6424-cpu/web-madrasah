import ExcelJS from 'exceljs';
import { headerKey, textCell } from './xlsx-cell-helpers.js';

export type MasterDataKind = 'TEACHERS' | 'SUBJECTS';

export type MasterDataSourceRow = {
  sourceRowNumber: number;
  sourceCode: string | null;
  sourceIdentifier: string | null;
  sourceName: string | null;
  sourceStatus: 'ACTIVE' | 'INACTIVE' | null;
  sourceBookName: string | null;
  sourceActive: boolean | null;
  validationErrorCode: string | null;
};

const HEADERS: Record<MasterDataKind, string[]> = {
  TEACHERS: ['code', 'niporidentifier', 'name', 'status'],
  SUBJECTS: ['code', 'name', 'bookname', 'active'],
};

function fail(code: string): never {
  throw Object.assign(new Error(code), { status: 400, code });
}

function normalized(value: string): string {
  return value.normalize('NFKC').trim().replace(/\s+/g, ' ').toLocaleLowerCase('id-ID');
}

function hasNonBlankValue(value: ExcelJS.CellValue): boolean {
  return value != null && value !== '';
}

function addDuplicateErrors(rows: MasterDataSourceRow[], kind: MasterDataKind): void {
  const seen = new Map<string, MasterDataSourceRow[]>();
  for (const row of rows) {
    const values = kind === 'TEACHERS'
      ? [row.sourceCode && `code:${normalized(row.sourceCode)}`, row.sourceIdentifier && `identifier:${normalized(row.sourceIdentifier)}`]
      : [row.sourceCode && `code:${normalized(row.sourceCode)}`, row.sourceName && `name:${normalized(row.sourceName)}`];
    for (const value of values.filter((item): item is string => Boolean(item))) {
      const matching = seen.get(value) ?? [];
      matching.push(row);
      seen.set(value, matching);
    }
  }
  for (const duplicateRows of seen.values()) {
    if (duplicateRows.length < 2) continue;
    for (const row of duplicateRows) {
      const errors = row.validationErrorCode?.split('|') ?? [];
      if (!errors.includes('DUPLICATE_IDENTITY_IN_SOURCE')) errors.push('DUPLICATE_IDENTITY_IN_SOURCE');
      row.validationErrorCode = errors.join('|');
    }
  }
}

export async function parseMasterDataWorkbook(bytes: Buffer, kind: MasterDataKind): Promise<MasterDataSourceRow[]> {
  let workbook: ExcelJS.Workbook;
  try {
    workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(bytes as never);
  } catch {
    return fail('INVALID_MASTER_DATA_XLSX');
  }
  if (workbook.worksheets.length !== 1) return fail('MASTER_DATA_WORKBOOK_MUST_HAVE_ONE_SHEET');
  const worksheet = workbook.worksheets[0];
  if (!worksheet || worksheet.rowCount < 1) return fail('MASTER_DATA_HEADER_INVALID');

  const requiredHeaders = HEADERS[kind];
  const headerRow = worksheet.getRow(1);
  const headers = Array.from(
    { length: headerRow.cellCount },
    (_, index) => headerKey(headerRow.getCell(index + 1).value),
  );
  if (headers.length !== requiredHeaders.length ||
      new Set(headers).size !== requiredHeaders.length ||
      requiredHeaders.some((header) => !headers.includes(header))) {
    return fail('MASTER_DATA_HEADER_INVALID');
  }
  const columnByHeader = new Map(headers.map((header, index) => [header, index + 1]));
  const rows: MasterDataSourceRow[] = [];

  for (let rowNumber = 2; rowNumber <= worksheet.rowCount; rowNumber++) {
    const row = worksheet.getRow(rowNumber);
    const values = requiredHeaders.map((header) => row.getCell(columnByHeader.get(header)!).value);
    if (values.every((value) => value == null || value === '')) continue;

    const codeCell = row.getCell(columnByHeader.get('code')!);
    const sourceCode = textCell(codeCell);
    const sourceName = textCell(row.getCell(columnByHeader.get('name')!));
    let sourceIdentifier: string | null = null;
    let sourceStatus: 'ACTIVE' | 'INACTIVE' | null = null;
    let sourceBookName: string | null = null;
    let sourceActive: boolean | null = null;
    const errors: string[] = [];

    if (!sourceName) errors.push('NAME_REQUIRED');
    else if (sourceName.length > 150) errors.push('NAME_TOO_LONG');
    if (hasNonBlankValue(codeCell.value) && !sourceCode) errors.push('CODE_REQUIRED_TEXT');
    if (sourceCode && sourceCode.length > 50) errors.push('CODE_TOO_LONG');

    if (kind === 'TEACHERS') {
      const identifierCell = row.getCell(columnByHeader.get('niporidentifier')!);
      sourceIdentifier = textCell(identifierCell);
      const statusText = textCell(row.getCell(columnByHeader.get('status')!))?.toUpperCase() ?? null;
      sourceStatus = statusText === 'ACTIVE' || statusText === 'INACTIVE' ? statusText : null;
      if (hasNonBlankValue(identifierCell.value) && !sourceIdentifier) errors.push('IDENTIFIER_REQUIRED_TEXT');
      if (!sourceIdentifier && !sourceCode) errors.push('TEACHER_IDENTIFIER_REQUIRED');
      if (sourceIdentifier && sourceIdentifier.length > 100) errors.push('IDENTIFIER_TOO_LONG');
      if (!sourceStatus) errors.push('STATUS_INVALID');
    } else {
      const bookNameCell = row.getCell(columnByHeader.get('bookname')!);
      sourceBookName = textCell(bookNameCell);
      const activeText = textCell(row.getCell(columnByHeader.get('active')!))?.toUpperCase() ?? null;
      sourceActive = activeText === 'TRUE' || activeText === 'YA' || activeText === '1'
        ? true
        : activeText === 'FALSE' || activeText === 'TIDAK' || activeText === '0'
          ? false
          : null;
      if (sourceBookName && sourceBookName.length > 255) errors.push('BOOK_NAME_TOO_LONG');
      if (hasNonBlankValue(bookNameCell.value) && !sourceBookName) errors.push('BOOK_NAME_REQUIRED_TEXT');
      if (activeText === null || sourceActive === null) errors.push('ACTIVE_INVALID');
    }

    rows.push({
      sourceRowNumber: rowNumber,
      sourceCode,
      sourceIdentifier,
      sourceName,
      sourceStatus,
      sourceBookName,
      sourceActive,
      validationErrorCode: errors.length ? errors.join('|') : null,
    });
  }
  if (!rows.length) return fail('MASTER_DATA_HAS_NO_DATA_ROWS');
  addDuplicateErrors(rows, kind);
  return rows;
}

export async function createMasterDataTemplate(kind: MasterDataKind): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet(kind === 'TEACHERS' ? 'Teachers' : 'Subjects');
  if (kind === 'TEACHERS') {
    worksheet.columns = [
      { header: 'Code', key: 'code', width: 20 },
      { header: 'NIP_or_Identifier', key: 'nip_or_identifier', width: 26 },
      { header: 'Name', key: 'name', width: 32 },
      { header: 'Status', key: 'status', width: 16 },
    ];
    worksheet.getColumn(1).numFmt = '@';
    worksheet.getColumn(2).numFmt = '@';
    for (let rowNumber = 2; rowNumber <= 501; rowNumber++) {
      worksheet.getCell(`D${rowNumber}`).dataValidation = {
        type: 'list', allowBlank: false, formulae: ['"ACTIVE,INACTIVE"'],
      };
    }
  } else {
    worksheet.columns = [
      { header: 'Code', key: 'code', width: 20 },
      { header: 'Name', key: 'name', width: 32 },
      { header: 'Book_Name', key: 'book_name', width: 32 },
      { header: 'Active', key: 'active', width: 16 },
    ];
    worksheet.getColumn(1).numFmt = '@';
    for (let rowNumber = 2; rowNumber <= 501; rowNumber++) {
      worksheet.getCell(`D${rowNumber}`).dataValidation = {
        type: 'list', allowBlank: false, formulae: ['"TRUE,FALSE"'],
      };
    }
  }
  worksheet.views = [{ state: 'frozen', ySplit: 1 }];
  worksheet.autoFilter = { from: 'A1', to: 'D1' };
  worksheet.getRow(1).font = { bold: true };
  return Buffer.from(await workbook.xlsx.writeBuffer());
}
