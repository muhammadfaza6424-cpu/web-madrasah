import ExcelJS from 'exceljs';
import { headerKey, textCell } from './xlsx-cell-helpers.js';

export const MUHAFADLOH_PERIODS = ['m1', 'm2', 'm3', 'm4', 'm5', 'm6', 'm7', 'm8'] as const;
export type MuhafadlohPeriod = typeof MUHAFADLOH_PERIODS[number];

export type MuhafadlohSourceRow = {
  sourceRowNumber: number;
  sourceNis: string;
  sourceName: string | null;
  sourceClass: string | null;
  scores: Record<MuhafadlohPeriod, number | null>;
};

const REQUIRED_HEADERS = ['nis', 'nama', 'kelas', ...MUHAFADLOH_PERIODS];

function fail(code: string): never {
  throw Object.assign(new Error(code), { status: 400, code });
}

function scoreValue(value: ExcelJS.CellValue): number | null | undefined {
  if (value === null || value === undefined || value === '') return null;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value === 'string' && /^\d+(?:\.\d{1,2})?$/.test(value.trim())) return Number(value.trim());
  return undefined;
}

export async function parseMuhafadlohWorkbook(bytes: Buffer): Promise<MuhafadlohSourceRow[]> {
  let workbook: ExcelJS.Workbook;
  try {
    workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(bytes as never);
  } catch {
    return fail('INVALID_MUHAFADLOH_XLSX');
  }
  if (workbook.worksheets.length !== 1) return fail('MUHAFADLOH_WORKBOOK_MUST_HAVE_ONE_SHEET');
  const worksheet = workbook.worksheets[0];
  if (!worksheet || worksheet.rowCount < 1) return fail('MUHAFADLOH_HEADER_INVALID');

  const headerRow = worksheet.getRow(1);
  const headers = Array.from({ length: headerRow.cellCount }, (_, index) => headerKey(headerRow.getCell(index + 1).value));
  if (headers.length !== REQUIRED_HEADERS.length ||
      new Set(headers).size !== REQUIRED_HEADERS.length ||
      REQUIRED_HEADERS.some(header => !headers.includes(header))) {
    return fail('MUHAFADLOH_HEADER_INVALID');
  }
  const columnByHeader = new Map(headers.map((header, index) => [header, index + 1]));
  const rows: MuhafadlohSourceRow[] = [];
  const seenNis = new Set<string>();

  for (let rowNumber = 2; rowNumber <= worksheet.rowCount; rowNumber++) {
    const row = worksheet.getRow(rowNumber);
    const cells = Object.fromEntries(
      REQUIRED_HEADERS.map(header => [header, row.getCell(columnByHeader.get(header)!).value]),
    );
    if (Object.values(cells).every(value => value == null || value === '')) continue;

    const nisCell = row.getCell(columnByHeader.get('nis')!);
    const sourceNis = typeof nisCell.value === 'string' ? textCell(nisCell) : null;
    const sourceName = textCell(row.getCell(columnByHeader.get('nama')!));
    const sourceClass = textCell(row.getCell(columnByHeader.get('kelas')!));
    if (!sourceNis || sourceNis.length > 100 ||
        (sourceName && sourceName.length > 255) ||
        (sourceClass && sourceClass.length > 50) ||
        seenNis.has(sourceNis)) {
      return fail('MUHAFADLOH_ROW_INVALID');
    }

    const scores = Object.fromEntries(MUHAFADLOH_PERIODS.map(period => {
      const value = scoreValue(row.getCell(columnByHeader.get(period)!).value);
      if (value === undefined || (value !== null && (value < 0 || value > 100))) {
        return fail('MUHAFADLOH_ROW_INVALID');
      }
      return [period, value];
    })) as Record<MuhafadlohPeriod, number | null>;
    if (Object.values(scores).every(value => value === null)) return fail('MUHAFADLOH_ROW_INVALID');

    seenNis.add(sourceNis);
    rows.push({ sourceRowNumber: rowNumber, sourceNis, sourceName, sourceClass, scores });
  }

  if (!rows.length) return fail('MUHAFADLOH_HAS_NO_DATA_ROWS');
  return rows;
}

export async function createMuhafadlohTemplate(): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Muhafadloh');
  worksheet.columns = [
    { header: 'NIS', key: 'nis', width: 20 },
    { header: 'Nama', key: 'nama', width: 32 },
    { header: 'Kelas', key: 'kelas', width: 16 },
    ...MUHAFADLOH_PERIODS.map(period => ({ header: period.toUpperCase(), key: period, width: 14 })),
  ];
  worksheet.views = [{ state: 'frozen', ySplit: 1 }];
  worksheet.autoFilter = { from: 'A1', to: 'K1' };
  worksheet.getRow(1).font = { bold: true };
  worksheet.getColumn(1).numFmt = '@';
  for (let column = 4; column <= 11; column++) {
    worksheet.getColumn(column).numFmt = '0.##';
    for (let rowNumber = 2; rowNumber <= 501; rowNumber++) {
      worksheet.getCell(rowNumber, column).dataValidation = {
        type: 'decimal',
        operator: 'between',
        allowBlank: true,
        formulae: [0, 100],
      };
    }
  }
  return Buffer.from(await workbook.xlsx.writeBuffer());
}
