import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';
import { createMuhafadlohTemplate, MUHAFADLOH_PERIODS, parseMuhafadlohWorkbook } from './muhafadloh-xlsx.js';

async function makeWorkbook(headers: string[], rows: unknown[][]): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Synthetic');
  worksheet.addRow(headers);
  for (const row of rows) worksheet.addRow(row);
  return Buffer.from(await workbook.xlsx.writeBuffer());
}

const headers = ['NIS', 'Nama', 'Kelas', 'M1', 'M2', 'M3', 'M4', 'M5', 'M6', 'M7', 'M8'];

describe('parseMuhafadlohWorkbook', () => {
  it('parses text NIS and explicit nullable M1-M8 scores', async () => {
    const rows = await parseMuhafadlohWorkbook(await makeWorkbook(headers, [
      ['000123', 'Synthetic Student', 'A1', 80, '', null, 81.25, null, null, null, 90],
    ]));
    assert.deepEqual(rows, [{
      sourceRowNumber: 2,
      sourceNis: '000123',
      sourceName: 'Synthetic Student',
      sourceClass: 'A1',
      scores: { m1: 80, m2: null, m3: null, m4: 81.25, m5: null, m6: null, m7: null, m8: 90 },
    }]);
  });

  it('rejects numeric NIS, duplicate NIS, empty scores and invalid score values', async () => {
    const invalidRows = [
      [[123, 'Synthetic Student', 'A1', 80, null, null, null, null, null, null, null]],
      [['123', 'First', 'A1', 80, null, null, null, null, null, null, null], ['123', 'Duplicate', 'A1', 81, null, null, null, null, null, null, null]],
      [['123', 'Synthetic Student', 'A1', null, null, null, null, null, null, null, null]],
      [['123', 'Synthetic Student', 'A1', 100.01, null, null, null, null, null, null, null]],
      [['123', 'Synthetic Student', 'A1', '80.123', null, null, null, null, null, null, null]],
    ];
    for (const rows of invalidRows) {
      await assert.rejects(parseMuhafadlohWorkbook(await makeWorkbook(headers, rows)), /MUHAFADLOH_ROW_INVALID/);
    }
  });

  it('rejects an invalid header, empty workbook and malformed XLSX', async () => {
    await assert.rejects(
      parseMuhafadlohWorkbook(await makeWorkbook([...headers.slice(0, 10), 'Extra'], [])),
      /MUHAFADLOH_HEADER_INVALID/,
    );
    await assert.rejects(parseMuhafadlohWorkbook(await makeWorkbook(headers, [])), /MUHAFADLOH_HAS_NO_DATA_ROWS/);
    await assert.rejects(parseMuhafadlohWorkbook(Buffer.from('not an xlsx')), /INVALID_MUHAFADLOH_XLSX/);
  });

  it('creates a template with nullable scores bounded to 0-100', async () => {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(await createMuhafadlohTemplate() as never);
    const sheet = workbook.getWorksheet('Muhafadloh');
    assert.deepEqual(
      Array.from({ length: 11 }, (_, index) => sheet?.getCell(1, index + 1).value),
      ['NIS', 'Nama', 'Kelas', ...MUHAFADLOH_PERIODS.map(period => period.toUpperCase())],
    );
    assert.equal(sheet?.getCell('A2').numFmt, '@');
    assert.deepEqual(sheet?.getCell('D2').dataValidation.formulae, [0, 100]);
    assert.equal(sheet?.getCell('D2').dataValidation.allowBlank, true);
  });
});
