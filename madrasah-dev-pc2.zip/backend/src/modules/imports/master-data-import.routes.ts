import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { db } from '../../config/db.js';
import { requireAuthentication } from '../../middleware/authentication.js';
import { requirePermission, requireRole } from '../../middleware/authorization.js';
import { writeAudit } from '../audit/audit.service.js';
import { digest, validOffice } from '../storage/integrity.js';
import {
  createMasterDataTemplate,
  parseMasterDataWorkbook,
  type MasterDataKind,
  type MasterDataSourceRow,
} from './master-data-xlsx.js';

export const masterDataImportRouter = Router();
masterDataImportRouter.use(
  requireAuthentication,
  requirePermission('masters.import.manage'),
  requireRole('SUPER_ADMIN', 'ADMIN'),
);

const upload = multer({ storage: multer.memoryStorage(), limits: { files: 1, fileSize: 10 * 1024 * 1024 } });
const positiveId = z.coerce.number().int().positive();
const kinds: MasterDataKind[] = ['TEACHERS', 'SUBJECTS'];
const reviewInput = z.object({
  decision: z.enum(['CREATE_NEW', 'KEEP_OFFICIAL', 'REVIEW']),
  note: z.string().trim().max(1000).nullable().optional(),
}).strict();
const sourceTypes = {
  TEACHERS: 'EXCEL_MASTER_TEACHERS',
  SUBJECTS: 'EXCEL_MASTER_SUBJECTS',
} as const;

type Classification = 'NEW' | 'UNCHANGED' | 'CONFLICT' | 'AMBIGUOUS' | 'INVALID';
type Decision = 'CREATE_NEW' | 'KEEP_OFFICIAL' | 'REVIEW';

function isKind(value: unknown): value is MasterDataKind {
  return typeof value === 'string' && kinds.includes(value as MasterDataKind);
}

function safeFilename(value: unknown): string {
  const original = String(value || 'master-data.xlsx').replace(/\\/g, '/');
  return (original.split('/').pop() || 'master-data.xlsx')
    .replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 255) || 'master-data.xlsx';
}

function normalized(value: unknown): string {
  return String(value ?? '').normalize('NFKC').trim().replace(/\s+/g, ' ').toLocaleLowerCase('id-ID');
}

function rowFromDb(row: any): MasterDataSourceRow {
  return {
    sourceRowNumber: Number(row.source_row_number),
    sourceCode: row.source_code,
    sourceIdentifier: row.source_identifier,
    sourceName: row.source_name,
    sourceStatus: row.source_status,
    sourceBookName: row.source_book_name,
    sourceActive: row.source_active === null ? null : Boolean(row.source_active),
    validationErrorCode: row.validation_error_code,
  };
}

async function classifyRow(executor: any, kind: MasterDataKind, source: MasterDataSourceRow) {
  if (source.validationErrorCode) {
    return { classification: 'INVALID' as Classification, matchedTargetId: null, validationErrorCode: source.validationErrorCode };
  }

  const conditions: string[] = [];
  const params: unknown[] = [];
  if (source.sourceCode) {
    conditions.push('code=?');
    params.push(source.sourceCode);
  }
  if (kind === 'TEACHERS' && source.sourceIdentifier) {
    conditions.push('nip_or_identifier=?');
    params.push(source.sourceIdentifier);
  }
  conditions.push('name=?');
  params.push(source.sourceName);

  const table = kind === 'TEACHERS' ? 'teachers' : 'subjects';
  const columns = kind === 'TEACHERS'
    ? 'id,code,nip_or_identifier,name,status,NULL AS book_name,NULL AS active'
    : 'id,code,NULL AS nip_or_identifier,name,NULL AS status,book_name,active';
  const [candidates]: any = await executor.query(
    `SELECT ${columns} FROM ${table} WHERE ${conditions.map((condition) => `LOWER(TRIM(${condition.split('=')[0]}))=LOWER(TRIM(?))`).join(' OR ')}`,
    params,
  );

  const matches = candidates.filter((candidate: any) =>
    (source.sourceCode && normalized(candidate.code) === normalized(source.sourceCode)) ||
    (kind === 'TEACHERS' && source.sourceIdentifier && normalized(candidate.nip_or_identifier) === normalized(source.sourceIdentifier)) ||
    normalized(candidate.name) === normalized(source.sourceName),
  );
  const matchedIds = [...new Set(matches.map((candidate: any) => Number(candidate.id)))];
  if (matchedIds.length > 1) {
    return { classification: 'AMBIGUOUS' as Classification, matchedTargetId: null, validationErrorCode: 'MASTER_IDENTITY_AMBIGUOUS' };
  }
  if (!matches.length) {
    return { classification: 'NEW' as Classification, matchedTargetId: null, validationErrorCode: null };
  }

  const current = matches[0];
  const same = kind === 'TEACHERS'
    ? normalized(current.code) === normalized(source.sourceCode) &&
      normalized(current.nip_or_identifier) === normalized(source.sourceIdentifier) &&
      normalized(current.name) === normalized(source.sourceName) &&
      current.status === source.sourceStatus
    : normalized(current.code) === normalized(source.sourceCode) &&
      normalized(current.name) === normalized(source.sourceName) &&
      normalized(current.book_name) === normalized(source.sourceBookName) &&
      Boolean(current.active) === source.sourceActive;
  return {
    classification: same ? 'UNCHANGED' as Classification : 'CONFLICT' as Classification,
    matchedTargetId: Number(current.id),
    validationErrorCode: null,
  };
}

function eligibleDecision(
  classification: Classification,
  matchedTargetId: number | null,
  decision: Decision,
): boolean {
  if (decision === 'REVIEW') return true;
  if (classification === 'NEW') return decision === 'CREATE_NEW' && matchedTargetId === null;
  return ['UNCHANGED', 'CONFLICT'].includes(classification) &&
    decision === 'KEEP_OFFICIAL' && matchedTargetId !== null;
}

masterDataImportRouter.get('/template/:kind', async (req, res, next) => {
  try {
    if (!isKind(req.params.kind)) return void res.status(400).json({ error: 'MASTER_DATA_KIND_INVALID' });
    const template = await createMasterDataTemplate(req.params.kind);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="master-${req.params.kind.toLowerCase()}-template.xlsx"`);
    res.send(template);
  } catch (error) { next(error); }
});

masterDataImportRouter.get('/', async (_req, res, next) => {
  try {
    const [batches] = await db.query(
      `SELECT b.id,b.source_type,b.source_name,b.source_checksum,b.status,b.created_at,b.approved_at,
        COUNT(r.id) total_rows,
        COALESCE(SUM(r.decision='REVIEW' OR r.classification IN('CONFLICT','AMBIGUOUS','INVALID')),0) unresolved_rows
       FROM import_batches b
       LEFT JOIN import_master_data_rows r ON r.batch_id=b.id
       WHERE b.source_type IN('EXCEL_MASTER_TEACHERS','EXCEL_MASTER_SUBJECTS')
       GROUP BY b.id ORDER BY b.created_at DESC,b.id DESC`,
    );
    res.json({ batches });
  } catch (error) { next(error); }
});

masterDataImportRouter.post('/stage', upload.single('file'), async (req, res, next) => {
  try {
    if (!req.file) return void res.status(400).json({ error: 'FILE_REQUIRED' });
    if (!isKind(req.body.kind)) return void res.status(400).json({ error: 'MASTER_DATA_KIND_INVALID' });
    const kind: MasterDataKind = req.body.kind;
    if (!req.file.originalname.toLowerCase().endsWith('.xlsx') ||
        req.file.mimetype !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
        !(await validOffice(req.file.buffer, 'xl'))) {
      return void res.status(400).json({ error: 'INVALID_MASTER_DATA_XLSX' });
    }
    const sourceRows = await parseMasterDataWorkbook(req.file.buffer, kind);
    const checksum = digest(req.file.buffer);
    const conn = await db.getConnection();
    const lockName = `master-import:${kind.toLowerCase()}:${checksum.slice(0, 40)}`;
    let lockAcquired = false;
    try {
      const [locks]: any = await conn.query('SELECT GET_LOCK(?,10) acquired', [lockName]);
      lockAcquired = Number(locks[0]?.acquired) === 1;
      if (!lockAcquired) return void res.status(409).json({ error: 'IMPORT_SOURCE_STAGING_IN_PROGRESS' });
      await conn.beginTransaction();
      const sourceType = sourceTypes[kind];
      const [existing]: any = await conn.query(
        `SELECT id FROM import_batches WHERE source_type=? AND source_checksum=?
         AND status IN('STAGED','REVIEW_REQUIRED','APPROVED','IMPORTED') LIMIT 1 FOR UPDATE`,
        [sourceType, checksum],
      );
      if (existing[0]) {
        await conn.rollback();
        return void res.status(409).json({ error: 'IMPORT_SOURCE_ALREADY_STAGED' });
      }

      const sourceName = safeFilename(req.file.originalname);
      const [insertBatch]: any = await conn.execute(
        `INSERT INTO import_batches(source_type,source_name,source_checksum,status,created_by)
         VALUES(?,?,?,'STAGED',?)`,
        [sourceType, sourceName, checksum, req.auth!.userId],
      );
      const batchId = Number(insertBatch.insertId);
      const counts: Record<string, number> = {};
      for (const source of sourceRows) {
        const classified = await classifyRow(conn, kind, source);
        const validationErrorCode = source.validationErrorCode ?? classified.validationErrorCode;
        const classification = validationErrorCode ? 'INVALID' : classified.classification;
        counts[classification] = (counts[classification] ?? 0) + 1;
        await conn.execute(
          `INSERT INTO import_master_data_rows(
            batch_id,source_row_number,entity_type,source_code,source_identifier,source_name,
            source_status,source_book_name,source_active,matched_target_id,classification,decision,validation_error_code
          ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          [
            batchId, source.sourceRowNumber, kind === 'TEACHERS' ? 'TEACHER' : 'SUBJECT',
            source.sourceCode, source.sourceIdentifier, source.sourceName, source.sourceStatus,
            source.sourceBookName, source.sourceActive, classified.matchedTargetId, classification,
            'REVIEW', validationErrorCode,
          ],
        );
      }
      await writeAudit(req, {
        action: 'MASTER_DATA_IMPORT.STAGED',
        entityType: 'import_batch',
        entityId: batchId,
        metadata: { kind, sourceName, checksum, rowCount: sourceRows.length, classifications: counts },
      }, conn);
      await conn.commit();
      res.status(201).json({ batchId, kind, sourceName, checksum, rowCount: sourceRows.length, classifications: counts });
    } catch (error) {
      await conn.rollback();
      throw error;
    } finally {
      if (lockAcquired) await conn.query('SELECT RELEASE_LOCK(?)', [lockName]);
      conn.release();
    }
  } catch (error: any) {
    if (error?.status === 400 && (
      error?.code === 'INVALID_MASTER_DATA_XLSX' ||
      (typeof error?.code === 'string' && error.code.startsWith('MASTER_DATA_'))
    )) {
      return void res.status(400).json({ error: error.code });
    }
    next(error);
  }
});

masterDataImportRouter.get('/:batchId/review', async (req, res, next) => {
  const batchId = positiveId.safeParse(req.params.batchId);
  if (!batchId.success) return void res.status(400).json({ error: 'INVALID_IMPORT_BATCH' });
  try {
    const [batches]: any = await db.query(
      `SELECT id,source_type,source_name,source_checksum,status,created_at,approved_at
       FROM import_batches WHERE id=? AND source_type IN('EXCEL_MASTER_TEACHERS','EXCEL_MASTER_SUBJECTS') LIMIT 1`,
      [batchId.data],
    );
    if (!batches[0]) return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' });
    const [rows] = await db.query(
      `SELECT * FROM import_master_data_rows WHERE batch_id=? ORDER BY source_row_number`,
      [batchId.data],
    );
    const [classificationRows]: any = await db.query(
      `SELECT classification,decision,COUNT(*) row_count FROM import_master_data_rows
       WHERE batch_id=? GROUP BY classification,decision`,
      [batchId.data],
    );
    const counts: Record<string, number> = {};
    const decisions: Record<string, number> = {};
    for (const item of classificationRows) {
      counts[item.classification] = (counts[item.classification] ?? 0) + Number(item.row_count);
      decisions[item.decision] = (decisions[item.decision] ?? 0) + Number(item.row_count);
    }
    res.json({ batch: batches[0], rows, preview: { counts, decisions } });
  } catch (error) { next(error); }
});

masterDataImportRouter.put('/:batchId/review/:rowId', async (req, res, next) => {
  const batchId = positiveId.safeParse(req.params.batchId);
  const rowId = positiveId.safeParse(req.params.rowId);
  const input = reviewInput.safeParse(req.body);
  if (!batchId.success || !rowId.success) return void res.status(400).json({ error: 'INVALID_IMPORT_REVIEW_ID' });
  if (!input.success) return void res.status(400).json({ error: 'INVALID_MASTER_DATA_REVIEW_DECISION' });

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batches]: any = await conn.query(
      `SELECT source_type,status FROM import_batches WHERE id=?
       AND source_type IN('EXCEL_MASTER_TEACHERS','EXCEL_MASTER_SUBJECTS') FOR UPDATE`,
      [batchId.data],
    );
    if (!batches[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (!['STAGED', 'REVIEW_REQUIRED'].includes(batches[0].status)) {
      await conn.rollback();
      return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_REVIEWABLE' });
    }
    const [rows]: any = await conn.query(
      'SELECT * FROM import_master_data_rows WHERE id=? AND batch_id=? FOR UPDATE',
      [rowId.data, batchId.data],
    );
    if (!rows[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_ROW_NOT_FOUND' }); }
    const row = rows[0];
    const kind: MasterDataKind = row.entity_type === 'TEACHER' ? 'TEACHERS' : 'SUBJECTS';
    const decision = input.data.decision;
    if (row.validation_error_code || !eligibleDecision(row.classification, row.matched_target_id === null ? null : Number(row.matched_target_id), decision)) {
      await conn.rollback();
      return void res.status(409).json({ error: 'MASTER_DATA_DECISION_NOT_ELIGIBLE' });
    }
    if (decision === 'KEEP_OFFICIAL' && row.classification === 'CONFLICT' && !input.data.note) {
      await conn.rollback();
      return void res.status(400).json({ error: 'MASTER_DATA_CONFLICT_NOTE_REQUIRED' });
    }
    await conn.execute(
      `UPDATE import_master_data_rows SET decision=?,review_note=?,resolved_by=?,resolved_at=NOW()
       WHERE id=? AND batch_id=?`,
      [decision, input.data.note ?? null, req.auth!.userId, rowId.data, batchId.data],
    );
    await conn.execute(
      `UPDATE import_batches SET status='REVIEW_REQUIRED' WHERE id=? AND status='STAGED'`,
      [batchId.data],
    );
    await writeAudit(req, {
      action: 'MASTER_DATA_IMPORT.ROW_DECIDED',
      entityType: kind === 'TEACHERS' ? 'teacher_import_row' : 'subject_import_row',
      entityId: rowId.data,
      metadata: { batchId: batchId.data, decision, classification: row.classification, note: input.data.note ?? null },
    }, conn);
    await conn.commit();
    res.json({ id: rowId.data, decision });
  } catch (error) {
    await conn.rollback();
    next(error);
  } finally {
    conn.release();
  }
});

masterDataImportRouter.post('/:batchId/approve', async (req, res, next) => {
  const batchId = positiveId.safeParse(req.params.batchId);
  if (!batchId.success) return void res.status(400).json({ error: 'INVALID_IMPORT_BATCH' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batches]: any = await conn.query(
      `SELECT source_type,status FROM import_batches WHERE id=?
       AND source_type IN('EXCEL_MASTER_TEACHERS','EXCEL_MASTER_SUBJECTS') FOR UPDATE`,
      [batchId.data],
    );
    if (!batches[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (!['STAGED', 'REVIEW_REQUIRED'].includes(batches[0].status)) {
      await conn.rollback();
      return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_APPROVABLE' });
    }
    const kind: MasterDataKind = batches[0].source_type === sourceTypes.TEACHERS ? 'TEACHERS' : 'SUBJECTS';
    const [rows]: any = await conn.query(
      'SELECT * FROM import_master_data_rows WHERE batch_id=? ORDER BY source_row_number FOR UPDATE',
      [batchId.data],
    );
    if (!rows.length) { await conn.rollback(); return void res.status(409).json({ error: 'MASTER_DATA_BATCH_EMPTY' }); }
    for (const row of rows) {
      if (row.validation_error_code || row.decision === 'REVIEW') {
        await conn.rollback();
        return void res.status(409).json({ error: 'MASTER_DATA_REVIEW_INCOMPLETE', rowId: row.id });
      }
      const fresh = await classifyRow(conn, kind, rowFromDb(row));
      const storedTarget = row.matched_target_id === null ? null : Number(row.matched_target_id);
      if (fresh.classification === 'AMBIGUOUS' || fresh.classification === 'INVALID' ||
          !eligibleDecision(fresh.classification, fresh.matchedTargetId, row.decision) ||
          (row.decision === 'KEEP_OFFICIAL' && storedTarget !== fresh.matchedTargetId) ||
          (row.decision === 'CREATE_NEW' && fresh.classification !== 'NEW')) {
        await conn.rollback();
        return void res.status(409).json({ error: 'MASTER_DATA_CHANGED_SINCE_STAGING', rowId: row.id });
      }
    }
    await conn.execute(
      `UPDATE import_batches SET status='APPROVED',approved_by=?,approved_at=NOW()
       WHERE id=? AND status IN('STAGED','REVIEW_REQUIRED')`,
      [req.auth!.userId, batchId.data],
    );
    await writeAudit(req, {
      action: 'MASTER_DATA_IMPORT.APPROVED',
      entityType: kind === 'TEACHERS' ? 'teacher_import_batch' : 'subject_import_batch',
      entityId: batchId.data,
      metadata: { rowCount: rows.length },
    }, conn);
    await conn.commit();
    res.json({ batchId: batchId.data, status: 'APPROVED', rowCount: rows.length });
  } catch (error) {
    await conn.rollback();
    next(error);
  } finally {
    conn.release();
  }
});

masterDataImportRouter.post('/:batchId/apply', async (req, res, next) => {
  const batchId = positiveId.safeParse(req.params.batchId);
  if (!batchId.success) return void res.status(400).json({ error: 'INVALID_IMPORT_BATCH' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batches]: any = await conn.query(
      `SELECT source_type,status FROM import_batches WHERE id=?
       AND source_type IN('EXCEL_MASTER_TEACHERS','EXCEL_MASTER_SUBJECTS') FOR UPDATE`,
      [batchId.data],
    );
    if (!batches[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (batches[0].status !== 'APPROVED') {
      await conn.rollback();
      return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_APPROVED' });
    }
    const kind: MasterDataKind = batches[0].source_type === sourceTypes.TEACHERS ? 'TEACHERS' : 'SUBJECTS';
    const [rows]: any = await conn.query(
      'SELECT * FROM import_master_data_rows WHERE batch_id=? ORDER BY source_row_number FOR UPDATE',
      [batchId.data],
    );
    let createdCount = 0;
    let keptCount = 0;
    for (const row of rows) {
      const source = rowFromDb(row);
      const fresh = await classifyRow(conn, kind, source);
      const storedTarget = row.matched_target_id === null ? null : Number(row.matched_target_id);
      if (row.validation_error_code || row.decision === 'REVIEW' ||
          !eligibleDecision(fresh.classification, fresh.matchedTargetId, row.decision) ||
          (row.decision === 'KEEP_OFFICIAL' && storedTarget !== fresh.matchedTargetId) ||
          (row.decision === 'CREATE_NEW' && fresh.classification !== 'NEW')) {
        await conn.rollback();
        return void res.status(409).json({ error: 'MASTER_DATA_CHANGED_SINCE_APPROVAL', rowId: row.id });
      }
      if (row.decision === 'KEEP_OFFICIAL') {
        keptCount++;
      } else if (kind === 'TEACHERS') {
        await conn.execute(
          'INSERT INTO teachers(code,name,nip_or_identifier,status) VALUES(?,?,?,?)',
          [source.sourceCode, source.sourceName, source.sourceIdentifier, source.sourceStatus],
        );
        createdCount++;
      } else {
        await conn.execute(
          'INSERT INTO subjects(code,name,book_name,active) VALUES(?,?,?,?)',
          [source.sourceCode, source.sourceName, source.sourceBookName, source.sourceActive],
        );
        createdCount++;
      }
    }
    await conn.execute(`UPDATE import_batches SET status='IMPORTED' WHERE id=? AND status='APPROVED'`, [batchId.data]);
    await writeAudit(req, {
      action: 'MASTER_DATA_IMPORT.APPLIED',
      entityType: kind === 'TEACHERS' ? 'teacher_import_batch' : 'subject_import_batch',
      entityId: batchId.data,
      metadata: { rowCount: rows.length, createdCount, keptCount },
    }, conn);
    await conn.commit();
    res.json({ batchId: batchId.data, status: 'IMPORTED', rowCount: rows.length, createdCount, keptCount });
  } catch (error) {
    await conn.rollback();
    next(error);
  } finally {
    conn.release();
  }
});
