import yauzl from 'yauzl';
import { XMLParser, XMLValidator } from 'fast-xml-parser';

export type WordStudentRow = {
  sourceRowNumber: number;
  sourceClass: string | null;
  sourceNis: string | null;
  sourceName: string;
  sourceStatus: 'AKTIF' | 'BOYONG';
};

const HEADER = ['Kelas', 'NIS', 'Nama', 'Keterangan'];
type XmlNode = Record<string, unknown>;

const xmlParser = new XMLParser({
  ignoreAttributes: true,
  parseTagValue: false,
  preserveOrder: true,
  processEntities: true,
  removeNSPrefix: true,
  trimValues: false,
});

function localName(name: string): string {
  return name.slice(name.lastIndexOf(':') + 1);
}

function normalizeText(value: string): string {
  return value.replace(/\s+/g, ' ').trim();
}

function directChildElements(node: XmlNode): XmlNode[] {
  const children: XmlNode[] = [];
  for (const value of Object.values(node)) {
    if (!Array.isArray(value)) continue;
    for (const content of value) {
      if (typeof content !== 'object' || content === null) continue;
      for (const [key, childContent] of Object.entries(content)) {
        if (Array.isArray(childContent)) children.push({ [key]: childContent });
      }
    }
  }
  return children;
}

function childElements(node: XmlNode, name: string): XmlNode[] {
  return directChildElements(node).filter((child) => Object.keys(child).some((key) => localName(key) === name));
}

function descendants(nodes: XmlNode[], name: string): XmlNode[] {
  const found: XmlNode[] = [];
  for (const node of nodes) {
    const children = directChildElements(node);
    found.push(...children.filter((child) => Object.keys(child).some((key) => localName(key) === name)));
    found.push(...descendants(children, name));
  }
  return found;
}

function elementText(node: XmlNode): string {
  let text = '';
  for (const [key, value] of Object.entries(node)) {
    if (!Array.isArray(value)) continue;
    for (const child of value) {
      if (typeof child !== 'object' || child === null) continue;
      if (localName(key) === 't' && typeof (child as XmlNode)['#text'] === 'string') text += (child as XmlNode)['#text'];
      else text += elementText(child as XmlNode);
    }
  }
  return normalizeText(text);
}

export function parseWordStudentDocumentXml(xml: string): WordStudentRow[] {
  if (XMLValidator.validate(xml) !== true) {
    throw Object.assign(new Error('XML_INVALID'), { status: 400, code: 'INVALID_WORD_DOCX' });
  }
  const document = xmlParser.parse(xml) as XmlNode[];
  const tables = descendants(document, 'tbl');
  if (!tables.length) throw Object.assign(new Error('HEADER_INVALID'), { status: 400, code: 'INVALID_WORD_DOCX_CONTENT' });

  let dataRows: XmlNode[] | null = null;
  for (const table of tables) {
    const tableRows = childElements(table, 'tr');
    for (let index = 0; index < tableRows.length; index++) {
      const row = tableRows[index];
      if (!row) continue;
      const cells = childElements(row, 'tc').map(elementText);
      const normalized = cells.map(normalizeText);
      if (normalized.length === HEADER.length && HEADER.every((label, cellIndex) => normalized[cellIndex] === label)) {
        dataRows = tableRows.slice(index + 1);
        continue;
      }
      if (dataRows !== null) break;
    }
    if (dataRows !== null) break;
  }

  if (dataRows === null) throw Object.assign(new Error('HEADER_INVALID'), { status: 400, code: 'INVALID_WORD_DOCX_CONTENT' });
  const rows: WordStudentRow[] = [];
  for (const row of dataRows) {
      const cells = childElements(row, 'tc').map(elementText);
      if (cells.length !== HEADER.length) {
        throw Object.assign(new Error('ROW_INVALID'), { status: 400, code: 'INVALID_WORD_DOCX_CONTENT' });
      }
      const [sourceClass, sourceNis, sourceName, sourceStatusText] = cells;
      if (!sourceClass || !sourceNis || !sourceName || !sourceStatusText) {
        throw Object.assign(new Error('ROW_INVALID'), { status: 400, code: 'INVALID_WORD_DOCX_CONTENT' });
      }
      const sourceStatus = normalizeText(sourceStatusText).toUpperCase();
      if (!['AKTIF', 'BOYONG'].includes(sourceStatus)) {
        throw Object.assign(new Error('STATUS_INVALID'), { status: 400, code: 'INVALID_WORD_DOCX_CONTENT' });
      }
      rows.push({
        sourceRowNumber: rows.length + 1,
        sourceClass: normalizeText(sourceClass),
        sourceNis: normalizeText(sourceNis),
        sourceName: normalizeText(sourceName),
        sourceStatus: sourceStatus === 'AKTIF' ? 'AKTIF' : 'BOYONG',
      });
  }
  return rows;
}

export async function extractWordStudentRowsFromDocx(buffer: Buffer): Promise<WordStudentRow[]> {
  return new Promise((resolve, reject) => {
    yauzl.fromBuffer(buffer, { lazyEntries: true, validateEntrySizes: true }, (error, zip) => {
      if (error || !zip) {
        reject(Object.assign(new Error('INVALID_WORD_DOCX'), { status: 400, code: 'INVALID_WORD_DOCX' }));
        return;
      }
      let xmlFound = false;
      zip.on('entry', (entry) => {
        if (entry.fileName === 'word/document.xml') {
          xmlFound = true;
          zip.openReadStream(entry, (streamError, readStream) => {
            if (streamError || !readStream) {
              reject(Object.assign(new Error('INVALID_WORD_DOCX'), { status: 400, code: 'INVALID_WORD_DOCX' }));
              return;
            }
            const chunks: Buffer[] = [];
            readStream.on('data', (chunk) => chunks.push(Buffer.from(chunk)));
            readStream.on('end', () => {
              try {
                const xml = Buffer.concat(chunks).toString('utf8');
                resolve(parseWordStudentDocumentXml(xml));
              } catch (cause) {
                reject(cause);
              } finally {
                zip.close();
              }
            });
            readStream.on('error', () => reject(Object.assign(new Error('INVALID_WORD_DOCX'), { status: 400, code: 'INVALID_WORD_DOCX' })));
          });
          return;
        }
        zip.readEntry();
      });
      zip.on('end', () => {
        if (!xmlFound) reject(Object.assign(new Error('HEADER_INVALID'), { status: 400, code: 'INVALID_WORD_DOCX_CONTENT' }));
      });
      zip.readEntry();
    });
  });
}
