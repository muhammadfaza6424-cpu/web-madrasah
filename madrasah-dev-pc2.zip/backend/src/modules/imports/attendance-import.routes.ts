import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { db } from '../../config/db.js';
import { requireAuthentication } from '../../middleware/authentication.js';
import { requirePermission } from '../../middleware/authorization.js';
import { writeAudit } from '../audit/audit.service.js';
import { digest, validOffice } from '../storage/integrity.js';
import { createAttendanceTemplate, parseAttendanceWorkbook, type AttendanceSourceRow } from './attendance-xlsx.js';

export const attendanceImportRouter = Router();
attendanceImportRouter.use(requireAuthentication, requirePermission('attendance.import.manage'));

const upload = multer({ storage: multer.memoryStorage(), limits: { files: 1, fileSize: 10 * 1024 * 1024 } });
const id = z.coerce.number().int().positive();
const reviewInput = z.object({
  nis: z.string().trim().max(100).nullable(),
  note: z.string().trim().max(500).nullable().optional(),
}).strict();

function safeFilename(value: unknown): string {
  const original = String(value || 'attendance.xlsx').replace(/\\/g, '/');
  return (original.split('/').pop() || 'attendance.xlsx').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 255) || 'attendance.xlsx';
}

attendanceImportRouter.get('/template', async (_req, res, next) => {
  try {
    const template = await createAttendanceTemplate();
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="attendance-template.xlsx"');
    res.send(template);
  } catch (error) { next(error); }
});

attendanceImportRouter.get('/', async (_req, res, next) => {
  try {
    const [batches] = await db.query(`SELECT b.id,b.source_name,b.source_checksum,b.status,b.created_at,b.approved_at,COUNT(r.id) total_rows,COALESCE(SUM(r.matched_student_id IS NULL),0) unresolved_rows FROM import_batches b LEFT JOIN import_attendance_rows r ON r.batch_id=b.id WHERE b.source_type='EXCEL_ATTENDANCE' GROUP BY b.id ORDER BY b.created_at DESC,b.id DESC`);
    res.json({ batches });
  } catch (error) { next(error); }
});

attendanceImportRouter.post('/stage', upload.single('file'), async (req, res, next) => {
  try {
    if (!req.file) return void res.status(400).json({ error: 'FILE_REQUIRED' });
    if (!req.file.originalname.toLowerCase().endsWith('.xlsx') || req.file.mimetype !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') return void res.status(400).json({ error: 'INVALID_ATTENDANCE_XLSX' });
    if (!(await validOffice(req.file.buffer, 'xl'))) return void res.status(400).json({ error: 'INVALID_ATTENDANCE_XLSX' });
    const sourceRows = await parseAttendanceWorkbook(req.file.buffer);
    const checksum = digest(req.file.buffer);
    const sourceName = safeFilename(req.file.originalname);
    const conn = await db.getConnection();
    const lockName = `attendance-import:${checksum.slice(0, 44)}`;
    let lockAcquired = false;
    try {
      const [locks]: any = await conn.query('SELECT GET_LOCK(?,10) acquired', [lockName]);
      lockAcquired = Number(locks[0]?.acquired) === 1;
      if (!lockAcquired) return void res.status(409).json({ error: 'IMPORT_SOURCE_STAGING_IN_PROGRESS' });
      await conn.beginTransaction();
      const [existing]: any = await conn.query(`SELECT id FROM import_batches WHERE source_type='EXCEL_ATTENDANCE' AND source_checksum=? AND status IN('STAGED','REVIEW_REQUIRED','APPROVED','IMPORTED') LIMIT 1 FOR UPDATE`, [checksum]);
      if (existing[0]) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_SOURCE_ALREADY_STAGED' }); }

      const [insertBatch]: any = await conn.execute(`INSERT INTO import_batches(source_type,source_name,source_checksum,status,created_by) VALUES('EXCEL_ATTENDANCE',?,?,'STAGED',?)`, [sourceName, checksum, req.auth!.userId]);
      const batchId = Number(insertBatch.insertId);
      let matchedCount = 0;
      for (const row of sourceRows) {
        const match = await findExactOfficialNis(conn, row.sourceNis);
        if (match.status === 'EXACT_OFFICIAL_NIS') matchedCount++;
        await insertAttendanceRow(conn, batchId, row, match.studentId, match.status, match.note);
      }
      await writeAudit(req, {
        action: 'ATTENDANCE_IMPORT.STAGED',
        entityType: 'import_batch',
        entityId: batchId,
        metadata: { sourceName, checksum, rowCount: sourceRows.length, matchedCount, unmatchedCount: sourceRows.length - matchedCount },
      }, conn);
      await conn.commit();
      res.status(201).json({ batchId, sourceName, checksum, rowCount: sourceRows.length, matchedCount, unmatchedCount: sourceRows.length - matchedCount });
    } catch (error) {
      await conn.rollback();
      throw error;
    } finally {
      if (lockAcquired) await conn.query('SELECT RELEASE_LOCK(?)', [lockName]);
      conn.release();
    }
  } catch (error: any) {
    if (error?.status === 400 && ['INVALID_ATTENDANCE_XLSX', 'ATTENDANCE_WORKBOOK_MUST_HAVE_ONE_SHEET', 'ATTENDANCE_HEADER_INVALID', 'ATTENDANCE_HAS_NO_DATA_ROWS', 'ATTENDANCE_ROW_INVALID'].includes(error?.code)) return void res.status(400).json({ error: error.code });
    next(error);
  }
});

async function findExactOfficialNis(executor: any, sourceNis: string | null): Promise<{ studentId: number | null; status: 'EXACT_OFFICIAL_NIS' | 'UNMATCHED' | 'AMBIGUOUS'; note: string | null }> {
  if (!sourceNis) return { studentId: null, status: 'UNMATCHED', note: 'SOURCE_NIS_REQUIRED_FOR_EXACT_MATCH' };
  const [students]: any = await executor.query(`SELECT id FROM students WHERE nis=? LIMIT 2`, [sourceNis]);
  if (students.length === 1) return { studentId: Number(students[0].id), status: 'EXACT_OFFICIAL_NIS', note: null };
  if (students.length > 1) return { studentId: null, status: 'AMBIGUOUS', note: 'OFFICIAL_NIS_NOT_UNIQUE' };
  return { studentId: null, status: 'UNMATCHED', note: 'OFFICIAL_NIS_NOT_FOUND' };
}

async function insertAttendanceRow(executor: any, batchId: number, row: AttendanceSourceRow, studentId: number | null, matchStatus: string, note: string | null) {
  await executor.execute(
    `INSERT INTO import_attendance_rows(batch_id,source_row_number,source_nis,source_name,source_class,attendance_date,attendance_status,matched_student_id,match_status,review_note) VALUES(?,?,?,?,?,?,?,?,?,?)`,
    [batchId, row.sourceRowNumber, row.sourceNis, row.sourceName, row.sourceClass, row.attendanceDate, row.attendanceStatus, studentId, matchStatus, note],
  );
}

attendanceImportRouter.get('/:batchId/review', async (req, res, next) => {
  try {
    const batchId = id.safeParse(req.params.batchId);
    if (!batchId.success) return void res.status(400).json({ error: 'INVALID_IMPORT_BATCH' });
    const [batches]: any = await db.query(`SELECT id,source_type,source_name,source_checksum,status,created_at,approved_at FROM import_batches WHERE id=? AND source_type='EXCEL_ATTENDANCE' LIMIT 1`, [batchId.data]);
    if (!batches[0]) return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' });
    const [rows] = await db.query(`SELECT r.id,r.source_row_number,r.source_nis,r.source_name,r.source_class,r.attendance_date,r.attendance_status,r.matched_student_id,r.match_status,r.review_note,s.nis official_nis,s.name official_name,s.status student_status FROM import_attendance_rows r LEFT JOIN students s ON s.id=r.matched_student_id WHERE r.batch_id=? ORDER BY r.source_row_number`, [batchId.data]);
    res.json({ batch: batches[0], rows });
  } catch (error) { next(error); }
});

attendanceImportRouter.put('/:batchId/review/:rowId', async (req, res, next) => {
  const batchId = id.safeParse(req.params.batchId), rowId = id.safeParse(req.params.rowId), input = reviewInput.safeParse(req.body);
  if (!batchId.success || !rowId.success) return void res.status(400).json({ error: 'INVALID_IMPORT_REVIEW_ID' });
  if (!input.success) return void res.status(400).json({ error: 'INVALID_ATTENDANCE_REVIEW' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batches]: any = await conn.query(`SELECT status FROM import_batches WHERE id=? AND source_type='EXCEL_ATTENDANCE' FOR UPDATE`, [batchId.data]);
    if (!batches[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (!['STAGED', 'REVIEW_REQUIRED'].includes(batches[0].status)) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_REVIEWABLE' }); }
    const [rows]: any = await conn.query(`SELECT id FROM import_attendance_rows WHERE id=? AND batch_id=? FOR UPDATE`, [rowId.data, batchId.data]);
    if (!rows[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_ROW_NOT_FOUND' }); }

    const nis = input.data.nis || null;
    const match = await findExactOfficialNis(conn, nis);
    const note = input.data.note ?? (match.status === 'UNMATCHED' && nis ? 'OFFICIAL_NIS_NOT_FOUND' : match.note);
    await conn.execute(`UPDATE import_attendance_rows SET matched_student_id=?,match_status=?,review_note=? WHERE id=? AND batch_id=?`, [match.studentId, match.status, note, rowId.data, batchId.data]);
    await writeAudit(req, {
      action: 'ATTENDANCE_IMPORT.ROW_REVIEWED',
      entityType: 'import_attendance_row',
      entityId: rowId.data,
      metadata: { batchId: batchId.data, matchStatus: match.status, matchedStudentId: match.studentId },
    }, conn);
    await conn.commit();
    res.json({ matchStatus: match.status, matchedStudentId: match.studentId, reviewNote: note });
  } catch (error) {
    await conn.rollback();
    next(error);
  } finally { conn.release(); }
});

attendanceImportRouter.post('/:batchId/approve', async (req, res, next) => {
  try {
    const batchId = id.safeParse(req.params.batchId);
    if (!batchId.success) return void res.status(400).json({ error: 'INVALID_IMPORT_BATCH' });
    const [batches]: any = await db.query(`SELECT status FROM import_batches WHERE id=? AND source_type='EXCEL_ATTENDANCE' LIMIT 1`, [batchId.data]);
    if (!batches[0]) return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' });
    if (!['STAGED', 'REVIEW_REQUIRED'].includes(batches[0].status)) return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_REVIEWABLE' });
    const [bad]: any = await db.query(`SELECT COUNT(*) n FROM import_attendance_rows WHERE batch_id=? AND (matched_student_id IS NULL OR attendance_date IS NULL OR attendance_status NOT IN('H','S','I','A') OR match_status IN('UNMATCHED','NAME_CLASS_REVIEW','AMBIGUOUS'))`, [batchId.data]);
    if (Number(bad[0].n) > 0) return void res.status(409).json({ error: 'IMPORT_REVIEW_INCOMPLETE' });
    const [duplicates]: any = await db.query(`SELECT matched_student_id,attendance_date FROM import_attendance_rows WHERE batch_id=? GROUP BY matched_student_id,attendance_date HAVING COUNT(*)>1 LIMIT 1`, [batchId.data]);
    if (duplicates[0]) return void res.status(409).json({ error: 'DUPLICATE_STUDENT_ATTENDANCE_DATE_IN_BATCH' });
    const [result]: any = await db.execute(`UPDATE import_batches SET status='APPROVED',approved_by=?,approved_at=NOW() WHERE id=? AND status IN('STAGED','REVIEW_REQUIRED')`, [req.auth!.userId, batchId.data]);
    if (result.affectedRows !== 1) return void res.status(409).json({ error: 'IMPORT_BATCH_STATE_CHANGED' });
    res.status(204).end();
  } catch (error) { next(error); }
});

attendanceImportRouter.post('/:batchId/apply', async (req, res, next) => {
  const batchId = id.safeParse(req.params.batchId);
  if (!batchId.success) return void res.status(400).json({ error: 'INVALID_IMPORT_BATCH' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batches]: any = await conn.query(`SELECT status FROM import_batches WHERE id=? AND source_type='EXCEL_ATTENDANCE' FOR UPDATE`, [batchId.data]);
    if (!batches[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (batches[0].status !== 'APPROVED') { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_APPROVED' }); }
    const [rows]: any = await conn.query(`SELECT id,source_class,matched_student_id,attendance_date,attendance_status FROM import_attendance_rows WHERE batch_id=? ORDER BY source_row_number FOR UPDATE`, [batchId.data]);
    if (!rows.length) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_EMPTY' }); }
    const seen = new Set<string>();
    for (const row of rows) {
      if (!row.matched_student_id) throw new Error('UNMATCHED_ATTENDANCE_ROW');
      if (!['H', 'S', 'I', 'A'].includes(row.attendance_status)) throw new Error('INVALID_ATTENDANCE_STATUS');
      const date = String(row.attendance_date instanceof Date ? row.attendance_date.toISOString().slice(0, 10) : row.attendance_date);
      const key = `${row.matched_student_id}:${date}`;
      if (seen.has(key)) throw new Error('DUPLICATE_STUDENT_ATTENDANCE_DATE_IN_BATCH');
      seen.add(key);
      const [enrollments]: any = await conn.query(`SELECT se.class_id,se.academic_year_id,c.code class_code FROM student_enrollments se JOIN academic_years ay ON ay.id=se.academic_year_id JOIN classes c ON c.id=se.class_id WHERE se.student_id=? AND ? BETWEEN ay.starts_on AND ay.ends_on AND se.status IN('ACTIVE','BOYONG','PROMOTED','GRADUATED','INACTIVE','WITHDRAWN') ORDER BY ay.starts_on DESC FOR UPDATE`, [row.matched_student_id, row.attendance_date]);
      if (enrollments.length === 0) throw new Error('HISTORICAL_ENROLLMENT_REQUIRED');
      if (enrollments.length !== 1) throw new Error('AMBIGUOUS_HISTORICAL_ENROLLMENT');
      const sourceClass = String(row.source_class ?? '').trim();
      if (sourceClass && sourceClass.toUpperCase() !== String(enrollments[0].class_code ?? '').trim().toUpperCase()) throw new Error('SOURCE_CLASS_HISTORICAL_ENROLLMENT_MISMATCH');
      const [existing]: any = await conn.query(`SELECT source FROM attendance WHERE student_id=? AND attendance_date=? AND schedule_id IS NULL FOR UPDATE`, [row.matched_student_id, row.attendance_date]);
      if (existing[0]?.source === 'MANUAL') throw new Error('MANUAL_ATTENDANCE_EXISTS');
      await conn.execute(`INSERT INTO attendance(student_id,class_id,academic_year_id,attendance_date,status,source,import_row_id,recorded_by) VALUES(?,?,?,?,?,'IMPORT_EXCEL',?,?) ON DUPLICATE KEY UPDATE class_id=VALUES(class_id),academic_year_id=VALUES(academic_year_id),status=VALUES(status),source='IMPORT_EXCEL',import_row_id=VALUES(import_row_id),recorded_by=VALUES(recorded_by)`, [row.matched_student_id, enrollments[0].class_id, enrollments[0].academic_year_id, row.attendance_date, row.attendance_status, row.id, req.auth!.userId]);
    }
    const [result]: any = await conn.execute(`UPDATE import_batches SET status='IMPORTED' WHERE id=? AND status='APPROVED'`, [batchId.data]);
    if (result.affectedRows !== 1) throw new Error('IMPORT_BATCH_STATE_CHANGED');
    await writeAudit(req, { action: 'IMPORT.APPLIED', entityType: 'import_batch', entityId: batchId.data, metadata: { rows: rows.length } }, conn);
    await conn.commit();
    res.status(204).end();
  } catch (error: any) {
    await conn.rollback();
    if (['UNMATCHED_ATTENDANCE_ROW', 'INVALID_ATTENDANCE_STATUS', 'HISTORICAL_ENROLLMENT_REQUIRED', 'AMBIGUOUS_HISTORICAL_ENROLLMENT', 'SOURCE_CLASS_HISTORICAL_ENROLLMENT_MISMATCH', 'DUPLICATE_STUDENT_ATTENDANCE_DATE_IN_BATCH', 'MANUAL_ATTENDANCE_EXISTS', 'IMPORT_BATCH_STATE_CHANGED'].includes(error?.message)) {
      return void res.status(409).json({ error: error.message });
    }
    next(error);
  } finally { conn.release(); }
});
