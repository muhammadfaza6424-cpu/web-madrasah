import ExcelJS from 'exceljs';
import { headerKey, textCell } from './xlsx-cell-helpers.js';

export type StudentRosterSourceRow = {
  sourceRowNumber: number;
  sourceNis: string | null;
  sourceName: string | null;
  sourceClass: string | null;
  sourceStatus: 'AKTIF' | 'BOYONG' | null;
  validationErrorCode: string | null;
};

const REQUIRED_HEADERS = ['nis', 'nama', 'kelas', 'status'];

function fail(code: string): never {
  throw Object.assign(new Error(code), { status: 400, code });
}

export async function parseStudentRosterWorkbook(bytes: Buffer): Promise<StudentRosterSourceRow[]> {
  let workbook: ExcelJS.Workbook;
  try {
    workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(bytes as never);
  } catch {
    return fail('INVALID_ROSTER_XLSX');
  }
  if (workbook.worksheets.length !== 1) return fail('ROSTER_WORKBOOK_MUST_HAVE_ONE_SHEET');
  const worksheet = workbook.worksheets[0];
  if (!worksheet || worksheet.rowCount < 1) return fail('ROSTER_HEADER_INVALID');

  const headerRow = worksheet.getRow(1);
  const headerCount = headerRow.cellCount;
  const headers = Array.from({ length: headerCount }, (_, index) => headerKey(headerRow.getCell(index + 1).value));
  if (headers.length !== REQUIRED_HEADERS.length || new Set(headers).size !== REQUIRED_HEADERS.length || REQUIRED_HEADERS.some((header) => !headers.includes(header))) {
    return fail('ROSTER_HEADER_INVALID');
  }
  const columnByHeader = new Map(headers.map((header, index) => [header, index + 1]));
  const sourceRows: StudentRosterSourceRow[] = [];

  for (let rowNumber = 2; rowNumber <= worksheet.rowCount; rowNumber++) {
    const row = worksheet.getRow(rowNumber);
    const cells = Object.fromEntries(REQUIRED_HEADERS.map((header) => [header, row.getCell(columnByHeader.get(header)!).value]));
    if (Object.values(cells).every((value) => value == null || value === '')) continue;

    const nisCell = row.getCell(columnByHeader.get('nis')!);
    const sourceNis = typeof nisCell.value === 'string' ? textCell(nisCell) : null;
    const sourceName = textCell(row.getCell(columnByHeader.get('nama')!));
    const sourceClass = textCell(row.getCell(columnByHeader.get('kelas')!));
    const statusText = textCell(row.getCell(columnByHeader.get('status')!))?.toUpperCase() ?? null;
    const sourceStatus = statusText === 'AKTIF' || statusText === 'BOYONG' ? statusText : null;
    const errors = [
      !sourceNis ? 'NIS_REQUIRED_TEXT' : sourceNis.length > 100 ? 'NIS_TOO_LONG' : null,
      !sourceName ? 'NAME_REQUIRED' : sourceName.length > 255 ? 'NAME_TOO_LONG' : null,
      !sourceClass ? 'CLASS_REQUIRED' : sourceClass.length > 50 ? 'CLASS_TOO_LONG' : null,
      !sourceStatus ? 'STATUS_INVALID' : null,
    ].filter((value): value is string => value !== null);

    sourceRows.push({
      sourceRowNumber: rowNumber,
      sourceNis,
      sourceName,
      sourceClass,
      sourceStatus,
      validationErrorCode: errors.length ? errors.join('|') : null,
    });
  }

  if (!sourceRows.length) return fail('ROSTER_HAS_NO_DATA_ROWS');
  return sourceRows;
}

export async function createStudentRosterTemplate(): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Roster');
  worksheet.columns = [
    { header: 'NIS', key: 'nis', width: 20 },
    { header: 'Nama', key: 'nama', width: 32 },
    { header: 'Kelas', key: 'kelas', width: 16 },
    { header: 'Status', key: 'status', width: 16 },
  ];
  worksheet.views = [{ state: 'frozen', ySplit: 1 }];
  worksheet.autoFilter = { from: 'A1', to: 'D1' };
  worksheet.getRow(1).font = { bold: true };
  worksheet.getColumn(1).numFmt = '@';
  for (let rowNumber = 2; rowNumber <= 501; rowNumber++) {
    worksheet.getCell(`D${rowNumber}`).dataValidation = { type: 'list', allowBlank: false, formulae: ['"AKTIF,BOYONG"'] };
  }
  return Buffer.from(await workbook.xlsx.writeBuffer());
}
