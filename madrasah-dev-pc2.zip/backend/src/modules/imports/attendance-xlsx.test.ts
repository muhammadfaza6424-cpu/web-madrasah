import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';
import { createAttendanceTemplate, parseAttendanceWorkbook } from './attendance-xlsx.js';

async function makeWorkbook(headers: string[], rows: unknown[][]): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Synthetic');
  worksheet.addRow(headers);
  for (const row of rows) worksheet.addRow(row);
  return Buffer.from(await workbook.xlsx.writeBuffer());
}

describe('parseAttendanceWorkbook', () => {
  it('parses template fields, exact status codes, and formatted Excel dates', async () => {
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('Synthetic');
    sheet.addRow([' NIS ', 'Nama', 'Kelas', 'Tanggal', 'Status']);
    sheet.addRow(['000123', 'Synthetic Student', 'A1', new Date(2025, 0, 2), 'h']);
    sheet.getCell('D2').numFmt = 'yyyy-mm-dd';
    const rows = await parseAttendanceWorkbook(Buffer.from(await workbook.xlsx.writeBuffer()));
    assert.deepEqual(rows, [{
      sourceRowNumber: 2,
      sourceNis: '000123',
      sourceName: 'Synthetic Student',
      sourceClass: 'A1',
      attendanceDate: '2025-01-02',
      attendanceStatus: 'H',
    }]);
  });

  it('keeps numeric NIS unmatched and accepts only strict ISO text dates', async () => {
    const rows = await parseAttendanceWorkbook(await makeWorkbook(['NIS', 'Nama', 'Kelas', 'Tanggal', 'Status'], [
      [123, 'Synthetic Student', 'A1', '2025-01-02', 'S'],
    ]));
    assert.equal(rows[0]?.sourceNis, null);
    assert.equal(rows[0]?.attendanceDate, '2025-01-02');
    assert.equal(rows[0]?.attendanceStatus, 'S');
  });

  it('rejects invalid and ambiguous date cells', async () => {
    for (const value of ['2025-02-29', '01/02/2025', '2025-1-2', 45659]) {
      await assert.rejects(
        parseAttendanceWorkbook(await makeWorkbook(['NIS', 'Nama', 'Kelas', 'Tanggal', 'Status'], [
          ['000123', 'Synthetic Student', 'A1', value, 'H'],
        ])),
        /ATTENDANCE_ROW_INVALID/,
      );
    }
  });

  it('rejects statuses beyond the existing H/S/I/A values', async () => {
    for (const value of ['HADIR', 'T', '']) {
      await assert.rejects(
        parseAttendanceWorkbook(await makeWorkbook(['NIS', 'Nama', 'Kelas', 'Tanggal', 'Status'], [
          ['000123', 'Synthetic Student', 'A1', '2025-01-02', value],
        ])),
        /ATTENDANCE_ROW_INVALID/,
      );
    }
  });

  it('rejects unexpected headers and malformed workbooks', async () => {
    await assert.rejects(parseAttendanceWorkbook(await makeWorkbook(['NIS', 'Nama', 'Kelas', 'Tanggal', 'Catatan'], [])), /ATTENDANCE_HEADER_INVALID/);
    await assert.rejects(parseAttendanceWorkbook(Buffer.from('not an xlsx')), /INVALID_ATTENDANCE_XLSX/);
  });

  it('creates the documented XLSX template and status validation', async () => {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(await createAttendanceTemplate() as never);
    const sheet = workbook.getWorksheet('Attendance');
    assert.deepEqual(
      Array.from({ length: 5 }, (_, index) => sheet?.getCell(1, index + 1).value),
      ['NIS', 'Nama', 'Kelas', 'Tanggal', 'Status'],
    );
    assert.deepEqual(sheet?.getCell('E2').dataValidation.formulae, ['"H,S,I,A"']);
    assert.equal(sheet?.getColumn(1).numFmt, '@');
  });
});
