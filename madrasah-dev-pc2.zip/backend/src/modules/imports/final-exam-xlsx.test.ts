import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';
import { createFinalExamTemplate, parseFinalExamWorkbook } from './final-exam-xlsx.js';

async function makeWorkbook(headers: string[], rows: unknown[][]): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Synthetic');
  worksheet.addRow(headers);
  for (const row of rows) worksheet.addRow(row);
  return Buffer.from(await workbook.xlsx.writeBuffer());
}

const headers = ['NIS', 'Nama', 'Kelas', 'Kode_Mapel', 'Nilai'];

describe('parseFinalExamWorkbook', () => {
  it('parses explicit final-exam subject codes and scores', async () => {
    const rows = await parseFinalExamWorkbook(await makeWorkbook(headers, [
      ['000123', 'Synthetic Student', 'A1', 'FIQIH', 87.5],
    ]));
    assert.deepEqual(rows, [{
      sourceRowNumber: 2,
      sourceNis: '000123',
      sourceName: 'Synthetic Student',
      sourceClass: 'A1',
      subjectCode: 'FIQIH',
      score: 87.5,
    }]);
  });

  it('requires text NIS, an exact subject code and a bounded score', async () => {
    for (const row of [
      [123, 'Student', 'A1', 'FIQIH', 80],
      ['123', 'Student', 'A1', 'Fiqih', 80],
      ['123', 'Student', 'A1', 'FIQIH', null],
      ['123', 'Student', 'A1', 'FIQIH', 100.01],
      ['123', 'Student', 'A1', 'FIQIH', '80.123'],
    ]) {
      await assert.rejects(
        parseFinalExamWorkbook(await makeWorkbook(headers, [row])),
        /FINAL_EXAM_ROW_INVALID/,
      );
    }
  });

  it('rejects duplicate NIS-subject pairs, malformed headers, empty sheets and invalid files', async () => {
    await assert.rejects(
      parseFinalExamWorkbook(await makeWorkbook(headers, [
        ['123', 'Student', 'A1', 'FIQIH', 80],
        ['123', 'Student', 'A1', 'FIQIH', 81],
      ])),
      /FINAL_EXAM_ROW_INVALID/,
    );
    await assert.rejects(
      parseFinalExamWorkbook(await makeWorkbook([...headers.slice(0, 4), 'Extra'], [])),
      /FINAL_EXAM_HEADER_INVALID/,
    );
    await assert.rejects(parseFinalExamWorkbook(await makeWorkbook(headers, [])), /FINAL_EXAM_HAS_NO_DATA_ROWS/);
    await assert.rejects(parseFinalExamWorkbook(Buffer.from('not an xlsx')), /INVALID_FINAL_EXAM_XLSX/);
  });

  it('creates a template with score validation bounded to 0-100', async () => {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(await createFinalExamTemplate() as never);
    const sheet = workbook.getWorksheet('Ujian Akhir');
    assert.deepEqual(
      Array.from({ length: 5 }, (_, index) => sheet?.getCell(1, index + 1).value),
      ['NIS', 'Nama', 'Kelas', 'Kode_Mapel', 'Nilai'],
    );
    assert.equal(sheet?.getCell('A2').numFmt, '@');
    assert.deepEqual(sheet?.getCell('E2').dataValidation.formulae, [0, 100]);
  });
});
