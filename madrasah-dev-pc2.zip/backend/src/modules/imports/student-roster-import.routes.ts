import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { db } from '../../config/db.js';
import { requireAuthentication } from '../../middleware/authentication.js';
import { requirePermission, requireSuperAdmin } from '../../middleware/authorization.js';
import { writeAudit } from '../audit/audit.service.js';
import { digest, validOffice } from '../storage/integrity.js';
import { createStudentRosterTemplate, parseStudentRosterWorkbook, type StudentRosterSourceRow } from './student-roster-xlsx.js';

export const studentRosterImportRouter = Router();
studentRosterImportRouter.use(requireAuthentication, requirePermission('students.import.manage'), requireSuperAdmin);

const upload = multer({ storage: multer.memoryStorage(), limits: { files: 1, fileSize: 10 * 1024 * 1024 } });
const id = z.coerce.number().int().positive();
const reviewInput = z.object({
  decision: z.enum(['CREATE_NEW', 'REUSE_EXISTING', 'KEEP_HISTORICAL', 'MARK_BOYONG', 'REVIEW']),
  note: z.string().trim().max(1000).nullable().optional(),
}).strict();
const approvalErrors = new Set([
  'ROSTER_REVIEW_INCOMPLETE', 'ROSTER_DUPLICATE_NIS', 'ROSTER_CLASS_CHANGED',
  'ROSTER_STUDENT_CHANGED', 'ROSTER_TARGET_ENROLLMENT_CONFLICT', 'ROSTER_NIS_ALREADY_EXISTS',
  'ROSTER_DECISION_NOT_ELIGIBLE', 'TARGET_ACADEMIC_YEAR_NOT_FOUND', 'TARGET_ACADEMIC_YEAR_START_REQUIRED',
]);

function safeFilename(value: unknown): string {
  const original = String(value || 'student-roster.xlsx').replace(/\\/g, '/');
  return (original.split('/').pop() || 'student-roster.xlsx').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 255) || 'student-roster.xlsx';
}

function normalizedName(value: unknown): string {
  return String(value ?? '').normalize('NFKC').trim().replace(/\s+/g, ' ').toLocaleLowerCase('id-ID');
}

async function classifyRow(executor: any, targetYearId: number, source: StudentRosterSourceRow) {
  let classification = 'INVALID';
  let decision = 'REVIEW';
  let sourceClassId: number | null = null;
  let matchedStudentId: number | null = null;
  let validationErrorCode = source.validationErrorCode;
  if (validationErrorCode) return { classification, decision, sourceClassId, matchedStudentId, validationErrorCode };

  const [classes]: any = await executor.query(`SELECT id FROM classes WHERE UPPER(TRIM(code))=UPPER(TRIM(?)) AND active=1`, [source.sourceClass]);
  if (classes.length !== 1) return { classification: classes.length ? 'AMBIGUOUS' : 'INVALID', decision, sourceClassId, matchedStudentId, validationErrorCode: classes.length ? 'CLASS_AMBIGUOUS' : 'CLASS_NOT_FOUND' };
  sourceClassId = Number(classes[0].id);

  const [students]: any = await executor.query(`SELECT id,status,name FROM students WHERE nis=? LIMIT 1`, [source.sourceNis]);
  if (!students[0]) {
    classification = source.sourceStatus === 'AKTIF' ? 'NEW_STUDENT' : 'HISTORICAL';
    return { classification, decision, sourceClassId, matchedStudentId, validationErrorCode: null };
  }

  matchedStudentId = Number(students[0].id);
  if (normalizedName(students[0].name) !== normalizedName(source.sourceName)) {
    return { classification: 'CONFLICT', decision, sourceClassId, matchedStudentId, validationErrorCode: 'STUDENT_NAME_CONFLICT' };
  }
  if (source.sourceStatus === 'BOYONG') {
    if (!['ACTIVE', 'BOYONG'].includes(students[0].status)) {
      return { classification: 'CONFLICT', decision, sourceClassId, matchedStudentId, validationErrorCode: 'HISTORICAL_STUDENT_STATUS_CONFLICT' };
    }
    const [targetEnrollment]: any = await executor.query(`SELECT id FROM student_enrollments WHERE student_id=? AND academic_year_id=? LIMIT 1`, [matchedStudentId, targetYearId]);
    if (targetEnrollment[0]) return { classification: 'CONFLICT', decision, sourceClassId, matchedStudentId, validationErrorCode: 'ROSTER_TARGET_ENROLLMENT_EXISTS' };
    return { classification: 'HISTORICAL', decision, sourceClassId, matchedStudentId, validationErrorCode: null };
  }

  if (students[0].status !== 'ACTIVE') {
    return { classification: 'CONFLICT', decision, sourceClassId, matchedStudentId, validationErrorCode: 'STUDENT_REACTIVATION_REQUIRES_REVIEW' };
  }
  const [targetEnrollments]: any = await executor.query(`SELECT id,class_id,status FROM student_enrollments WHERE student_id=? AND academic_year_id=? LIMIT 1`, [matchedStudentId, targetYearId]);
  if (targetEnrollments[0]) {
    if (targetEnrollments[0].status === 'ACTIVE' && Number(targetEnrollments[0].class_id) === sourceClassId) {
      return { classification: 'UNCHANGED', decision, sourceClassId, matchedStudentId, validationErrorCode: null };
    }
    return { classification: 'CONFLICT', decision, sourceClassId, matchedStudentId, validationErrorCode: 'ROSTER_TARGET_ENROLLMENT_EXISTS' };
  }
  const [previous]: any = await executor.query(`SELECT se.class_id FROM student_enrollments se JOIN academic_years ay ON ay.id=se.academic_year_id WHERE se.student_id=? AND se.academic_year_id<>? ORDER BY ay.starts_on DESC,se.id DESC LIMIT 1`, [matchedStudentId, targetYearId]);
  classification = previous[0] && Number(previous[0].class_id) !== sourceClassId ? 'CLASS_CHANGE' : 'UNCHANGED';
  return { classification, decision, sourceClassId, matchedStudentId, validationErrorCode: null };
}

function addDuplicateErrors(rows: StudentRosterSourceRow[]) {
  const grouped = new Map<string, StudentRosterSourceRow[]>();
  for (const row of rows) {
    if (!row.sourceNis) continue;
    const group = grouped.get(row.sourceNis) ?? [];
    group.push(row);
    grouped.set(row.sourceNis, group);
  }
  for (const duplicateRows of grouped.values()) {
    if (duplicateRows.length < 2) continue;
    for (const row of duplicateRows) row.validationErrorCode = [row.validationErrorCode, 'DUPLICATE_NIS_IN_SOURCE'].filter(Boolean).join('|');
  }
}

studentRosterImportRouter.get('/template', async (_req, res, next) => {
  try {
    const template = await createStudentRosterTemplate();
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="student-roster-template.xlsx"');
    res.send(template);
  } catch (error) { next(error); }
});

studentRosterImportRouter.get('/', async (_req, res, next) => {
  try {
    const [batches] = await db.query(`SELECT b.id,b.source_name,b.source_checksum,b.academic_year_id,b.status,b.created_at,b.approved_at,COUNT(r.id) total_rows,COALESCE(SUM(r.classification IN('CONFLICT','AMBIGUOUS','INVALID')),0) unresolved_rows FROM import_batches b LEFT JOIN import_student_roster_rows r ON r.batch_id=b.id WHERE b.source_type='EXCEL_STUDENT_ROSTER' GROUP BY b.id ORDER BY b.created_at DESC,b.id DESC`);
    res.json({ batches });
  } catch (error) { next(error); }
});

studentRosterImportRouter.post('/stage', upload.single('file'), async (req, res, next) => {
  try {
    if (!req.file) return void res.status(400).json({ error: 'FILE_REQUIRED' });
    if (!req.file.originalname.toLowerCase().endsWith('.xlsx') || req.file.mimetype !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') return void res.status(400).json({ error: 'INVALID_ROSTER_XLSX' });
    if (!(await validOffice(req.file.buffer, 'xl'))) return void res.status(400).json({ error: 'INVALID_ROSTER_XLSX' });
    const yearId = id.safeParse(req.body.targetYearId);
    if (!yearId.success) return void res.status(400).json({ error: 'TARGET_ACADEMIC_YEAR_REQUIRED' });
    const sourceRows = await parseStudentRosterWorkbook(req.file.buffer);
    addDuplicateErrors(sourceRows);
    const checksum = digest(req.file.buffer);
    const conn = await db.getConnection();
    const lockName = `student-import:${checksum.slice(0, 48)}`;
    let lockAcquired = false;
    try {
      const [locks]: any = await conn.query('SELECT GET_LOCK(?,10) acquired', [lockName]);
      lockAcquired = Number(locks[0]?.acquired) === 1;
      if (!lockAcquired) return void res.status(409).json({ error: 'IMPORT_SOURCE_STAGING_IN_PROGRESS' });
      await conn.beginTransaction();
      const [years]: any = await conn.query(`SELECT id,starts_on FROM academic_years WHERE id=? FOR UPDATE`, [yearId.data]);
      if (!years[0]) { await conn.rollback(); return void res.status(404).json({ error: 'TARGET_ACADEMIC_YEAR_NOT_FOUND' }); }
      if (!years[0].starts_on) { await conn.rollback(); return void res.status(409).json({ error: 'TARGET_ACADEMIC_YEAR_START_REQUIRED' }); }
      const [existing]: any = await conn.query(`SELECT id FROM import_batches WHERE source_type='EXCEL_STUDENT_ROSTER' AND source_checksum=? AND status IN('STAGED','REVIEW_REQUIRED','APPROVED','IMPORTED') LIMIT 1 FOR UPDATE`, [checksum]);
      if (existing[0]) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_SOURCE_ALREADY_STAGED' }); }
      const sourceName = safeFilename(req.file.originalname);
      const [insertBatch]: any = await conn.execute(`INSERT INTO import_batches(source_type,source_name,source_checksum,academic_year_id,status,created_by) VALUES('EXCEL_STUDENT_ROSTER',?,?,?,'STAGED',?)`, [sourceName, checksum, yearId.data, req.auth!.userId]);
      const batchId = Number(insertBatch.insertId);
      const counts: Record<string, number> = {};
      for (const row of sourceRows) {
        const classified = await classifyRow(conn, yearId.data, row);
        const validationErrorCode = row.validationErrorCode ?? classified.validationErrorCode;
        const classification = validationErrorCode ? 'INVALID' : classified.classification;
        counts[classification] = (counts[classification] ?? 0) + 1;
        await conn.execute(`INSERT INTO import_student_roster_rows(batch_id,source_row_number,source_nis,source_name,source_class,source_status,source_class_id,matched_student_id,classification,decision,validation_error_code) VALUES(?,?,?,?,?,?,?,?,?,?,?)`, [batchId, row.sourceRowNumber, row.sourceNis, row.sourceName, row.sourceClass, row.sourceStatus, classified.sourceClassId, classified.matchedStudentId, classification, classified.decision, validationErrorCode]);
      }
      await writeAudit(req, { action: 'STUDENT_ROSTER_IMPORT.STAGED', entityType: 'import_batch', entityId: batchId, metadata: { sourceName, checksum, targetAcademicYearId: yearId.data, rowCount: sourceRows.length, classifications: counts } }, conn);
      await conn.commit();
      res.status(201).json({ batchId, sourceName, checksum, academicYearId: yearId.data, rowCount: sourceRows.length, classifications: counts });
    } catch (error) {
      await conn.rollback();
      throw error;
    } finally {
      if (lockAcquired) await conn.query('SELECT RELEASE_LOCK(?)', [lockName]);
      conn.release();
    }
  } catch (error: any) {
    if (error?.status === 400 && ['INVALID_ROSTER_XLSX','ROSTER_WORKBOOK_MUST_HAVE_ONE_SHEET','ROSTER_HEADER_INVALID','ROSTER_HAS_NO_DATA_ROWS'].includes(error?.code)) return void res.status(400).json({ error: error.code });
    next(error);
  }
});

studentRosterImportRouter.get('/:batchId/review', async (req, res, next) => {
  const batchId = id.safeParse(req.params.batchId);
  if (!batchId.success) return void res.status(400).json({ error: 'INVALID_IMPORT_BATCH' });
  try {
    const [batches]: any = await db.query(`SELECT id,source_name,source_checksum,academic_year_id,status,created_at,approved_at FROM import_batches WHERE id=? AND source_type='EXCEL_STUDENT_ROSTER' LIMIT 1`, [batchId.data]);
    if (!batches[0]) return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' });
    const [rows] = await db.query(`SELECT r.*,c.code resolved_class_code,s.status matched_student_status,s.name matched_student_name FROM import_student_roster_rows r LEFT JOIN classes c ON c.id=r.source_class_id LEFT JOIN students s ON s.id=r.matched_student_id WHERE r.batch_id=? ORDER BY r.source_row_number`, [batchId.data]);
    const [classificationRows]: any = await db.query(`SELECT classification,decision,COUNT(*) row_count FROM import_student_roster_rows WHERE batch_id=? GROUP BY classification,decision`, [batchId.data]);
    const counts: Record<string, number> = {}, decisions: Record<string, number> = {};
    for (const item of classificationRows) {
      counts[item.classification] = (counts[item.classification] ?? 0) + Number(item.row_count);
      decisions[item.decision] = (decisions[item.decision] ?? 0) + Number(item.row_count);
    }
    const [[invalid]]: any = await db.query(`SELECT COUNT(*) row_count FROM import_student_roster_rows WHERE batch_id=? AND validation_error_code IS NOT NULL`, [batchId.data]);
    const [[duplicateNis]]: any = await db.query(`SELECT COUNT(*) duplicate_groups FROM (SELECT source_nis FROM import_student_roster_rows WHERE batch_id=? AND source_nis IS NOT NULL GROUP BY source_nis HAVING COUNT(*)>1) duplicates`, [batchId.data]);
    res.json({ batch: batches[0], rows, preview: { counts, decisions, invalidCount: Number(invalid.row_count), duplicateNisCount: Number(duplicateNis.duplicate_groups) } });
  } catch (error) { next(error); }
});

studentRosterImportRouter.put('/:batchId/review/:rowId', async (req, res, next) => {
  const batchId = id.safeParse(req.params.batchId), rowId = id.safeParse(req.params.rowId), input = reviewInput.safeParse(req.body);
  if (!batchId.success || !rowId.success) return void res.status(400).json({ error: 'INVALID_IMPORT_REVIEW_ID' });
  if (!input.success) return void res.status(400).json({ error: 'INVALID_ROSTER_REVIEW_DECISION' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batches]: any = await conn.query(`SELECT academic_year_id,status FROM import_batches WHERE id=? AND source_type='EXCEL_STUDENT_ROSTER' FOR UPDATE`, [batchId.data]);
    if (!batches[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (!['STAGED','REVIEW_REQUIRED'].includes(batches[0].status)) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_REVIEWABLE' }); }
    const [rows]: any = await conn.query(`SELECT * FROM import_student_roster_rows WHERE id=? AND batch_id=? FOR UPDATE`, [rowId.data, batchId.data]);
    if (!rows[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_ROW_NOT_FOUND' }); }
    const row = rows[0], decision = input.data.decision;
    if (row.validation_error_code) { await conn.rollback(); return void res.status(409).json({ error: 'ROSTER_ROW_INVALID' }); }
    if (decision === 'CREATE_NEW' && (row.source_status !== 'AKTIF' || row.classification !== 'NEW_STUDENT' || row.matched_student_id)) { await conn.rollback(); return void res.status(409).json({ error: 'ROSTER_CREATE_NEW_NOT_ELIGIBLE' }); }
    if (decision === 'REUSE_EXISTING' && (row.source_status !== 'AKTIF' || !row.matched_student_id || !['UNCHANGED','CLASS_CHANGE'].includes(row.classification))) { await conn.rollback(); return void res.status(409).json({ error: 'ROSTER_REUSE_NOT_ELIGIBLE' }); }
    if (decision === 'KEEP_HISTORICAL' && (row.source_status !== 'BOYONG' || row.matched_student_id || row.classification !== 'HISTORICAL')) { await conn.rollback(); return void res.status(409).json({ error: 'ROSTER_HISTORICAL_NOT_ELIGIBLE' }); }
    if (decision === 'MARK_BOYONG' && (row.source_status !== 'BOYONG' || !row.matched_student_id || row.classification !== 'HISTORICAL')) { await conn.rollback(); return void res.status(409).json({ error: 'ROSTER_MARK_BOYONG_NOT_ELIGIBLE' }); }
    if (decision !== 'REVIEW') {
      const [classes]: any = await conn.query(`SELECT id FROM classes WHERE id=? AND active=1 FOR UPDATE`, [row.source_class_id]);
      if (!classes[0]) { await conn.rollback(); return void res.status(409).json({ error: 'ROSTER_CLASS_CHANGED' }); }
      if (row.source_status === 'BOYONG' && row.matched_student_id) {
        const [students]: any = await conn.query(`SELECT id,status,nis FROM students WHERE id=? FOR UPDATE`, [row.matched_student_id]);
        if (!students[0] || students[0].nis !== row.source_nis || !['ACTIVE','BOYONG'].includes(students[0].status)) { await conn.rollback(); return void res.status(409).json({ error: 'ROSTER_STUDENT_CHANGED' }); }
      }
      if (row.source_status === 'BOYONG' && !row.matched_student_id) {
        const [owners]: any = await conn.query(`SELECT id FROM students WHERE nis=? FOR UPDATE`, [row.source_nis]);
        if (owners[0]) { await conn.rollback(); return void res.status(409).json({ error: 'ROSTER_NIS_ALREADY_EXISTS' }); }
      }
    }
    await conn.execute(`UPDATE import_student_roster_rows SET decision=?,review_note=?,resolved_by=?,resolved_at=NOW() WHERE id=?`, [decision, input.data.note ?? null, req.auth!.userId, rowId.data]);
    await conn.execute(`UPDATE import_batches SET status='REVIEW_REQUIRED' WHERE id=? AND status='STAGED'`, [batchId.data]);
    await writeAudit(req, { action: 'STUDENT_ROSTER_IMPORT.REVIEW_RESOLVED', entityType: 'import_student_roster_row', entityId: rowId.data, metadata: { batchId: batchId.data, classification: row.classification, decision } }, conn);
    await conn.commit();
    res.status(204).end();
  } catch (error) { await conn.rollback(); next(error); } finally { conn.release(); }
});

studentRosterImportRouter.post('/:batchId/approve', async (req, res, next) => {
  const batchId = id.safeParse(req.params.batchId);
  if (!batchId.success) return void res.status(400).json({ error: 'INVALID_IMPORT_BATCH' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batches]: any = await conn.query(`SELECT academic_year_id,status FROM import_batches WHERE id=? AND source_type='EXCEL_STUDENT_ROSTER' FOR UPDATE`, [batchId.data]);
    if (!batches[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (!['STAGED','REVIEW_REQUIRED'].includes(batches[0].status)) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_REVIEWABLE' }); }
    const [rows]: any = await conn.query(`SELECT * FROM import_student_roster_rows WHERE batch_id=? ORDER BY source_row_number FOR UPDATE`, [batchId.data]);
    if (!rows.length || rows.some((row: any) => row.validation_error_code || row.decision === 'REVIEW' || ['CONFLICT','AMBIGUOUS','INVALID'].includes(row.classification))) { await conn.rollback(); return void res.status(409).json({ error: 'ROSTER_REVIEW_INCOMPLETE' }); }
    const [duplicates]: any = await conn.query(`SELECT source_nis FROM import_student_roster_rows WHERE batch_id=? GROUP BY source_nis HAVING COUNT(*)>1`, [batchId.data]);
    if (duplicates.length) { await conn.rollback(); return void res.status(409).json({ error: 'ROSTER_DUPLICATE_NIS' }); }
    const [year]: any = await conn.query(`SELECT id FROM academic_years WHERE id=? FOR UPDATE`, [batches[0].academic_year_id]);
    if (!year[0]) { await conn.rollback(); return void res.status(409).json({ error: 'TARGET_ACADEMIC_YEAR_NOT_FOUND' }); }
    for (const row of rows) {
      const eligibleDecision = row.source_status === 'AKTIF'
        ? (row.decision === 'CREATE_NEW' && row.classification === 'NEW_STUDENT' && !row.matched_student_id)
          || (row.decision === 'REUSE_EXISTING' && Boolean(row.matched_student_id) && ['UNCHANGED','CLASS_CHANGE'].includes(row.classification))
        : (row.decision === 'KEEP_HISTORICAL' && row.classification === 'HISTORICAL' && !row.matched_student_id)
          || (row.decision === 'MARK_BOYONG' && row.classification === 'HISTORICAL' && Boolean(row.matched_student_id));
      if (!eligibleDecision) { await conn.rollback(); return void res.status(409).json({ error: 'ROSTER_DECISION_NOT_ELIGIBLE' }); }
      const [classes]: any = await conn.query(`SELECT id FROM classes WHERE id=? AND active=1 FOR UPDATE`, [row.source_class_id]);
      if (!classes[0]) throw new Error('ROSTER_CLASS_CHANGED');
      if (row.decision === 'CREATE_NEW' || row.decision === 'KEEP_HISTORICAL') {
        const [owners]: any = await conn.query(`SELECT id FROM students WHERE nis=? FOR UPDATE`, [row.source_nis]);
        if (owners[0]) throw new Error('ROSTER_NIS_ALREADY_EXISTS');
      }
      if (row.matched_student_id) {
        const [students]: any = await conn.query(`SELECT id,status,nis,name FROM students WHERE id=? FOR UPDATE`, [row.matched_student_id]);
        if (!students[0] || students[0].nis !== row.source_nis || normalizedName(students[0].name) !== normalizedName(row.source_name)) throw new Error('ROSTER_STUDENT_CHANGED');
        if (row.source_status === 'AKTIF' && students[0].status !== 'ACTIVE') throw new Error('ROSTER_STUDENT_CHANGED');
        if (row.decision === 'MARK_BOYONG' && !['ACTIVE','BOYONG'].includes(students[0].status)) throw new Error('ROSTER_STUDENT_CHANGED');
      }
      if (row.source_status === 'AKTIF' && row.decision === 'REUSE_EXISTING') {
        const [target]: any = await conn.query(`SELECT id,class_id,status FROM student_enrollments WHERE student_id=? AND academic_year_id=? FOR UPDATE`, [row.matched_student_id, batches[0].academic_year_id]);
        if (target[0] && (target[0].status !== 'ACTIVE' || Number(target[0].class_id) !== Number(row.source_class_id))) throw new Error('ROSTER_TARGET_ENROLLMENT_CONFLICT');
      }
      if (row.source_status === 'BOYONG' && row.matched_student_id) {
        const [target]: any = await conn.query(`SELECT id FROM student_enrollments WHERE student_id=? AND academic_year_id=? FOR UPDATE`, [row.matched_student_id, batches[0].academic_year_id]);
        if (target[0]) throw new Error('ROSTER_TARGET_ENROLLMENT_CONFLICT');
      }
    }
    const [result]: any = await conn.execute(`UPDATE import_batches SET status='APPROVED',approved_by=?,approved_at=NOW() WHERE id=? AND status IN('STAGED','REVIEW_REQUIRED')`, [req.auth!.userId, batchId.data]);
    if (result.affectedRows !== 1) { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_STATE_CHANGED' }); }
    await writeAudit(req, { action: 'STUDENT_ROSTER_IMPORT.APPROVED', entityType: 'import_batch', entityId: batchId.data, metadata: { academicYearId: Number(batches[0].academic_year_id), rowCount: rows.length } }, conn);
    await conn.commit();
    res.status(204).end();
  } catch (error: any) {
    await conn.rollback();
    if (approvalErrors.has(error?.message)) return void res.status(409).json({ error: error.message });
    next(error);
  } finally { conn.release(); }
});

studentRosterImportRouter.post('/:batchId/apply', async (req, res, next) => {
  const batchId = id.safeParse(req.params.batchId);
  if (!batchId.success) return void res.status(400).json({ error: 'INVALID_IMPORT_BATCH' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [batches]: any = await conn.query(`SELECT academic_year_id,status FROM import_batches WHERE id=? AND source_type='EXCEL_STUDENT_ROSTER' FOR UPDATE`, [batchId.data]);
    if (!batches[0]) { await conn.rollback(); return void res.status(404).json({ error: 'IMPORT_BATCH_NOT_FOUND' }); }
    if (batches[0].status !== 'APPROVED') { await conn.rollback(); return void res.status(409).json({ error: 'IMPORT_BATCH_NOT_APPROVED' }); }
    const [years]: any = await conn.query(`SELECT id FROM academic_years WHERE id=? FOR UPDATE`, [batches[0].academic_year_id]);
    const [targetYears]: any = await conn.query(`SELECT id,starts_on FROM academic_years WHERE id=? FOR UPDATE`, [batches[0].academic_year_id]);
    if (!years[0]) throw new Error('TARGET_ACADEMIC_YEAR_NOT_FOUND');
    if (!targetYears[0]?.starts_on) throw new Error('TARGET_ACADEMIC_YEAR_START_REQUIRED');
    const [rows]: any = await conn.query(`SELECT * FROM import_student_roster_rows WHERE batch_id=? ORDER BY source_row_number FOR UPDATE`, [batchId.data]);
    const seenNis = new Set<string>();
    const summary = { createdActive: 0, enrolledExisting: 0, createdHistorical: 0, markedBoyong: 0, unchanged: 0 };
    for (const row of rows) {
      const nis = String(row.source_nis ?? '').trim();
      if (!nis || seenNis.has(nis) || row.validation_error_code || row.decision === 'REVIEW') throw new Error('ROSTER_REVIEW_INCOMPLETE');
      seenNis.add(nis);
      const [validClasses]: any = await conn.query(`SELECT id FROM classes WHERE id=? AND active=1 FOR UPDATE`, [row.source_class_id]);
      if (!validClasses[0]) throw new Error('ROSTER_CLASS_CHANGED');
      let studentId = row.matched_student_id == null ? null : Number(row.matched_student_id);
      if (row.decision === 'CREATE_NEW') {
        if (row.source_status !== 'AKTIF' || studentId) throw new Error('ROSTER_STUDENT_CHANGED');
        const [owners]: any = await conn.query(`SELECT id FROM students WHERE nis=? FOR UPDATE`, [nis]);
        if (owners[0]) throw new Error('ROSTER_NIS_ALREADY_EXISTS');
        const [created]: any = await conn.execute(`INSERT INTO students(nis,name,status,source_reference,official_source_batch_id) VALUES(?,?,'ACTIVE','EXCEL_STUDENT_ROSTER',?)`, [nis, row.source_name, batchId.data]);
        studentId = Number(created.insertId);
        await conn.execute(`INSERT INTO student_enrollments(student_id,class_id,academic_year_id,status,started_on,ended_on) VALUES(?,?,?,'ACTIVE',?,NULL)`, [studentId, row.source_class_id, batches[0].academic_year_id, targetYears[0].starts_on]);
        summary.createdActive++;
      } else if (row.decision === 'KEEP_HISTORICAL') {
        if (row.source_status !== 'BOYONG' || studentId) throw new Error('ROSTER_STUDENT_CHANGED');
        const [owners]: any = await conn.query(`SELECT id FROM students WHERE nis=? FOR UPDATE`, [nis]);
        if (owners[0]) throw new Error('ROSTER_NIS_ALREADY_EXISTS');
        const [created]: any = await conn.execute(`INSERT INTO students(nis,name,status,source_reference,official_source_batch_id) VALUES(?,?,'BOYONG','EXCEL_STUDENT_ROSTER',?)`, [nis, row.source_name, batchId.data]);
        studentId = Number(created.insertId);
        summary.createdHistorical++;
      } else if (row.decision === 'MARK_BOYONG') {
        if (row.source_status !== 'BOYONG' || !studentId) throw new Error('ROSTER_STUDENT_CHANGED');
        const [students]: any = await conn.query(`SELECT id,status,nis,name FROM students WHERE id=? FOR UPDATE`, [studentId]);
        if (!students[0] || students[0].nis !== nis || normalizedName(students[0].name) !== normalizedName(row.source_name) || !['ACTIVE','BOYONG'].includes(students[0].status)) throw new Error('ROSTER_STUDENT_CHANGED');
        const [target]: any = await conn.query(`SELECT id FROM student_enrollments WHERE student_id=? AND academic_year_id=? FOR UPDATE`, [studentId, batches[0].academic_year_id]);
        if (target[0]) throw new Error('ROSTER_TARGET_ENROLLMENT_CONFLICT');
        if (students[0].status === 'ACTIVE') {
          const [activeEnrollments]: any = await conn.query(`SELECT se.id,ay.starts_on FROM student_enrollments se JOIN academic_years ay ON ay.id=se.academic_year_id WHERE se.student_id=? AND se.status='ACTIVE' FOR UPDATE`, [studentId]);
          const prior = activeEnrollments.filter((enrollment: any) => enrollment.starts_on && new Date(enrollment.starts_on) < new Date(targetYears[0].starts_on));
          if (prior.length > 1 || activeEnrollments.length !== prior.length) throw new Error('ROSTER_TARGET_ENROLLMENT_CONFLICT');
          for (const enrollment of prior) await conn.execute(`UPDATE student_enrollments SET status='BOYONG',ended_on=DATE_SUB(?,INTERVAL 1 DAY) WHERE id=? AND status='ACTIVE'`, [targetYears[0].starts_on, enrollment.id]);
          await conn.execute(`UPDATE students SET status='BOYONG' WHERE id=? AND status='ACTIVE'`, [studentId]);
        }
        summary.markedBoyong++;
      } else if (row.decision === 'REUSE_EXISTING') {
        if (row.source_status !== 'AKTIF' || !studentId) throw new Error('ROSTER_STUDENT_CHANGED');
        const [students]: any = await conn.query(`SELECT id,status,nis,name FROM students WHERE id=? FOR UPDATE`, [studentId]);
        if (!students[0] || students[0].nis !== nis || normalizedName(students[0].name) !== normalizedName(row.source_name) || students[0].status !== 'ACTIVE') throw new Error('ROSTER_STUDENT_CHANGED');
        const [target]: any = await conn.query(`SELECT id,class_id,status FROM student_enrollments WHERE student_id=? AND academic_year_id=? FOR UPDATE`, [studentId, batches[0].academic_year_id]);
        if (target[0]) {
          if (target[0].status !== 'ACTIVE' || Number(target[0].class_id) !== Number(row.source_class_id)) throw new Error('ROSTER_TARGET_ENROLLMENT_CONFLICT');
          summary.unchanged++;
        } else {
          await conn.execute(`INSERT INTO student_enrollments(student_id,class_id,academic_year_id,status,started_on,ended_on) VALUES(?,?,?,'ACTIVE',?,NULL)`, [studentId, row.source_class_id, batches[0].academic_year_id, targetYears[0].starts_on]);
          summary.enrolledExisting++;
        }
      } else throw new Error('ROSTER_REVIEW_INCOMPLETE');
      if (!studentId) throw new Error('ROSTER_STUDENT_CHANGED');
      await conn.execute(`UPDATE import_student_roster_rows SET matched_student_id=? WHERE id=?`, [studentId, row.id]);
    }
    const [result]: any = await conn.execute(`UPDATE import_batches SET status='IMPORTED' WHERE id=? AND status='APPROVED'`, [batchId.data]);
    if (result.affectedRows !== 1) throw new Error('IMPORT_BATCH_STATE_CHANGED');
    await writeAudit(req, { action: 'STUDENT_ROSTER_IMPORT.APPLIED', entityType: 'import_batch', entityId: batchId.data, metadata: { academicYearId: Number(batches[0].academic_year_id), rowCount: rows.length, ...summary } }, conn);
    await conn.commit();
    res.json({ batchId: batchId.data, academicYearId: Number(batches[0].academic_year_id), rowCount: rows.length, ...summary });
  } catch (error: any) {
    await conn.rollback();
    if (['TARGET_ACADEMIC_YEAR_NOT_FOUND','TARGET_ACADEMIC_YEAR_START_REQUIRED','ROSTER_REVIEW_INCOMPLETE','ROSTER_STUDENT_CHANGED','ROSTER_NIS_ALREADY_EXISTS','ROSTER_TARGET_ENROLLMENT_CONFLICT','ROSTER_CLASS_CHANGED','IMPORT_BATCH_STATE_CHANGED'].includes(error?.message)) return void res.status(409).json({ error: error.message });
    next(error);
  } finally { conn.release(); }
});
