import { writeAudit } from "../audit/audit.service.js";
import { Router } from "express";
import { z } from "zod";
import { db } from "../../config/db.js";
import { requireAuthentication } from "../../middleware/authentication.js";
import {
  requirePermission,
  requireRole,
} from "../../middleware/authorization.js";
export const supportRouter = Router();
supportRouter.use(requireAuthentication);
supportRouter.get("/calendar", async (_req, res, next) => {
  try {
    const [rows] = await db.query(
      `SELECT id,academic_year_id,title,category,starts_on,ends_on,locks_attendance,description FROM calendar_events ORDER BY starts_on`,
    );
    res.json({ events: rows });
  } catch (e) {
    next(e);
  }
});
const calendarSchema = z
  .object({
    academicYearId: z.number().int().positive().nullable().optional(),
    title: z.string().trim().min(1).max(200),
    startsOn: z.string().date(),
    endsOn: z.string().date(),
    category: z.enum([
      "KBM",
      "UJIAN",
      "LIBUR",
      "PONDOK",
      "MUHAFADLOH",
      "LAINNYA",
    ]),
    locksAttendance: z.boolean().default(false),
    description: z.string().trim().max(3000).nullable().optional(),
  })
  .refine((v) => v.endsOn >= v.startsOn);
supportRouter.post(
  "/calendar",
  requirePermission("schedules.manage"),
  async (req, res, next) => {
    const x = calendarSchema.safeParse(req.body);
    if (!x.success) {
      res.status(400).json({ error: "INVALID_CALENDAR_EVENT" });
      return;
    }
    const conn = await db.getConnection();
    try {
      const p = x.data;
      await conn.beginTransaction();
      const [r]: any = await conn.execute(
        `INSERT INTO calendar_events(academic_year_id,title,category,starts_on,ends_on,locks_attendance,description,created_by) VALUES(?,?,?,?,?,?,?,?)`,
        [
          p.academicYearId ?? null,
          p.title,
          p.category,
          p.startsOn,
          p.endsOn,
          p.locksAttendance,
          p.description ?? null,
          req.auth!.userId,
        ],
      );
      await writeAudit(req,{action:"CALENDAR.CREATED",entityType:"calendar_event",entityId:r.insertId,metadata:{title:p.title,category:p.category,startsOn:p.startsOn,endsOn:p.endsOn}},conn);
      await conn.commit();
      res.status(201).json({ id: r.insertId });
    } catch (e) {
      await conn.rollback();
      next(e);
    } finally {
      conn.release();
    }
  },
);
supportRouter.get("/documents", async (req, res, next) => {
  try {
    const role = req.auth!.role;
    const managesDocuments = req.auth!.permissions.includes("documents.manage");
    const [rows] = managesDocuments
      ? await db.query(
          `SELECT id,category,title,description,mime_type,file_size,audience,published,created_at FROM documents WHERE (?='SUPER_ADMIN' OR audience<>'SUPER_ADMIN') ORDER BY created_at DESC`,
          [role],
        )
      : await db.query(
          `SELECT id,category,title,description,mime_type,file_size,audience,published,created_at FROM documents WHERE published=1 AND (audience='ALL' OR audience=? OR ?='SUPER_ADMIN') ORDER BY created_at DESC`,
          [role, role],
        );
    res.json({ documents: rows });
  } catch (e) {
    next(e);
  }
});
supportRouter.get("/announcements", async (req, res, next) => {
  try {
    const role = req.auth!.role,
      audience = role === "GURU" ? "GURU" : role === "SANTRI" ? "SANTRI" : null;
    const [rows] = audience
      ? await db.query(
          `SELECT id,title,body,published_at FROM announcements WHERE published_at IS NOT NULL AND published_at<=NOW() AND audience IN('ALL',?) ORDER BY published_at DESC`,
          [audience],
        )
      : await db.query(
          `SELECT id,title,body,audience,published_at FROM announcements WHERE published_at IS NOT NULL AND published_at<=NOW() ORDER BY published_at DESC`,
        );
    res.json({ announcements: rows });
  } catch (e) {
    next(e);
  }
});
const ann = z.object({
  title: z.string().trim().min(1).max(255),
  body: z.string().trim().min(1).max(20000),
  audience: z.enum(["ALL", "GURU", "SANTRI"]),
  publish: z.boolean().default(false),
});
supportRouter.post(
  "/announcements",
  requirePermission("announcements.manage"),
  async (req, res, next) => {
    const x = ann.safeParse(req.body);
    if (!x.success) {
      res.status(400).json({ error: "INVALID_ANNOUNCEMENT" });
      return;
    }
    const conn = await db.getConnection();
    try {
      const p = x.data;
      await conn.beginTransaction();
      const [r]: any = await conn.execute(
        `INSERT INTO announcements(title,body,audience,published_at,created_by) VALUES(?,?,?,${p.publish ? "NOW()" : "NULL"},?)`,
        [p.title, p.body, p.audience, req.auth!.userId],
      );
      await writeAudit(req,{action:"ANNOUNCEMENT.CREATED",entityType:"announcement",entityId:r.insertId,metadata:{title:p.title,audience:p.audience,published:p.publish}},conn);
      await conn.commit();
      res.status(201).json({ id: r.insertId });
    } catch (e) {
      await conn.rollback();
      next(e);
    } finally {
      conn.release();
    }
  },
);
supportRouter.get("/notifications/me", async (req, res, next) => {
  try {
    const [rows] = await db.query(
      `SELECT id,title,message,type,module,entity_id,read_at,created_at FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 100`,
      [req.auth!.userId],
    );
    res.json({ notifications: rows });
  } catch (e) {
    next(e);
  }
});
supportRouter.patch("/notifications/:id/read", async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isSafeInteger(id) || id <= 0) {
      res.status(400).json({ error: "INVALID_NOTIFICATION_ID" });
      return;
    }
    const [r]: any = await db.execute(
      `UPDATE notifications SET read_at=COALESCE(read_at,NOW()) WHERE id=? AND user_id=?`,
      [id, req.auth!.userId],
    );
    if (!r.affectedRows) {
      res.status(404).json({ error: "NOTIFICATION_NOT_FOUND" });
      return;
    }
    res.status(204).end();
  } catch (e) {
    next(e);
  }
});
const feedback = z.object({
  category: z.enum([
    "KURIKULUM",
    "KEDISIPLINAN",
    "FASILITAS",
    "SANTRI",
    "LAINNYA",
  ]),
  title: z.string().trim().min(1).max(255),
  message: z.string().trim().min(1).max(10000),
});
supportRouter.post("/feedback", requireRole("GURU"), async (req, res, next) => {
  try {
    if (!req.auth!.teacherId) {
      res.status(403).json({ error: "TEACHER_PROFILE_REQUIRED" });
      return;
    }
    const x = feedback.safeParse(req.body);
    if (!x.success) {
      res.status(400).json({ error: "INVALID_FEEDBACK" });
      return;
    }
    const p = x.data,
      [r]: any = await db.execute(
        `INSERT INTO feedback(teacher_id,category,title,message) VALUES(?,?,?,?)`,
        [req.auth!.teacherId, p.category, p.title, p.message],
      );
    res.status(201).json({ id: r.insertId });
  } catch (e) {
    next(e);
  }
});
supportRouter.get(
  "/feedback/me",
  requireRole("GURU"),
  async (req, res, next) => {
    try {
      if (!req.auth!.teacherId) {
        res.status(403).json({ error: "TEACHER_PROFILE_REQUIRED" });
        return;
      }
      const [rows] = await db.query(
        `SELECT id,category,title,message,response,responded_at,read_at,created_at FROM feedback WHERE teacher_id=? ORDER BY created_at DESC`,
        [req.auth!.teacherId],
      );
      res.json({ feedback: rows });
    } catch (e) {
      next(e);
    }
  },
);
supportRouter.get(
  "/feedback/admin",
  requirePermission("feedback.manage"),
  async (_req, res, next) => {
    try {
      const [rows] = await db.query(
        `SELECT f.id,f.category,f.title,f.message,f.response,f.responded_at,f.read_at,f.created_at,t.name AS teacher_name FROM feedback f JOIN teachers t ON t.id=f.teacher_id ORDER BY f.created_at DESC`,
      );
      res.json({ feedback: rows });
    } catch (e) {
      next(e);
    }
  },
);
const feedbackResponse = z.object({ response: z.string().trim().min(1).max(10000) }).strict();
supportRouter.patch(
  "/feedback/admin/:feedbackId/respond",
  requirePermission("feedback.manage"),
  async (req, res, next) => {
    const id = Number(req.params.feedbackId);
    const parsed = feedbackResponse.safeParse(req.body);
    if (!Number.isSafeInteger(id) || id <= 0 || !parsed.success) {
      res.status(400).json({ error: "INVALID_FEEDBACK_RESPONSE" });
      return;
    }
    const conn = await db.getConnection();
    try {
      await conn.beginTransaction();
      const [rows]: any = await conn.query("SELECT id,teacher_id,title FROM feedback WHERE id=? FOR UPDATE", [id]);
      if (!rows[0]) {
        await conn.rollback();
        res.status(404).json({ error: "FEEDBACK_NOT_FOUND" });
        return;
      }
      await conn.execute(
        "UPDATE feedback SET response=?,responded_by=?,responded_at=NOW(),read_at=COALESCE(read_at,NOW()) WHERE id=?",
        [parsed.data.response, req.auth!.userId, id],
      );
      await conn.execute(
        `INSERT INTO notifications(user_id,title,message,type,module,entity_id)
         SELECT tul.user_id,'Kritik & Saran dijawab',?, 'SUCCESS','feedback',?
         FROM teacher_user_links tul JOIN users u ON u.id=tul.user_id AND u.status='ACTIVE'
         WHERE tul.teacher_id=?`,
        [`Admin menjawab: ${rows[0].title}`, id, rows[0].teacher_id],
      );
      await writeAudit(req, { action: "FEEDBACK.RESPONDED", entityType: "feedback", entityId: id }, conn);
      await conn.commit();
      res.status(204).end();
    } catch (error) {
      await conn.rollback();
      next(error);
    } finally {
      conn.release();
    }
  },
);
supportRouter.get(
  "/settings/operational",
  requirePermission("settings.operational.manage"),
  async (_req, res, next) => {
    try {
      const [rows] = await db.query(
        `SELECT setting_key,setting_value FROM system_settings WHERE scope='OPERATIONAL' ORDER BY setting_key`,
      );
      res.json({ settings: rows });
    } catch (e) {
      next(e);
    }
  },
);
const setting = z
  .object({
    key: z
      .string()
      .trim()
      .regex(/^[a-z0-9._-]{1,150}$/),
    value: z.json(),
  })
  .strict();
supportRouter.put(
  "/settings/operational",
  requirePermission("settings.operational.manage"),
  async (req, res, next) => {
    const x = setting.safeParse(req.body);
    if (!x.success) {
      res.status(400).json({ error: "INVALID_SETTING" });
      return;
    }
    const conn = await db.getConnection();
    try {
      await conn.beginTransaction();
      const [current]: any = await conn.query(
        "SELECT scope,setting_value FROM system_settings WHERE setting_key=? FOR UPDATE",
        [x.data.key],
      );
      if (current[0] && current[0].scope !== "OPERATIONAL") {
        await conn.rollback();
        res.status(403).json({ error: "TECHNICAL_SETTING_FORBIDDEN" });
        return;
      }
      if (
        /^(system|auth|integration|app|feature|security)[._-]/.test(x.data.key)
      ) {
        await conn.rollback();
        res.status(403).json({ error: "RESERVED_SETTING_KEY" });
        return;
      }
      await conn.execute(
        "INSERT INTO system_settings(setting_key,setting_value,scope,updated_by) VALUES(?,?,'OPERATIONAL',?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_by=VALUES(updated_by)",
        [x.data.key, JSON.stringify(x.data.value), req.auth!.userId],
      );
      await writeAudit(
        req,
        {
          action: "SETTINGS.OPERATIONAL_UPDATED",
          entityType: "setting",
          entityId: x.data.key,
          metadata: {
            before: current[0]?.setting_value ?? null,
            after: x.data.value,
          },
        },
        conn,
      );
      await conn.commit();
      res.status(204).end();
    } catch (e) {
      await conn.rollback();
      next(e);
    } finally {
      conn.release();
    }
  },
);
