import 'dotenv/config';
import { z } from 'zod';

const schema = z.object({
  NODE_ENV: z.enum(['development','test','production']).default('development'),
  PORT: z.coerce.number().int().positive().default(3000),
  FRONTEND_ORIGIN: z.string().url(),
  DB_HOST: z.string().min(1),
  DB_PORT: z.coerce.number().int().positive().default(3306),
  DB_NAME: z.string().min(1),
  DB_USER: z.string().min(1),
  DB_PASSWORD: z.string(),
  AUTH_JWT_SECRET: z.string().min(32),
  AUTH_COOKIE_NAME: z.string().min(1).default('madin_session'),
  AUTH_TOKEN_MINUTES: z.coerce.number().int().positive().max(1440).default(480),
  UPLOAD_ROOT: z.string().min(1).optional(),
  SMTP_HOST: z.string().min(1).optional(),
  SMTP_PORT: z.coerce.number().int().positive().default(465),
  SMTP_USER: z.string().email().optional(),
  SMTP_PASSWORD: z.string().min(1).optional(),
  SUPER_ADMIN_RECOVERY_EMAIL: z.string().email().optional(),
});

const parsed = schema.parse(process.env);
if(parsed.NODE_ENV==='production'){
  if(!parsed.FRONTEND_ORIGIN.startsWith('https://')) throw new Error('FRONTEND_ORIGIN must use HTTPS in production');
  if(parsed.AUTH_JWT_SECRET.includes('CHANGE_ME')||parsed.AUTH_JWT_SECRET.length<48) throw new Error('AUTH_JWT_SECRET must be a strong production secret (48+ characters)');
  if(!parsed.DB_PASSWORD) throw new Error('DB_PASSWORD must not be empty in production');
  if(!parsed.UPLOAD_ROOT) throw new Error('UPLOAD_ROOT must be explicitly configured in production');
  if(!parsed.SMTP_HOST||!parsed.SMTP_USER||!parsed.SMTP_PASSWORD||!parsed.SUPER_ADMIN_RECOVERY_EMAIL) throw new Error('SMTP and Super Admin recovery email must be configured in production');
  if(parsed.SMTP_USER.toLowerCase()!==parsed.SUPER_ADMIN_RECOVERY_EMAIL.toLowerCase()) throw new Error('Super Admin recovery sender and recipient must match');
}
export const env = parsed;
export const isProduction = env.NODE_ENV === 'production';
