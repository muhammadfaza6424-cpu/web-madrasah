import 'dotenv/config';
import mysql from 'mysql2/promise';
import bcrypt from 'bcrypt';
import readline from 'node:readline';

if(!process.stdin.isTTY||!process.stdout.isTTY)throw new Error('Run this recovery only in a private interactive terminal.');
const ask=prompt=>new Promise(resolve=>{const rl=readline.createInterface({input:process.stdin,output:process.stdout});rl.question(prompt,answer=>{rl.close();resolve(answer.trim())})});
const askHidden=prompt=>new Promise(resolve=>{process.stdout.write(prompt);let value='';process.stdin.setRawMode(true);process.stdin.resume();const onData=chunk=>{for(const byte of chunk){if(byte===3){process.stdin.setRawMode(false);process.stdin.off('data',onData);process.stdout.write('\n');process.exit(130)}if(byte===13||byte===10){process.stdin.setRawMode(false);process.stdin.off('data',onData);process.stdout.write('\n');resolve(value);return}if(byte===127||byte===8)value=value.slice(0,-1);else value+=String.fromCharCode(byte)}};process.stdin.on('data',onData)});
const username=await ask('Username Super Admin: ');
const password=await askHidden('Password pengganti (12–72 karakter, tidak tampil): ');
if(password.length<12||password.length>72||Buffer.byteLength(password,'utf8')>72)throw new Error('Password must contain 12–72 characters and fit within 72 UTF-8 bytes.');
const confirm=await askHidden('Ulangi password pengganti: ');
if(confirm!==password)throw new Error('Password confirmation differs.');
const conn=await mysql.createConnection({host:process.env.DB_HOST,port:Number(process.env.DB_PORT??3306),database:process.env.DB_NAME,user:process.env.DB_USER,password:process.env.DB_PASSWORD});
try{await conn.beginTransaction();const[rows]=await conn.query("SELECT u.id FROM users u JOIN roles r ON r.id=u.role_id WHERE u.username=? AND r.code='SUPER_ADMIN' AND u.status='ACTIVE' FOR UPDATE",[username]);if(rows.length!==1)throw new Error('Active Super Admin account not found.');await conn.execute('UPDATE users SET password_hash=?,must_change_password=1,session_version=session_version+1 WHERE id=?',[await bcrypt.hash(password,12),rows[0].id]);await conn.execute("INSERT INTO audit_logs(user_id,action,entity_type,entity_id,metadata) VALUES(?,?,?,?,?)",[rows[0].id,'AUTH.SUPER_ADMIN_RECOVERED','user',String(rows[0].id),JSON.stringify({method:'server_console'})]);await conn.commit();process.stdout.write('Password reset. Log in and change the temporary password immediately.\n')}catch(e){await conn.rollback();throw e}finally{await conn.end()}
