# AUDIT ABSENSI — MADRASAH DINIYAH

- **Tanggal audit:** 2 Oktober 2026
- **Workspace:** `/var/www/madrasah-dev` (isolated development workspace)
- **Status:** AUDIT ONLY — tidak ada source code, migration, dependency, deployment, atau push GitHub yang diubah.
- **Referensi target workflow:** `AGENTS.md` bagian "Current task: Attendance".

---

## 1. File yang Diperiksa

### Backend
| File | Peran |
|---|---|
| `backend/src/server.ts` | Registrasi route; mount `attendanceRouter` di `/api/attendance`, `attendanceImportRouter` di `/api/imports/attendance` |
| `backend/src/modules/attendance/attendance.routes.ts` | Seluruh endpoint absensi (read + write manual) |
| `backend/src/modules/imports/attendance-import.routes.ts` | Import absensi Excel (stage/review/approve/apply) |
| `backend/src/modules/imports/attendance-xlsx.ts` | Parser & template XLSX absensi |
| `backend/src/modules/imports/attendance-xlsx.test.ts` | Unit test parser absensi |
| `backend/src/middleware/authentication.ts` | Verifikasi sesi JWT/cookie |
| `backend/src/middleware/authorization.ts` | `requireRole`, `requirePermission`, `requireSuperAdmin` |
| `backend/src/middleware/mutationAudit.ts` | Audit otomatis untuk semua mutasi sukses |
| `backend/src/modules/audit/audit.service.ts` | `writeAudit()` ke `audit_logs` |
| `backend/src/modules/audit/audit.routes.ts` | Baca audit log |
| `backend/src/modules/auth/auth.service.ts` | Pembentukan principal (`role`, `permissions`, `teacherId`, `studentId`) |
| `backend/src/modules/assignments/assignment.routes.ts` | `teaching_assignments` per tahun/semester |
| `backend/src/modules/schedules/schedule.routes.ts` | CRUD jadwal, deteksi bentrok guru/kelas |
| `backend/src/modules/classes/class.routes.ts` | Kelas per-role + penugasan mengajar/wali kelas |
| `backend/src/modules/teachers/teacher.routes.ts` | Guru + `me/students` (scope guru) |
| `backend/src/modules/support/support.routes.ts` | Kalender & `locks_attendance` |
| `backend/src/modules/support/operations.routes.ts` | CRUD generik `assignments`/`homerooms` |
| `backend/src/modules/reports/report.routes.ts` | Rekap absensi dipakai di snapshot raport |

### Frontend
| File | Peran |
|---|---|
| `frontend/src/app/App.tsx` | Navigasi, role map, routing halaman "Absensi" |
| `frontend/src/features/academic/AcademicEditor.tsx` | Editor absensi manual per kelas (halaman "Absensi" untuk non-Santri) |
| `frontend/src/features/academic/AcademicPage.tsx` | Tampilan absensi read-only (Guru/Santri) |
| `frontend/src/features/academic/ScheduleEditor.tsx` | Editor jadwal (Admin/Super Admin) |
| `frontend/src/features/production/AttendanceImport.tsx` | UI import absensi Excel |
| `frontend/src/features/admin/OperationsPage.tsx` | Administrasi penugasan/wali kelas |
| `frontend/src/services/api.ts` | Klien API |

### Database
`database/migrations/001_initial_schema.sql`, `002_import_staging.sql`, `005_academic_terms.sql`, `008_attendance_import_provenance.sql`, `011_enrollment_status_alignment.sql`, `012_user_session_version.sql`, `018_muhafadloh_execution_targets.sql`, `025_production_invariants.sql`, `028_enrollment_repeated.sql`, `database/seeds/001_roles_permissions.sql`, `database/README.md`.

### Lain-lain
`AGENTS.md`, `package.json`, `scripts/import/reconcile.ts`, `database/import/README.md`.

---

## 2. Arsitektur Absensi Saat Ini

- **Backend:** Express 5 + TypeScript ESM, MySQL 8 (`mysql2/promise`), Zod untuk validasi, JWT cookie session (`session_version` untuk revokasi). Pola arsitektur **route-only** (tidak ada service/controller terpisah); query SQL langsung di route.
- **Frontend:** React 19 + Vite, klien `fetch` terpusat di `services/api.ts`, navigasi berbasis `page` state (bukan router).
- **Konsep absensi:** Satu baris absensi = **(santri, tanggal)**, terhubung ke satu `class_id` dan `academic_year_id`. **Tidak ada dimensi sesi/jadwal/mata pelajaran** pada tabel `attendance`.
- **Dua jalur input:**
  1. **Manual** (`PUT /api/attendance`) — satu santri per request, `source='MANUAL'`.
  2. **Import Excel** (`/api/imports/attendance`) — staging → review → approve → apply, `source='IMPORT_EXCEL'`.
- **Rekap** dihitung on-the-fly via `SUM(status=...)` (bukan tabel rekap tersimpan); juga disisipkan ke snapshot raport dari `academic_terms`.
- **Otorisasi:** Berbasis role + permission (`attendance.manage`, `attendance.import.manage`) plus scope guru (teaching/homeroom assignment aktif pada tahun ajaran terkait).
- **Audit:** Setiap mutasi sukses dicatat otomatis oleh middleware `auditSuccessfulMutation`; absensi manual & import juga menulis audit eksplisit (`ATTENDANCE.UPDATED`, `ATTENDANCE_IMPORT.*`, `IMPORT.APPLIED`).

---

## 3. Alur Absensi Saat Ini

### 3.1 Input Manual (satu per satu)
1. Guru/Admin memilih **Kelas** + **Tanggal** di `AcademicEditor` (halaman "Absensi").
2. `GET /api/attendance/class/:classId?from=<tgl>&to=<tgl>`:
   - Menentukan tahun ajaran dari rentang tanggal (`academic_years.starts_on/ends_on`).
   - Bila role GURU: cek `teaching_assignments` ATAU `homeroom_assignments` aktif (`active=1`) untuk kelas+tahun tersebut, jika tidak → `403 OUTSIDE_TEACHER_SCOPE`.
   - Mengembalikan daftar siswa terdaftar (`student_enrollments` status `ACTIVE/PROMOTED/GRADUATED`) join `attendance` pada rentang tanggal.
3. UI menampilkan dropdown status **H / S / I / A**; tombol Simpan per baris.
4. `PUT /api/attendance` dengan `{studentId, attendanceDate, status}`:
   - Transaksi; `SELECT ... FOR UPDATE` pada role SUPER_ADMIN sebagai semacam lock global.
   - Mencari enrollment santri pada tanggal tersebut; jika tidak ada → `400 NO_ENROLLMENT_FOR_DATE`.
   - Jika GURU: cek scope teaching/homeroom di dalam transaksi.
   - Cek `calendar_events.locks_attendance=1` → `409 ATTENDANCE_LOCKED`.
   - `INSERT ... ON DUPLICATE KEY UPDATE` (upsert) pada `attendance`, `source='MANUAL'`, `recorded_by=userId`.
   - Tulis audit `ATTENDANCE.UPDATED`, commit, `204`.
5. Setelah simpan, UI memuat ulang data.

### 3.2 Import Excel
1. SUPER_ADMIN membuka `AttendanceImport`, unduh template (`GET /api/imports/attendance/template`).
2. `POST /api/imports/attendance/stage` (multipart XLSX ≤10MB): validasi Office/OOXML, parse sheet tunggal dengan header **NIS, Nama, Kelas, Tanggal, Status**, hitung checksum, cegah batch duplikat, simpan ke `import_batches` + `import_attendance_rows` (staging).
3. Review: `GET .../:batchId/review`, `PUT .../:batchId/review/:rowId` (mencocokkan NIS resmi tepat; nama/kelas tidak dipakai untuk auto-match).
4. `POST .../:batchId/approve` → status APPROVED (semua baris harus resolved & tidak duplikat).
5. `POST .../:batchId/apply` → upsert ke `attendance` `source='IMPORT_EXCEL'`; enrollment harus tunggal & cocok kelas sumber; **menolak menimpa absensi `source='MANUAL'`** (`MANUAL_ATTENDANCE_EXISTS`).

### 3.3 Pembacaan
- Guru/Santri: `AcademicPage` (read-only) via `GET /api/attendance/class/:classId` atau `GET /api/attendance/student/me`.
- Rekap: query agregat per siswa/periode; untuk raport memakai rentang `academic_terms` per semester.

---

## 4. Role dan Authorization

### Role (seed `001_roles_permissions.sql`)
- `SUPER_ADMIN` — semua permission (`CROSS JOIN permissions`).
- `ADMIN` — termasuk `attendance.manage`, `attendance.import.manage`, `schedules.manage`.
- `GURU` — `attendance.manage`, `grades.manage`, `muhafadloh.manage`, `teaching.scope.read`, `reports.manage` (raport **hanya wali kelas / homeroom**), `feedback.create`.
- `SANTRI` — `own.academic.read` saja.

### Matriks Endpoint Absensi
| Endpoint | Role | Permission | Scope |
|---|---|---|---|
| `GET /api/attendance/student/me` | SANTRI | (authenticated) | Hanya `studentId` milik sendiri |
| `GET /api/attendance/class/:classId` | SUPER_ADMIN, ADMIN, GURU | `attendance.manage` | GURU wajib teaching/homeroom aktif |
| `PUT /api/attendance` | SUPER_ADMIN, ADMIN, GURU | `attendance.manage` | GURU cek scope saat write |
| `GET/POST /api/imports/attendance/*` | semua role login | `attendance.import.manage` | Hanya SUPER_ADMIN & ADMIN punya permission |
| `GET /api/audit` | — | `system.audit.read` | Hanya SUPER_ADMIN |

### Catatan
- Middleware `requireAuthentication` membaca cookie JWT, memuat ulang principal dari DB (role + permission + `teacherId`/`studentId`), dan menolak sesi dengan `session_version` lama.
- `requirePermission` hanya memeriksa permission, **bukan** role; UI menyembunyikan menu tapi backend tetap otoritatif.
- Scope guru diperluas: **guru pengampu (teaching_assignment) juga boleh menulis absensi kelas**, bukan hanya wali kelas. (Raport dibatasi hanya wali kelas.)

---

## 5. Struktur Database dan Relasi

### Tabel inti (`001_initial_schema.sql`)
```
roles ── role_permissions ── permissions
users ──┬── teacher_user_links ── teachers
        └── student_user_links ── students

academic_years
classes
subjects

teaching_assignments (teacher_id, class_id, subject_id, academic_year_id, semester, active)
  UNIQUE (teacher_id, class_id, subject_id, academic_year_id, semester)

homeroom_assignments (teacher_id, class_id, academic_year_id, assignment_type[WALI_KELAS|MUSRIF], active)
  UNIQUE (teacher_id, class_id, academic_year_id, assignment_type)

schedules (teaching_assignment_id, day_of_week, starts_at, ends_at, room_name, active)

student_enrollments (student_id, academic_year_id, class_id, status, started_on, ended_on)
  UNIQUE (student_id, academic_year_id)

attendance (
  id, student_id, class_id, academic_year_id, attendance_date DATE, status ENUM('H','S','I','A'),
  source ENUM('IMPORT_EXCEL','MANUAL','SYSTEM'), source_reference, recorded_by,
  import_row_id (008), created_at, updated_at
)
  UNIQUE (student_id, attendance_date)      <-- KUNCI UTAMA KEUNIKAN
  INDEX (class_id, attendance_date)

calendar_events (academic_year_id, title, category, starts_on, ends_on, locks_attendance)

academic_terms (academic_year_id, semester, starts_on, ends_on) UNIQUE(year,semester)

audit_logs (user_id, action, entity_type, entity_id, metadata JSON, ip_address, user_agent)
```

### Import staging (`002_import_staging.sql` + `008`)
```
import_batches (source_type[.. EXCEL_ATTENDANCE ..], status[STAGED|REVIEW_REQUIRED|APPROVED|IMPORTED|FAILED])
import_attendance_rows (batch_id, source_row_number, source_nis, source_name, source_class,
   attendance_date, attendance_status, matched_student_id, match_status, review_note)
attendance.import_row_id ──> import_attendance_rows.id  (UNIQUE)
```

### Relasi kunci
- `attendance.student_id → students.id`, `attendance.class_id → classes.id`, `attendance.academic_year_id → academic_years.id`, `attendance.recorded_by → users.id`.
- Jenjang kelas lewat `student_enrollments` (satu enrollment per siswa per tahun).
- Rekap raport memakai `academic_terms` (bukan `academic_years.starts_on/ends_on`).
- `student_enrollments` mendukung status `ACTIVE|BOYONG|PROMOTED|GRADUATED|INACTIVE|WITHDRAWN|REPEATED` (011, 028).
- Invariant produksi (025): satu tahun ajaran aktif, satu wali kelas aktif per kelas/tahun, dst.

---

## 6. Fitur yang Sudah Tersedia

1. **Input absensi manual** H/S/I/A per santri per kelas per tanggal.
2. **Daftar absensi per kelas** dengan rentang tanggal.
3. **Absensi per siswa** (`/attendance/student/me`) + rekap agregat.
4. **Autorisasi role + permission** dan **scope guru** (teaching/homeroom) pada read & write.
5. **Upsert aman** dengan transaksi, `FOR UPDATE`, dan `ON DUPLICATE KEY UPDATE`.
6. **Penguncian kalender**: `calendar_events.locks_attendance` memblokir penulisan manual.
7. **Import Excel** dengan template resmi, staging, review NIS, approve, apply, replay protection (checksum + GET_LOCK), dan larangan menimpa data manual.
8. **Audit trail** lengkap: audit otomatis untuk semua mutasi + audit eksplisit absensi/import.
9. **Snapshot raport** mengambil rekap absensi (`H/S/I/A`, hari tercatat) per semester.
10. **Unit test** parser/template XLSX absensi (`attendance-xlsx.test.ts`).
11. **Jadwal & deteksi bentrok** guru/kelas (`schedules`).
12. **Manajemen penugasan mengajar & wali kelas** via `OperationsPage` / `class.routes`.

---

## 7. Fitur yang Belum Tersedia

1. **Dimensi sesi/pertemuan/jam pelajaran pada absensi.** Keunikan hanya `(student_id, attendance_date)`, sehingga tidak bisa membedakan absensi mata pelajaran/sesi berbeda pada hari yang sama.
2. **Pemilihan sesi pada UI.** Belum ada pilihan jadwal/sesi; hanya kelas + tanggal.
3. **Pemilihan penugasan (mata pelajaran) untuk absensi.** Guru tidak memilih pengampuannya saat absensi; scope hanya per kelas.
4. **Input massal (bulk) per kelas dalam satu aksi.** Simpan tetap per baris (satu request per siswa); belum ada "simpan semua".
5. **Absensi berbasis jadwal aktif otomatis** (prefill daftar siswa sesuai jadwal/hari).
6. **Tabel rekap tersimpan / rekapitulasi resmi.** Rekap dihitung ad-hoc.
7. **Koreksi/otorisasi eksplisit Admin** sebagai alur koreksi terpisah (saat ini Admin bebas mengubah via permission yang sama).
8. **UI audit log khusus absensi** untuk menelusuri perubahan per siswa/tanggal.
9. **Pembatasan koreksi historis** (mis. hanya tahun ajaran berjalan, atau jendela waktu) — belum ada.
10. **Absensi per mata pelajaran/semester** (raport hanya menghitung total hari, tidak per mapel).
11. **Integrasi `academic_terms` ke validasi input manual** (validasi input manual memakai rentang `academic_years`, bukan semester).
12. **Test integrasi end-to-end absensi** (hanya ada unit test parser).

---

## 8. Gap terhadap Workflow Target

| Target (`AGENTS.md`) | Kondisi saat ini | Gap |
|---|---|---|
| GURU melihat kelas/jadwal yang ditugaskan | `GET /classes` (scope) dan `GET /schedules/teacher/me` tersedia | OK, tetapi absensi tidak memakai konteks jadwal |
| GURU memilih **tanggal/sesi** | Hanya pilih tanggal + kelas | **Belum ada sesi/pertemuan** |
| GURU menandai H/S/I/A | Tersedia via dropdown per baris | OK |
| GURU menyimpan absensi | `PUT /api/attendance` per baris | Berfungsi, tetapi belum bulk/satu aksi |
| System: persist di MySQL | `attendance` + `import_*` | OK |
| System: rekap otomatis | Agregat on-the-fly + snapshot raport | Sebagian; belum rekap resmi tersimpan |
| Enforce teacher/class authorization | Cek teaching/homeroom aktif pada read & write | OK |
| Cegah guru mengubah kelas guru lain | `OUTSIDE_TEACHER_SCOPE` | OK |
| Uniqueness tanggal/sesi | `UNIQUE(student_id, attendance_date)` hanya tanggal | **Belum ada keunikan per sesi** |
| Auditability | `audit_logs` + mutasi otomatis | OK |
| Bulk upload opsional, bukan alur utama | Import ada dan dipisah dari alur harian | OK |

**Gap utama:** target menyebut "date/**session**" dan "date/session uniqueness", namun model data dan UI belum memiliki dimensi sesi. Ini gap arsitektural paling signifikan.

---

## 9. Risiko atau Potensi Masalah

1. **Duplikasi/kehilangan granularitas sesi.** Karena `UNIQUE(student_id, attendance_date)`, absensi pagi dan sore (atau dua mapel berbeda) saling menimpa. Jika workflow nyata multi-sesi, ini kehilangan data.
2. **Validasi tahun ajaran rapuh.** Read/write manual mengandalkan `academic_years.starts_on/ends_on` (nullable). Jika kosong, enrollment tidak ditemukan → `NO_ENROLLMENT_FOR_DATE`. Raport memakai `academic_terms`; **dua sumber kebenaran periode** berisiko tidak konsisten.
3. **Tidak ada pembatas koreksi historis.** Admin/guru dapat mengubah absensi tanggal lama tanpa jendela waktu, hanya diblokir kalender. Audit mencatat perubahan tetapi tidak membatasi.
4. **`SELECT id FROM roles WHERE code='SUPER_ADMIN' FOR UPDATE` sebagai lock global.** Menyerialisasi semua penulisan absensi/jadwal pada satu baris; dapat menjadi bottleneck dan tidak jelas maksudnya secara semantik.
5. **N+1 / per-baris.** Simpan satu request per siswa; kelas besar memicu banyak round-trip dan beban DB.
6. **`finally { await conn.rollback() }` setelah commit.** Pola umum di codebase; aman tetapi memanggil rollback setelah commit (biasanya no-op), berpotensi menyamarkan error.
7. **Import apply menolak menimpa `MANUAL`**, tetapi manual **dapat menimpa** hasil `IMPORT_EXCEL` (`ON DUPLICATE KEY UPDATE` tanpa cek `source`). Kebijakan konflik asimetris.
8. **`student_enrollments` UNIQUE `(student_id, academic_year_id)`** membatasi satu enrollment per tahun, namun status `WITHDRAWN/REPEATED` (011/028) menyiratkan kemungkinan enrollment berulang — perlu verifikasi konsistensi.
9. **Tidak ada foreign key `schedules` → absensi**; absensi tidak dapat ditautkan ke pertemuan.
10. **`is_mine` tidak ada di response `/assignments`.** `AcademicEditor` memfilter `a.is_mine===1`, namun SQL `assignment.routes.ts` tidak menyeleksi `is_mine`; filter guru tidak efektif (server masih mem-filter by teacher, jadi aman, tetapi UI logic menyesatkan/berpotensi menampilkan assignment lain bila server berubah).
11. **Referensi route:** frontend memanggil `/schedules/student/me`, `/schedules/teacher/me`, `/schedules/admin` sementara router didefinisikan `/admin`, `/teacher/me`, `/student/me`; hasilnya bergantung prefiks mount. Perlu verifikasi runtime bahwa tidak ada 404.
12. **Kalender `locks_attendance` hanya dicek saat manual**, tidak saat `apply` import.

---

## 10. Usulan Perubahan Minimal

Prinsip: perubahan sekecil mungkin, tidak merombak arsitektur, tidak menghapus fungsi, dan menunggu persetujuan.

### A. Dimensi sesi (opsional, tergantung keputusan produk)
- **A1.** Bila absensi memang per **pertemuan**, tambahkan kolom `schedule_id` NULL pada `attendance` dan ganti keunikan menjadi `(student_id, attendance_date, schedule_id)`; sesuaikan endpoint/UI untuk memilih jadwal sesi. Ini perubahan migration + route + UI — perlu keputusan eksplisit.
- **A2.** Bila absensi cukup **harian per kelas**, dokumentasikan keputusan ini dan pertahankan keunikan `(student_id, attendance_date)`; tidak perlu perubahan schema.

### B. Konsistensi periode
- **B1.** Satukan penentuan periode absensi: gunakan `academic_terms` (per semester) untuk validasi input manual dan rekap, dengan fallback eksplisit dan pesan error `SEMESTER_PERIOD_NOT_CONFIGURED`. Hindari ketergantungan pada `academic_years.starts_on/ends_on` yang nullable.

### C. Simpan massal (bulk) tanpa mengubah schema
- **C1.** Tambahkan endpoint `PUT /api/attendance/bulk` yang menerima array baris untuk satu kelas+tanggal dalam satu transaksi. Pertahankan `PUT /api/attendance` untuk kompatibilitas. Frontend menambahkan tombol "Simpan semua".

### D. Kebijakan konflik & koreksi
- **D1.** Terapkan kebijakan konflik simetris: putuskan apakah nilai ber-`source` lebih kuat menimpa, atau manual selalu boleh menimpa import. Minimal, tanggapi `PUT` manual terhadap baris `IMPORT_EXCEL` dengan keputusan eksplisit yang terdokumentasi.
- **D2.** Batasi koreksi historis bila diinginkan (mis. hanya tahun ajaran `is_active=1` atau jendela N hari) dan catat `ATTENDANCE.CORRECTED` eksplisit dengan nilai lama/baru.

### E. Perbaikan kecil & kebersihan
- **E1.** Ganti lock global `SELECT ... FROM roles WHERE code='SUPER_ADMIN' FOR UPDATE` dengan `SELECT ... FOR UPDATE` pada baris enrollment/attendance yang relevan saja.
- **E2.** Perbaiki filter `is_mine` di `AcademicEditor` (atau hapus filternya karena server sudah memfilter).
- **E3.** Verifikasi dan selaraskan prefiks route `/schedules/*` antara frontend dan backend.
- **E4.** Terapkan `locks_attendance` juga pada jalur `apply` import, atau dokumentasikan pengecualiannya.
- **E5.** Tambahkan test integrasi absensi (scope guru, lock kalender, upsert, no-enrollment) di samping unit test parser yang sudah ada.

### F. Observability
- **F1.** Tambahkan tampilan audit log khusus absensi untuk SUPER_ADMIN/ADMIN (filter `entity_type='attendance'`) tanpa tabel baru.

---

## Ringkasan Eksekutif

Implementasi absensi sudah **fungsional dan aman untuk model absensi harian per kelas**: input manual H/S/I/A, otorisasi role+permission dengan scope guru, penguncian kalender, audit trail menyeluruh, serta import Excel dengan staging/review/approve/apply. Gap terbesar terhadap workflow target adalah **tidak adanya dimensi sesi** pada data maupun UI, sehingga frasa target "tanggal/sesi" dan "date/session uniqueness" belum sepada dengan kenyataan schema. Selain itu, terdapat ketidakkonsistenan sumber periode (`academic_years` vs `academic_terms`) dan belum ada simpan massal. Perubahan minimal yang diusulkan berfokus pada penyelarasan periode, bulk save opsional, kebijakan konflik, dan perbaikan kebersihan — semuanya memerlukan persetujuan sebelum implementasi.
