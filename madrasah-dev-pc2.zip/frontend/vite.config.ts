import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],

  server: {
    proxy: {
      '/api': {
        target: process.env.API_PROXY_TARGET ?? 'http://127.0.0.1:3000',
        changeOrigin: true,
      },
    },
  },

  preview: {
    allowedHosts: ['takmiliyah.my.id'],
  },

  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          pdf: ['pdfjs-dist'],
        },
      },
    },
  },
});