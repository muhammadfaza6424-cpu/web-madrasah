import OperationsPage from "../features/admin/OperationsPage";
import OperationalSettingsPage from "../features/admin/OperationalSettingsPage";
import AccountsPage from "../features/admin/AccountsPage";
import { FormEvent, useEffect, useState } from "react";
import { api, ApiError } from "../services/api";
import ProductionPage from "../features/production/ProductionPage";
import AcademicPage from "../features/academic/AcademicPage";
import AcademicEditor from "../features/academic/AcademicEditor";
import ScheduleEditor from "../features/academic/ScheduleEditor";
import ReportPage from "../features/reports/ReportPage";
import ReportSignatureManager from "../features/reports/ReportSignatureManager";
import CertificatePage from "../features/certificates/CertificatePage";
import StudentImportReview from "../features/production/StudentImportReview";
import StudentRosterImport from "../features/production/StudentRosterImport";
import MasterDataImport from "../features/production/MasterDataImport";
import AttendanceImport from "../features/production/AttendanceImport";
import MuhafadlohImportReview from "../features/production/MuhafadlohImportReview";
import GradeImport from "../features/production/GradeImport";
import FinalExamImportReview from "../features/production/FinalExamImportReview";
import DocumentsPage from "../features/production/DocumentsPage";
import StudentsPage from "../features/production/StudentsPage";
import "./app.css";
import "./theme.css";
import {
  Bell, BookOpen, CalendarDays, ClipboardCheck, ClipboardList, FileBadge,
  FileText, GraduationCap, House, KeyRound, LayoutGrid, LogOut,
  MessageSquareText, Megaphone, NotebookPen, School, Search,
  Settings2, ShieldCheck, UserRound, UsersRound,
  type LucideIcon,
} from "lucide-react";
type Role = "SUPER_ADMIN" | "ADMIN" | "GURU" | "SANTRI";
type User = { username: string; role: Role; mustChangePassword: boolean };
const roles: Role[] = ["SUPER_ADMIN", "ADMIN", "GURU", "SANTRI"];
function validUser(v: any): v is User {
  return (
    !!v &&
    typeof v.username === "string" &&
    roles.includes(v.role) &&
    typeof v.mustChangePassword === "boolean"
  );
}
const academic = new Set(["Jadwal", "Absensi", "Nilai", "Muhafadloh"]),
  editable = new Set(["Absensi", "Nilai", "Muhafadloh"]);
const logo = "/assets/logo-bahrul-ulum.jpg.jpeg";
const icons: Record<string, LucideIcon> = {
  Dashboard: House, Santri: UsersRound, "Santri Kelas": UsersRound,
  "Rekonsiliasi Import": Search, Guru: GraduationCap, Kelas: School,
  Jadwal: CalendarDays, Absensi: ClipboardCheck, Nilai: NotebookPen,
  Muhafadloh: BookOpen, Raport: FileText, "Tanda Tangan Raport": ClipboardList,
  Ijazah: FileBadge, Kalender: CalendarDays, Dokumen: FileText,
  Pengumuman: Megaphone, Notifikasi: Bell, "Kritik & Saran": MessageSquareText,
  Akun: KeyRound, Pengaturan: Settings2, Profil: UserRound,
};
const nav: Record<Role, string[]> = {
  SUPER_ADMIN: [
    "Dashboard",
    "Santri",
    "Rekonsiliasi Import",
    "Guru",
    "Kelas",
    "Jadwal",
    "Absensi",
    "Nilai",
    "Muhafadloh",
    "Raport",
    "Tanda Tangan Raport",
    "Ijazah",
    "Kalender",
    "Dokumen",
    "Pengumuman",
    "Notifikasi",
    "Kritik & Saran",
    "Akun",
    "Pengaturan",
  ],
  ADMIN: [
    "Dashboard",
    "Santri",
    "Rekonsiliasi Import",
    "Guru",
    "Kelas",
    "Jadwal",
    "Absensi",
    "Nilai",
    "Muhafadloh",
    "Raport",
    "Tanda Tangan Raport",
    "Ijazah",
    "Kalender",
    "Dokumen",
    "Pengumuman",
    "Notifikasi",
    "Kritik & Saran",
    "Akun",
    "Pengaturan",
  ],
  GURU: [
    "Dashboard",
    "Santri Kelas",
    "Jadwal",
    "Absensi",
    "Nilai",
    "Muhafadloh",
    "Raport",
    "Kalender",
    "Dokumen",
    "Pengumuman",
    "Notifikasi",
    "Kritik & Saran",
  ],
  SANTRI: [
    "Dashboard",
    "Profil",
    "Jadwal",
    "Absensi",
    "Nilai",
    "Muhafadloh",
    "Raport",
    "Ijazah",
    "Kalender",
    "Dokumen",
    "Pengumuman",
    "Notifikasi",
  ],
};
export default function App() {
  const [user, setUser] = useState<User | null | undefined>(),
    [page, setPage] = useState("Dashboard"),
    [error, setError] = useState(""),
    [forgotOpen, setForgotOpen] = useState(false),
    [recoveryMode, setRecoveryMode] = useState<"STAFF"|"SUPER_ADMIN">("STAFF"),
    [otpRequested, setOtpRequested] = useState(false),
    [otpCode, setOtpCode] = useState(""),
    [otpPassword, setOtpPassword] = useState(""),
    [otpConfirmation, setOtpConfirmation] = useState(""),
    [recoveryUsername, setRecoveryUsername] = useState(""),
    [recoveryMessage, setRecoveryMessage] = useState("");
  useEffect(() => {
    api<{ user: unknown }>("/auth/me")
      .then((x) => setUser(validUser(x.user) ? x.user : null))
      .catch(() => setUser(null));
  }, []);
  async function login(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    const f = new FormData(e.currentTarget);
    try {
      const r = await api<{ user: unknown }>("/auth/login", {
        method: "POST",
        body: JSON.stringify({
          username: f.get("username"),
          password: f.get("password"),
        }),
      });
      if (!validUser(r.user)) {
        setError("Respons akun tidak valid.");
        return;
      }
      setUser(r.user);
      setPage("Dashboard");
    } catch (e) {
      setError(
        e instanceof ApiError && (e.status === 400 || e.status === 401)
          ? "Username atau password tidak sesuai."
          : e instanceof ApiError && e.status === 429
            ? "Terlalu banyak percobaan login. Tunggu beberapa menit, lalu coba lagi."
            : "Layanan login sedang bermasalah. Periksa apakah API lokal berjalan.",
      );
    }
  }
  async function changePassword(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    const f = new FormData(e.currentTarget),
      a = String(f.get("newPassword") ?? ""),
      b = String(f.get("confirmPassword") ?? "");
    if (a !== b) {
      setError("Konfirmasi password tidak sama.");
      return;
    }
    try {
      await api("/auth/change-password", {
        method: "POST",
        body: JSON.stringify({
          currentPassword: f.get("currentPassword"),
          newPassword: a,
        }),
      });
      setUser(null);
      setError("");
    } catch (e) {
      setError(
        e instanceof ApiError && e.code === "CURRENT_PASSWORD_INVALID"
          ? "Password saat ini tidak sesuai."
          : e instanceof ApiError && e.code === "PASSWORD_UNCHANGED"
            ? "Password baru harus berbeda."
            : "Password baru minimal 12 karakter dan harus valid.",
      );
    }
  }
  async function requestRecovery() {
    if (!recoveryUsername.trim()) { setRecoveryMessage("Isi username dahulu."); return; }
    try {
      await api(recoveryMode==='SUPER_ADMIN'?'/recovery/super/request':'/recovery/request', {method:'POST', body:JSON.stringify({username:recoveryUsername.trim()})});
      if(recoveryMode==='SUPER_ADMIN'){setOtpRequested(true);setRecoveryMessage('Jika akun aktif, kode pemulihan telah dikirim ke email terdaftar.');}
      else setRecoveryMessage('Permintaan diterima. Hubungi pengelola akun untuk mendapatkan password pengganti.');
    } catch (e) {
      setRecoveryMessage(e instanceof ApiError && e.status===429?'Terlalu banyak permintaan. Coba lagi nanti.':e instanceof ApiError&&e.code==='EMAIL_RECOVERY_UNAVAILABLE'?'Pemulihan email belum tersedia.':'Permintaan belum dapat dikirim. Periksa layanan aplikasi.');
    }
  }
  async function confirmRecovery(){
    if(otpPassword!==otpConfirmation){setRecoveryMessage('Konfirmasi password tidak sama.');return;}
    if(otpPassword.length<12){setRecoveryMessage('Password baru minimal 12 karakter.');return;}
    try{await api('/recovery/super/confirm',{method:'POST',body:JSON.stringify({username:recoveryUsername.trim(),code:otpCode,newPassword:otpPassword})});setOtpRequested(false);setForgotOpen(false);setOtpCode('');setOtpPassword('');setOtpConfirmation('');setRecoveryMessage('Password berhasil diubah. Silakan masuk.');}
    catch(e){setRecoveryMessage(e instanceof ApiError&&e.code==='INVALID_OR_EXPIRED_CODE'?'Kode tidak sesuai atau sudah kedaluwarsa.':'Pemulihan gagal. Periksa data dan coba lagi.');}
  }
  if (user === undefined) return <main className="center">Memuat…</main>;
  if (!user)
    return (
      <main className="login">
        <div className="login-orb login-orb-one" />
        <div className="login-orb login-orb-two" />
        <div className="login-panel">
          <form onSubmit={login} className="login-card">
            <div className="login-card-logo"><img src={logo} alt="Logo Madrasah Takmiliyah Annajiyah 2" /></div>
            <span className="eyebrow">PONDOK PESANTREN AN-NAJIYAH 2</span>
            <h2>Madrasah Takmiliyah Annajiyah 2</h2>
            <p>Masuk ke akun Anda</p>
            <label>Username / NIS<input name="username" autoComplete="username" placeholder="Masukkan username atau NIS" required onChange={e=>setRecoveryUsername(e.target.value)} /></label>
            <label>Password<input name="password" type="password" autoComplete="current-password" placeholder="Masukkan password" required /></label>
            {error && <p className="error" role="alert">{error}</p>}
            <button type="submit" className="login-submit">Masuk <span aria-hidden="true">→</span></button>
            <button type="button" className="text-link" onClick={() => setForgotOpen(v => !v)}>Lupa password?</button>
            {forgotOpen && <div className="recovery-note">
              <label>Jenis akun<select value={recoveryMode} onChange={e=>{setRecoveryMode(e.target.value as "STAFF"|"SUPER_ADMIN");setOtpRequested(false);setRecoveryMessage('')}}><option value="STAFF">Santri, Guru, atau Admin</option><option value="SUPER_ADMIN">Super Admin</option></select></label>
              <button type="button" onClick={requestRecovery}>{recoveryMode==='SUPER_ADMIN'?'Kirim kode OTP':'Kirim permintaan pemulihan'}</button>
              {otpRequested&&recoveryMode==='SUPER_ADMIN'&&<div className="otp-fields"><label>Kode OTP<input inputMode="numeric" pattern="[0-9]{6}" maxLength={6} value={otpCode} onChange={e=>setOtpCode(e.target.value.replace(/\D/g,''))}/></label><label>Password baru<input type="password" autoComplete="new-password" value={otpPassword} onChange={e=>setOtpPassword(e.target.value)}/></label><label>Ulangi password baru<input type="password" autoComplete="new-password" value={otpConfirmation} onChange={e=>setOtpConfirmation(e.target.value)}/></label><button type="button" disabled={otpCode.length!==6||otpPassword.length<12} onClick={confirmRecovery}>Simpan password baru</button></div>}
              {recoveryMessage&&<p role="status">{recoveryMessage}</p>}
            </div>}
          </form>
        </div>
        <footer className="login-footer">Madrasah Takmiliyah Annajiyah 2 · Bahrul Ulum</footer>
      </main>
    );
  if (user.mustChangePassword)
    return (
      <main className="login password-page">
        <form onSubmit={changePassword} className="login-card">
          <div className="login-card-logo"><img src={logo} alt="Logo Madrasah" /></div>
          <h1>Ganti Password</h1>
          <p>Password wajib diganti sebelum mengakses sistem.</p>
          <label>
            Password saat ini
            <input
              name="currentPassword"
              type="password"
              autoComplete="current-password"
              required
            />
          </label>
          <label>
            Password baru
            <input
              name="newPassword"
              type="password"
              autoComplete="new-password"
              minLength={12}
              required
            />
          </label>
          <label>
            Ulangi password baru
            <input
              name="confirmPassword"
              type="password"
              autoComplete="new-password"
              minLength={12}
              required
            />
          </label>
          {error && <p className="error">{error}</p>}
          <button>Ganti Password</button>
          <button
            type="button"
            onClick={async () => {
              await api("/auth/logout", { method: "POST" });
              setUser(null);
            }}
          >
            Keluar
          </button>
        </form>
      </main>
    );
  let content;
  if (page === "Dashboard")
    content = (
      <div className="dashboard">
        <section className="dashboard-hero">
          <span className="eyebrow">RUANG KERJA {user.role.replace("_", " ")}</span>
          <h2>Assalamu’alaikum, {user.username}</h2>
          <p>Selamat datang di Madrasah Takmiliyah Annajiyah 2. Pilih layanan yang ingin Anda kelola hari ini.</p>
          <img src={logo} alt="" aria-hidden="true" />
        </section>
        <div className="dashboard-grid">
          {nav[user.role].filter(n => ["Santri", "Santri Kelas", "Profil", "Absensi", "Nilai", "Raport", "Ijazah", "Kelas"].includes(n)).slice(0, 6).map((n, i) => {
            const Icon = icons[n] ?? LayoutGrid;
            return <button type="button" className={`dashboard-tile tile-${i % 4}`} key={n} onClick={() => setPage(n)}><span className="tile-icon"><Icon size={24} strokeWidth={2} /></span><strong>{n}</strong><small>Buka layanan <span aria-hidden="true">→</span></small></button>;
          })}
        </div>
      </div>
    );
  else if (page === "Santri" && (user.role === "ADMIN" || user.role === "SUPER_ADMIN"))
    content = <StudentsPage />;
  else if (
    page === "Akun" &&
    (user.role === "ADMIN" || user.role === "SUPER_ADMIN")
  )
    content = <AccountsPage role={user.role} />;
  else if (
    ["Guru", "Kelas"].includes(page) &&
    (user.role === "ADMIN" || user.role === "SUPER_ADMIN")
  )
    content = (
      <OperationsPage
        key={page}
        initial={
          page === "Guru" ? "teachers" : page === "Kelas" ? "classes" : "years"
        }
      />
    );
  else if (
    page === "Rekonsiliasi Import" &&
    user.role === "SUPER_ADMIN"
  )
    content = <><StudentImportReview /><StudentRosterImport /><MasterDataImport /><AttendanceImport /><MuhafadlohImportReview /><GradeImport /><FinalExamImportReview /></>;
  else if (page === "Rekonsiliasi Import" && user.role === "ADMIN")
    content = <MasterDataImport />;
  else if (
    page === "Pengaturan" &&
    (user.role === "ADMIN" || user.role === "SUPER_ADMIN")
  )
    content = <OperationalSettingsPage />;
  else if (page === "Dokumen") content = <DocumentsPage role={user.role} />;
  else if (page === "Raport") content = <ReportPage role={user.role} />;
  else if (page === "Ijazah") content = <CertificatePage role={user.role} />;
  else if (
    page === "Tanda Tangan Raport" &&
    (user.role === "ADMIN" || user.role === "SUPER_ADMIN")
  )
    content = <ReportSignatureManager />;
  else if (
    page === "Jadwal" &&
    (user.role === "ADMIN" || user.role === "SUPER_ADMIN")
  )
    content = <ScheduleEditor />;
  else if (editable.has(page) && user.role !== "SANTRI")
    content = <AcademicEditor key={page} page={page} role={user.role} />;
  else if (academic.has(page))
    content = <AcademicPage key={page} page={page} role={user.role} />;
  else content = <ProductionPage key={page} page={page} role={user.role} />;
  return (
    <div className="shell">
      <aside>
        <div className="sidebar-brand"><img src={logo} alt="Logo Madrasah" /><div><strong>Madrasah Takmiliyah<br />Annajiyah 2</strong><span>PP. Bahrul Ulum</span></div></div>
        <div className="sidebar-user"><span className="user-avatar"><UserRound size={20} /></span><div><strong>{user.username}</strong><small>{user.role.replace("_", " ")}</small></div></div>
        <span className="sidebar-label">MENU UTAMA</span>
        <nav>
          {nav[user.role].map((n) => {
            const Icon = icons[n] ?? LayoutGrid;
            return <button
              className={page === n ? "active" : ""}
              key={n}
              onClick={() => setPage(n)}
            >
              <Icon size={18} strokeWidth={2} /><span>{n}</span>
            </button>;
          })}
        </nav>
        <button
          className="sidebar-logout"
          onClick={async () => {
            await api("/auth/logout", { method: "POST" });
            setUser(null);
          }}
        >
          <LogOut size={18} /> Keluar
        </button>
      </aside>
      <main>
        <header className="page-header">
          <div><span className="eyebrow">MADRASAH TAKMILIYAH ANNAJIYAH 2</span><h1>{page}</h1></div>
          <div className="header-role"><ShieldCheck size={17} /> {user.role.replace("_", " ")}</div>
        </header>
        {content}
      </main>
    </div>
  );
}
