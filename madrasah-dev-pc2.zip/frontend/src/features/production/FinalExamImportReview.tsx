import { FormEvent, useEffect, useState } from 'react';
import { api, ApiError, apiUrl } from '../../services/api';

type Year = { id: number; name: string };
type Batch = {
  id: number;
  source_name: string;
  status: string;
  academic_year_id: number;
  total_rows: number;
  unresolved_rows: number;
  resolved_rows: number;
};
type Candidate = { id: number; nis: string; name: string; class_code: string };
type Row = {
  id: number;
  source_row_number: number;
  source_nis: string;
  source_name: string | null;
  source_class: string | null;
  subject_code: string;
  score: number;
  matched_student_id: number | null;
  match_status: string;
  review_note: string | null;
  official_nis: string | null;
  official_name: string | null;
  official_class: string | null;
};
type Review = { batch: Batch; rows: Row[]; candidates: Candidate[] };

export default function FinalExamImportReview() {
  const [batches, setBatches] = useState<Batch[]>([]);
  const [years, setYears] = useState<Year[]>([]);
  const [batchId, setBatchId] = useState('');
  const [yearId, setYearId] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [data, setData] = useState<Review | null>(null);
  const [matches, setMatches] = useState<Record<number, string>>({});
  const [notes, setNotes] = useState<Record<number, string>>({});
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  async function loadBatches() {
    try {
      const [batchResult, yearResult] = await Promise.all([
        api<{ batches: Batch[] }>('/imports/final-exam'),
        api<{ academicYears: Year[] }>('/academic-years'),
      ]);
      setBatches(batchResult.batches);
      setYears(yearResult.academicYears);
      if (!batchId && batchResult.batches[0]) setBatchId(String(batchResult.batches[0].id));
    } catch (e) {
      setError(e instanceof ApiError ? e.code : 'Gagal memuat daftar import ujian akhir.');
    }
  }

  useEffect(() => { void loadBatches(); }, []);

  async function load(id = batchId) {
    if (!id) return;
    setError('');
    setMessage('');
    try {
      const result = await api<Review>(`/imports/final-exam/${id}/review`);
      setData(result);
      setYearId(String(result.batch.academic_year_id));
      setMatches(Object.fromEntries(result.rows.map(row => [row.id, String(row.matched_student_id ?? '')])));
      setNotes(Object.fromEntries(result.rows.map(row => [row.id, row.review_note ?? ''])));
    } catch (e) {
      setError(e instanceof ApiError ? e.code : 'Gagal memuat review ujian akhir.');
    }
  }

  async function downloadTemplate() {
    setBusy(true);
    setError('');
    try {
      const response = await fetch(apiUrl('/imports/final-exam/template'), { credentials: 'include' });
      if (!response.ok) throw new ApiError(response.status, (await response.json().catch(() => null))?.error ?? 'TEMPLATE_DOWNLOAD_FAILED');
      const url = URL.createObjectURL(await response.blob());
      const link = document.createElement('a');
      link.href = url;
      link.download = 'final-exam-template.xlsx';
      link.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      setError(e instanceof ApiError ? e.code : 'Gagal mengunduh template ujian akhir.');
    } finally {
      setBusy(false);
    }
  }

  async function stage(event: FormEvent) {
    event.preventDefault();
    if (!file || !yearId) {
      setError('Pilih tahun ajaran dan file XLSX.');
      return;
    }
    setBusy(true);
    setError('');
    setMessage('');
    try {
      const form = new FormData();
      form.append('file', file);
      form.append('academicYearId', yearId);
      const result = await api<{ batchId: number; rowCount: number; matchedCount: number }>(
        '/imports/final-exam/stage',
        { method: 'POST', body: form },
      );
      setFile(null);
      setBatchId(String(result.batchId));
      await Promise.all([load(String(result.batchId)), loadBatches()]);
      setMessage(`Batch #${result.batchId} masuk staging: ${result.rowCount} baris, ${result.matchedCount} NIS cocok persis. Nilai resmi belum diubah.`);
    } catch (e) {
      setError(e instanceof ApiError ? e.code : 'Gagal menyiapkan batch ujian akhir.');
    } finally {
      setBusy(false);
    }
  }

  async function resolve(row: Row, decision: 'MATCH' | 'CLEAR') {
    setBusy(true);
    setError('');
    setMessage('');
    try {
      const note = notes[row.id]?.trim() || null;
      const body = decision === 'CLEAR'
        ? { decision, note }
        : { decision, studentId: Number(matches[row.id]), note };
      await api(`/imports/final-exam/${batchId}/review/${row.id}`, { method: 'PUT', body: JSON.stringify(body) });
      await Promise.all([load(), loadBatches()]);
      setMessage('Keputusan rekonsiliasi tersimpan; belum ada nilai resmi yang berubah.');
    } catch (e) {
      setError(e instanceof ApiError ? e.code : 'Gagal menyimpan keputusan rekonsiliasi.');
    } finally {
      setBusy(false);
    }
  }

  async function transition(action: 'approve' | 'apply') {
    if (!batchId || !yearId) return;
    setBusy(true);
    setError('');
    setMessage('');
    try {
      await api(`/imports/final-exam/${batchId}/${action}`, {
        method: 'POST',
        body: action === 'approve' ? JSON.stringify({ academicYearId: Number(yearId) }) : undefined,
      });
      await Promise.all([load(), loadBatches()]);
      setMessage(action === 'approve' ? 'Batch disetujui setelah validasi review.' : 'Batch diterapkan; setiap nilai menyimpan provenance import.');
    } catch (e) {
      setError(e instanceof ApiError ? e.code : 'Proses batch gagal.');
    } finally {
      setBusy(false);
    }
  }

  const selected = batches.find(batch => String(batch.id) === batchId);
  return (
    <section className="card">
      <h2>Rekonsiliasi Import Nilai Ujian Akhir / Ijazah</h2>
      <p>Import hanya menyiapkan staging. Terdapat tepat tujuh komponen ujian; kelulusan dan penerbitan ijazah tetap keputusan manusia.</p>
      <div className="filters">
        <button type="button" disabled={busy} onClick={downloadTemplate}>Unduh Template Ujian Akhir</button>
        <form onSubmit={stage}>
          <label>Tahun ajaran tujuan
            <select value={yearId} onChange={event => setYearId(event.target.value)} required>
              <option value="">Pilih tahun ajaran…</option>
              {years.map(year => <option key={year.id} value={year.id}>{year.name}</option>)}
            </select>
          </label>
          <label>File nilai ujian akhir XLSX
            <input
              type="file"
              accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
              onChange={event => setFile(event.target.files?.[0] ?? null)}
              required
            />
          </label>
          <button disabled={busy || !file || !yearId}>Tahapkan untuk Review</button>
        </form>
      </div>
      <div className="filters">
        <label>Batch
          <select value={batchId} onChange={event => { setBatchId(event.target.value); setData(null); }}>
            <option value="">Pilih batch…</option>
            {batches.map(batch => (
              <option key={batch.id} value={batch.id}>
                #{batch.id} · {batch.source_name} · {batch.status} · unresolved {batch.unresolved_rows}/{batch.total_rows}
              </option>
            ))}
          </select>
        </label>
        <button type="button" disabled={!batchId || busy} onClick={() => load()}>Muat Review</button>
        <button type="button" disabled={busy} onClick={loadBatches}>Segarkan daftar</button>
        {selected?.status === 'STAGED' || selected?.status === 'REVIEW_REQUIRED' ? (
          <button type="button" disabled={busy || !data} onClick={() => transition('approve')}>Setujui Batch</button>
        ) : null}
        {selected?.status === 'APPROVED' ? (
          <button type="button" disabled={busy || !data} onClick={() => transition('apply')}>Terapkan Batch</button>
        ) : null}
      </div>
      {!batches.length && <p>Belum ada batch ujian akhir di staging.</p>}
      {message && <p role="status">{message}</p>}
      {error && <p className="error" role="alert">{error}</p>}
      {data && (
        <>
          <p><b>{data.batch.source_name}</b> · tahun ajaran <b>{years.find(year => year.id === data.batch.academic_year_id)?.name ?? data.batch.academic_year_id}</b> · status <b>{data.batch.status}</b></p>
          <div className="tableWrap">
            <table>
              <thead><tr><th>Baris</th><th>NIS sumber</th><th>Nama sumber</th><th>Kelas sumber</th><th>Komponen</th><th>Nilai</th><th>Status</th><th>Santri tujuan</th><th>Catatan review/override</th><th>Aksi</th></tr></thead>
              <tbody>
                {data.rows.map(row => {
                  const unresolved = !row.matched_student_id || ['UNMATCHED', 'AMBIGUOUS'].includes(row.match_status);
                  return (
                    <tr key={row.id} className={unresolved ? 'review-conflict' : ''}>
                      <td>{row.source_row_number}</td>
                      <td>{row.source_nis}</td>
                      <td>{row.source_name ?? '—'}</td>
                      <td>{row.source_class ?? '—'}</td>
                      <td>{row.subject_code}</td>
                      <td>{row.score}</td>
                      <td>{row.match_status}</td>
                      <td>
                        {row.official_name ? <div>{row.official_nis} · {row.official_name} · {row.official_class}</div> : null}
                        <select
                          aria-label={`Santri tujuan baris ${row.source_row_number}`}
                          value={matches[row.id] ?? ''}
                          disabled={busy || !['STAGED', 'REVIEW_REQUIRED'].includes(data.batch.status)}
                          onChange={event => setMatches(current => ({ ...current, [row.id]: event.target.value }))}
                        >
                          <option value="">Pilih kandidat…</option>
                          {data.candidates.map(candidate => (
                            <option key={candidate.id} value={candidate.id}>{candidate.nis} · {candidate.name} · {candidate.class_code}</option>
                          ))}
                        </select>
                      </td>
                      <td>
                        <input
                          aria-label={`Catatan review baris ${row.source_row_number}`}
                          value={notes[row.id] ?? ''}
                          disabled={busy || !['STAGED', 'REVIEW_REQUIRED'].includes(data.batch.status)}
                          onChange={event => setNotes(current => ({ ...current, [row.id]: event.target.value }))}
                        />
                      </td>
                      <td>
                        <button
                          type="button"
                          disabled={busy || !matches[row.id] || !['STAGED', 'REVIEW_REQUIRED'].includes(data.batch.status)}
                          onClick={() => resolve(row, 'MATCH')}
                        >Tetapkan</button>
                        <button
                          type="button"
                          disabled={busy || !row.matched_student_id || !['STAGED', 'REVIEW_REQUIRED'].includes(data.batch.status)}
                          onClick={() => resolve(row, 'CLEAR')}
                        >Batalkan</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}
    </section>
  );
}
