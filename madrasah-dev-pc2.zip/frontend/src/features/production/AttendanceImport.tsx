import { FormEvent, useEffect, useState } from 'react';
import { api, apiUrl, ApiError } from '../../services/api';

type Batch = { id: number; source_name: string; source_checksum: string; status: string; total_rows: number; unresolved_rows: number };
type Row = {
  id: number;
  source_row_number: number;
  source_nis: string | null;
  source_name: string | null;
  source_class: string | null;
  attendance_date: string;
  attendance_status: 'H' | 'S' | 'I' | 'A';
  matched_student_id: number | null;
  match_status: string;
  review_note: string | null;
  official_nis: string | null;
  official_name: string | null;
};
type Review = { batch: Batch; rows: Row[] };

function displayError(cause: unknown, fallback: string): string {
  return cause instanceof ApiError ? cause.code : fallback;
}

export default function AttendanceImport() {
  const [batches, setBatches] = useState<Batch[]>([]);
  const [batchId, setBatchId] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [review, setReview] = useState<Review | null>(null);
  const [nisEdits, setNisEdits] = useState<Record<number, string>>({});
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function refresh() {
    const result = await api<{ batches: Batch[] }>('/imports/attendance');
    setBatches(result.batches);
    if (!batchId && result.batches[0]) setBatchId(String(result.batches[0].id));
  }

  async function loadReview(id = batchId) {
    if (!/^\d+$/.test(id)) return;
    const result = await api<Review>(`/imports/attendance/${id}/review`);
    setReview(result);
    setNisEdits(Object.fromEntries(result.rows.map(row => [row.id, row.source_nis ?? ''])));
  }

  useEffect(() => { void refresh().catch(cause => setError(displayError(cause, 'Gagal memuat batch absensi.'))); }, []);

  async function downloadTemplate() {
    setBusy(true); setError('');
    try {
      const response = await fetch(apiUrl('/imports/attendance/template'), { credentials: 'include' });
      if (!response.ok) throw new ApiError(response.status, (await response.json().catch(() => null))?.error ?? 'TEMPLATE_DOWNLOAD_FAILED');
      const url = URL.createObjectURL(await response.blob());
      const link = document.createElement('a');
      link.href = url; link.download = 'attendance-template.xlsx'; link.click(); URL.revokeObjectURL(url);
    } catch (cause) { setError(displayError(cause, 'Gagal mengunduh template.')); }
    finally { setBusy(false); }
  }

  async function stage(event: FormEvent) {
    event.preventDefault();
    if (!file) { setError('Pilih file XLSX absensi.'); return; }
    setBusy(true); setError('');
    try {
      const form = new FormData(); form.append('file', file);
      const staged = await api<{ batchId: number }>('/imports/attendance/stage', { method: 'POST', body: form });
      setFile(null); setBatchId(String(staged.batchId));
      await Promise.all([loadReview(String(staged.batchId)), refresh()]);
    } catch (cause) { setError(displayError(cause, 'Gagal menyiapkan batch absensi.')); }
    finally { setBusy(false); }
  }

  async function saveResolution(row: Row) {
    setBusy(true); setError('');
    try {
      await api(`/imports/attendance/${batchId}/review/${row.id}`, {
        method: 'PUT',
        body: JSON.stringify({ nis: nisEdits[row.id]?.trim() || null }),
      });
      await Promise.all([loadReview(), refresh()]);
    } catch (cause) { setError(displayError(cause, 'Gagal menyimpan pencocokan NIS.')); }
    finally { setBusy(false); }
  }

  async function transition(action: 'approve' | 'apply') {
    if (!batchId || !window.confirm(action === 'approve'
      ? 'Setujui batch setelah semua baris ditinjau?'
      : 'Terapkan batch yang telah disetujui ke absensi?')) return;
    setBusy(true); setError('');
    try {
      await api(`/imports/attendance/${batchId}/${action}`, { method: 'POST' });
      await Promise.all([loadReview(), refresh()]);
    } catch (cause) { setError(displayError(cause, 'Proses batch absensi gagal.')); }
    finally { setBusy(false); }
  }

  const reviewable = review && ['STAGED', 'REVIEW_REQUIRED'].includes(review.batch.status);
  return <section className="card">
    <h2>Import Absensi Excel</h2>
    <p>Unggah hanya menyiapkan data untuk rekonsiliasi. Absensi tidak diterapkan sampai batch ditinjau, disetujui, lalu diterapkan.</p>
    <p>Gunakan NIS resmi yang sama persis untuk mencocokkan santri. Nama dan kelas hanya informasi pendukung, bukan dasar pencocokan.</p>
    <form onSubmit={stage}>
      <div className="filters">
        <label>File absensi (.xlsx)<input type="file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onChange={event => setFile(event.target.files?.[0] ?? null)} /></label>
        <button type="button" disabled={busy} onClick={() => void downloadTemplate()}>Unduh template</button>
        <button type="submit" disabled={busy || !file}>Unggah untuk ditinjau</button>
      </div>
    </form>
    <div className="filters">
      <label>Batch<select value={batchId} onChange={event => { setBatchId(event.target.value); setReview(null); }}><option value="">Pilih batch</option>{batches.map(batch => <option key={batch.id} value={batch.id}>#{batch.id} · {batch.source_name} · {batch.status} · belum cocok {batch.unresolved_rows}</option>)}</select></label>
      <button type="button" disabled={!batchId || busy} onClick={() => void loadReview().catch(cause => setError(displayError(cause, 'Gagal memuat review absensi.')))}>Muat review</button>
      <button type="button" disabled={busy} onClick={() => void refresh().catch(cause => setError(displayError(cause, 'Gagal memperbarui daftar batch.')))}>Segarkan</button>
      {reviewable && <button type="button" disabled={busy || !review.rows.length} onClick={() => void transition('approve')}>Setujui batch</button>}
      {review?.batch.status === 'APPROVED' && <button type="button" disabled={busy} onClick={() => void transition('apply')}>Terapkan absensi</button>}
    </div>
    {error && <p role="alert">{error}</p>}
    {review && <div className="table-wrap">
      <p>Batch #{review.batch.id} · {review.batch.status} · {review.rows.filter(row => !row.matched_student_id).length} baris belum cocok</p>
      <table>
        <thead><tr><th>Baris</th><th>NIS sumber</th><th>Santri / kelas sumber</th><th>Tanggal</th><th>Status</th><th>NIS resmi untuk cocokkan</th><th>Hasil</th><th></th></tr></thead>
        <tbody>{review.rows.map(row => <tr key={row.id}>
          <td>{row.source_row_number}</td>
          <td>{row.source_nis ?? '—'}</td>
          <td>{row.source_name ?? '—'}{row.source_class ? ` · ${row.source_class}` : ''}</td>
          <td>{String(row.attendance_date).slice(0, 10)}</td>
          <td>{row.attendance_status}</td>
          <td>
            {reviewable
              ? <input aria-label={`NIS resmi baris ${row.source_row_number}`} value={nisEdits[row.id] ?? ''} onChange={event => setNisEdits(current => ({ ...current, [row.id]: event.target.value }))} />
              : row.official_nis ?? '—'}
          </td>
          <td>{row.matched_student_id ? `${row.match_status}: ${row.official_name ?? ''}` : `${row.match_status}${row.review_note ? ` · ${row.review_note}` : ''}`}</td>
          <td>{reviewable && <button type="button" disabled={busy} onClick={() => void saveResolution(row)}>Verifikasi NIS</button>}</td>
        </tr>)}</tbody>
      </table>
    </div>}
  </section>;
}
