import { FormEvent, useEffect, useState } from 'react';
import { api, apiUrl, ApiError } from '../../services/api';

type Kind = 'TEACHERS' | 'SUBJECTS';
type Batch = {
  id: number;
  source_type: string;
  source_name: string;
  status: string;
  total_rows: number;
  unresolved_rows: number;
};
type Row = {
  id: number;
  source_row_number: number;
  source_code: string | null;
  source_identifier: string | null;
  source_name: string | null;
  source_status: string | null;
  source_book_name: string | null;
  source_active: number | null;
  classification: string;
  decision: string;
  validation_error_code: string | null;
  matched_target_id: number | null;
  review_note: string | null;
};
type Review = { batch: Batch; rows: Row[]; preview: { counts: Record<string, number>; decisions: Record<string, number> } };
type Decision = 'CREATE_NEW' | 'KEEP_OFFICIAL' | 'REVIEW';

const kindLabels: Record<Kind, string> = { TEACHERS: 'Guru', SUBJECTS: 'Mata pelajaran / kitab' };
const decisionLabels: Record<Decision, string> = {
  CREATE_NEW: 'Buat data baru',
  KEEP_OFFICIAL: 'Pertahankan data resmi',
  REVIEW: 'Belum diputuskan',
};

function allowedDecisions(row: Row): Decision[] {
  if (row.validation_error_code || row.classification === 'AMBIGUOUS' || row.classification === 'INVALID') return ['REVIEW'];
  if (row.classification === 'NEW') return ['CREATE_NEW', 'REVIEW'];
  if (row.classification === 'UNCHANGED' || row.classification === 'CONFLICT') return ['KEEP_OFFICIAL', 'REVIEW'];
  return ['REVIEW'];
}

export default function MasterDataImport() {
  const [kind, setKind] = useState<Kind>('TEACHERS');
  const [batches, setBatches] = useState<Batch[]>([]);
  const [batchId, setBatchId] = useState('');
  const [review, setReview] = useState<Review | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [decisions, setDecisions] = useState<Record<number, Decision>>({});
  const [notes, setNotes] = useState<Record<number, string>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  async function refresh() {
    const result = await api<{ batches: Batch[] }>('/imports/masters');
    const matching = result.batches.filter((batch) => batch.source_type === `EXCEL_MASTER_${kind}`);
    setBatches(matching);
    if (!matching.some((batch) => String(batch.id) === batchId)) {
      setBatchId(matching[0] ? String(matching[0].id) : '');
      setReview(null);
    }
  }

  useEffect(() => {
    void refresh().catch((cause) => setError(cause instanceof ApiError ? cause.code : 'Gagal memuat batch master.'));
  }, [kind]);

  async function loadReview(id = batchId) {
    if (!/^\d+$/.test(id)) return;
    const result = await api<Review>(`/imports/masters/${id}/review`);
    setReview(result);
    setDecisions({});
    setNotes({});
  }

  async function downloadTemplate() {
    setBusy(true);
    setError('');
    try {
      const response = await fetch(apiUrl(`/imports/masters/template/${kind}`), { credentials: 'include' });
      if (!response.ok) throw new ApiError(response.status, (await response.json().catch(() => null))?.error ?? 'TEMPLATE_DOWNLOAD_FAILED');
      const url = URL.createObjectURL(await response.blob());
      const link = document.createElement('a');
      link.href = url;
      link.download = `master-${kind.toLowerCase()}-template.xlsx`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (cause) {
      setError(cause instanceof ApiError ? cause.code : 'Gagal mengunduh template.');
    } finally {
      setBusy(false);
    }
  }

  async function stage(event: FormEvent) {
    event.preventDefault();
    if (!file) return;
    setBusy(true);
    setError('');
    setMessage('');
    try {
      const form = new FormData();
      form.append('file', file);
      form.append('kind', kind);
      const result = await api<{ batchId: number }>('/imports/masters/stage', { method: 'POST', body: form });
      setFile(null);
      await refresh();
      setBatchId(String(result.batchId));
      await loadReview(String(result.batchId));
    } catch (cause) {
      setError(cause instanceof ApiError ? cause.code : 'Gagal menyiapkan batch master.');
    } finally {
      setBusy(false);
    }
  }

  async function saveDecision(row: Row) {
    const decision = decisions[row.id] ?? row.decision as Decision;
    const note = notes[row.id] ?? row.review_note ?? '';
    setBusy(true);
    setError('');
    try {
      await api(`/imports/masters/${batchId}/review/${row.id}`, {
        method: 'PUT',
        body: JSON.stringify({ decision, note: note || undefined }),
      });
      await Promise.all([loadReview(), refresh()]);
    } catch (cause) {
      setError(cause instanceof ApiError ? cause.code : 'Gagal menyimpan keputusan row.');
    } finally {
      setBusy(false);
    }
  }

  async function transition(action: 'approve' | 'apply') {
    if (!batchId) return;
    const prompt = action === 'approve'
      ? 'Setujui keputusan semua baris? Persetujuan tidak langsung mengubah data resmi.'
      : 'Terapkan baris yang dipilih dan buat data master baru?';
    if (!window.confirm(prompt)) return;
    setBusy(true);
    setError('');
    setMessage('');
    try {
      const result = await api<{ status: string; createdCount?: number; keptCount?: number }>(
        `/imports/masters/${batchId}/${action}`,
        { method: 'POST' },
      );
      setMessage(action === 'apply'
        ? `Selesai: ${result.createdCount ?? 0} data baru; ${result.keptCount ?? 0} dipertahankan.`
        : 'Batch disetujui. Terapkan secara terpisah setelah meninjau ulang. ');
      await Promise.all([loadReview(), refresh()]);
    } catch (cause) {
      setError(cause instanceof ApiError ? cause.code : 'Proses batch master gagal.');
    } finally {
      setBusy(false);
    }
  }

  const mayReview = review && ['STAGED', 'REVIEW_REQUIRED'].includes(review.batch.status);
  return <section className="card">
    <h2>Rekonsiliasi Master Guru dan Mata Pelajaran / Kitab</h2>
    <p>Hanya baris yang disetujui eksplisit sebagai data baru akan dibuat. Konflik tidak menimpa data resmi; pilih pertahankan data resmi dengan catatan atau biarkan untuk ditinjau.</p>
    <div className="filters">
      <label>Jenis master
        <select value={kind} onChange={(event) => { setKind(event.target.value as Kind); setReview(null); setBatchId(''); }}>
          {(Object.keys(kindLabels) as Kind[]).map((value) => <option key={value} value={value}>{kindLabels[value]}</option>)}
        </select>
      </label>
      <button type="button" disabled={busy} onClick={() => void downloadTemplate()}>Unduh template XLSX</button>
    </div>
    <form onSubmit={stage}>
      <div className="filters">
        <label>File XLSX
          <input type="file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onChange={(event) => setFile(event.target.files?.[0] ?? null)} />
        </label>
        <button type="submit" disabled={busy || !file}>Unggah dan siapkan review</button>
      </div>
    </form>
    <div className="filters">
      <label>Batch
        <select value={batchId} onChange={(event) => { setBatchId(event.target.value); setReview(null); }}>
          <option value="">Pilih batch</option>
          {batches.map((batch) => <option key={batch.id} value={batch.id}>#{batch.id} · {batch.source_name} · {batch.status}</option>)}
        </select>
      </label>
      <button type="button" disabled={busy || !batchId} onClick={() => void loadReview().catch((cause) => setError(cause instanceof ApiError ? cause.code : 'Gagal memuat review.'))}>Muat review</button>
      <button type="button" disabled={busy} onClick={() => void refresh().catch((cause) => setError(cause instanceof ApiError ? cause.code : 'Gagal memuat batch.'))}>Segarkan</button>
    </div>
    {error && <p className="error" role="alert">{error}</p>}
    {message && <p role="status">{message}</p>}
    {review && <>
      <h3>Batch #{review.batch.id} · {review.batch.status}</h3>
      <p>Baris: {review.rows.length} · Klasifikasi: {Object.entries(review.preview.counts).map(([key, value]) => `${key}: ${value}`).join(' · ') || '—'}</p>
      <div className="tableWrap"><table>
        <thead><tr><th>Baris</th><th>Kode / NIP</th><th>Nama</th><th>Kitab / Status</th><th>Klasifikasi</th><th>Keputusan</th><th>Aksi</th></tr></thead>
        <tbody>{review.rows.map((row) => {
          const rowDecision = decisions[row.id] ?? row.decision as Decision;
          const choices = allowedDecisions(row);
          return <tr key={row.id}>
            <td>{row.source_row_number}</td>
            <td>{[row.source_code, row.source_identifier].filter(Boolean).join(' / ') || '—'}</td>
            <td>{row.source_name ?? '—'}</td>
            <td>{row.source_book_name ?? row.source_status ?? (row.source_active == null ? '—' : row.source_active ? 'Aktif' : 'Nonaktif')}</td>
            <td>{row.classification}{row.validation_error_code && <><br /><small className="error">{row.validation_error_code}</small></>}</td>
            <td>
              <select disabled={!mayReview || busy} value={rowDecision} onChange={(event) => setDecisions({ ...decisions, [row.id]: event.target.value as Decision })}>
                {choices.map((choice) => <option key={choice} value={choice}>{decisionLabels[choice]}</option>)}
              </select>
              {row.classification === 'CONFLICT' && rowDecision === 'KEEP_OFFICIAL' &&
                <input aria-label={`Catatan konflik baris ${row.source_row_number}`} placeholder="Catatan keputusan wajib" value={notes[row.id] ?? row.review_note ?? ''} onChange={(event) => setNotes({ ...notes, [row.id]: event.target.value })} />}
            </td>
            <td><button type="button" disabled={!mayReview || busy || (row.classification === 'CONFLICT' && rowDecision === 'KEEP_OFFICIAL' && !(notes[row.id] ?? row.review_note ?? '').trim())} onClick={() => void saveDecision(row)}>Simpan</button></td>
          </tr>;
        })}</tbody>
      </table></div>
      {mayReview && <button type="button" disabled={busy} onClick={() => void transition('approve')}>Setujui batch</button>}
      {review.batch.status === 'APPROVED' && <button type="button" disabled={busy} onClick={() => void transition('apply')}>Terapkan keputusan</button>}
    </>}
  </section>;
}
