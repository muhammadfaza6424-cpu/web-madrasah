import { FormEvent, useEffect, useState } from 'react';
import { api, ApiError } from '../../services/api';

type Decision = 'MATCH_EXISTING' | 'CREATE_NEW' | 'KEEP_HISTORICAL' | 'REVIEW';
type Batch = { id: number; source_name: string; status: string; total_rows: number; unresolved_rows: number; resolved_rows: number };
type Row = { id: number; source_row_number: number; source_nis: string | null; reviewed_nis: string | null; source_name: string; source_class: string | null; source_status: 'AKTIF' | 'BOYONG' | null; match_status: string; review_note: string | null; matched_student_name: string | null; matched_student_nis: string | null };
type Review = { batch: { source_name: string; status: string }; rows: Row[] };
type Edit = { row: Row; kind: 'NIS' | 'DECISION'; decision?: Decision; value: string; note: string };
type BulkDecision = 'CREATE_NEW' | 'KEEP_HISTORICAL';
type BulkPreview = { batchId: number; decision: BulkDecision; sourceStatus: 'AKTIF' | 'BOYONG'; rowCount: number; rowIds: number[]; classCounts: Record<string, number> };

export default function StudentImportReview() {
  const [batches, setBatches] = useState<Batch[]>([]), [batchId, setBatchId] = useState(''), [data, setData] = useState<Review | null>(null), [error, setError] = useState(''), [busy, setBusy] = useState(false), [edit, setEdit] = useState<Edit | null>(null), [confirm, setConfirm] = useState<'approve' | 'apply' | null>(null), [uploadFile, setUploadFile] = useState<File | null>(null), [sourceFilter, setSourceFilter] = useState('ALL'), [classFilter, setClassFilter] = useState('ALL'), [matchFilter, setMatchFilter] = useState('ALL'), [search, setSearch] = useState(''), [selectedRowIds, setSelectedRowIds] = useState<number[]>([]), [bulkPreview, setBulkPreview] = useState<BulkPreview | null>(null);
    async function loadBatches() {
      try {
        const result = await api<{ batches: Batch[] }>('/imports/students');
        setBatches(result.batches);
        if (!batchId && result.batches[0]) setBatchId(String(result.batches[0].id));
      } catch (cause) {
        setError(cause instanceof ApiError ? cause.code : 'Gagal memuat daftar batch.');
      }
    }
  useEffect(() => { void loadBatches(); }, []);
    async function stageUpload(event: FormEvent) {
      event.preventDefault();
      if (!uploadFile) {
        setError('Pilih file DOCX terlebih dahulu.');
        return;
      }
      setBusy(true);
      setError('');
      try {
        const form = new FormData();
        form.append('file', uploadFile);
        const staged = await api<{ batchId: number }>('/imports/students/stage', { method: 'POST', body: form });
        const stagedBatchId = String(staged.batchId);
        setBatchId(stagedBatchId);
        setUploadFile(null);
        setData(await api<Review>(`/imports/students/${stagedBatchId}/review`));
        await loadBatches();
      } catch (cause) {
        setError(cause instanceof ApiError ? cause.code : 'Gagal menyiapkan file DOCX.');
      } finally {
        setBusy(false);
      }
    }
  async function load(e?: FormEvent) { e?.preventDefault(); setError(''); if (!/^\d+$/.test(batchId)) { setError('Pilih batch yang valid.'); return; } try { setData(await api<Review>('/imports/students/' + batchId + '/review')); } catch (x) { setError(x instanceof ApiError ? x.code : 'Gagal memuat batch.'); } }
  function openNis(row: Row) { setEdit({ row, kind: 'NIS', value: row.reviewed_nis ?? row.source_nis ?? '', note: row.review_note ?? '' }); }
  function openDecision(row: Row, decision: Decision) { setEdit({ row, kind: 'DECISION', decision, value: '', note: row.review_note ?? '' }); }
  async function saveEdit(e: FormEvent) { e.preventDefault(); if (!edit) return; setBusy(true); setError(''); try { if (edit.kind === 'NIS') await api('/imports/students/' + batchId + '/review/' + edit.row.id + '/nis', { method: 'PUT', body: JSON.stringify({ reviewedNis: edit.value.trim() || null, note: edit.note.trim() || null }) }); else { const studentId = Number(edit.value); if (edit.decision === 'MATCH_EXISTING' && (!Number.isSafeInteger(studentId) || studentId <= 0)) throw new Error('INVALID_STUDENT_ID'); await api('/imports/students/' + batchId + '/review/' + edit.row.id, { method: 'PUT', body: JSON.stringify({ decision: edit.decision, studentId: edit.decision === 'MATCH_EXISTING' ? studentId : null, note: edit.note.trim() || null }) }); } setEdit(null); await Promise.all([load(), loadBatches()]); } catch (x) { setError(x instanceof ApiError ? x.code : x instanceof Error && x.message === 'INVALID_STUDENT_ID' ? 'ID santri tidak valid.' : 'Gagal menyimpan perubahan.'); } finally { setBusy(false); } }
  async function runBatch() { if (!confirm) return; setBusy(true); setError(''); try { await api('/imports/students/' + batchId + '/' + confirm, { method: 'POST' }); setConfirm(null); await Promise.all([load(), loadBatches()]); } catch (x) { setError(x instanceof ApiError ? x.code : 'Proses batch gagal.'); } finally { setBusy(false); } }
  const conflict = (r: Row) => ['REVIEW', 'AMBIGUOUS', 'EXACT_NAME_REVIEW'].includes(r.match_status) || /duplicate/i.test(r.review_note ?? '');
  const eligible = (row: Row, status: 'AKTIF' | 'BOYONG') => row.source_status === status && row.match_status === 'UNMATCHED' && Boolean(row.source_nis?.trim() && row.source_name.trim() && row.source_class?.trim());
  const visibleRows = (data?.rows ?? []).filter(row => (sourceFilter === 'ALL' || (sourceFilter === 'NULL' ? row.source_status === null : row.source_status === sourceFilter)) && (classFilter === 'ALL' || row.source_class === classFilter) && (matchFilter === 'ALL' || row.match_status === matchFilter) && (!search || `${row.source_nis ?? ''} ${row.reviewed_nis ?? ''} ${row.source_name} ${row.source_class ?? ''}`.toLocaleLowerCase('id-ID').includes(search.toLocaleLowerCase('id-ID'))));
  const classes = [...new Set((data?.rows ?? []).map(row => row.source_class).filter((value): value is string => Boolean(value)))].sort();
  const matchStatuses = [...new Set((data?.rows ?? []).map(row => row.match_status))].sort();
  const selectedRows = (data?.rows ?? []).filter(row => selectedRowIds.includes(row.id));
  const canBulkActive = selectedRows.length > 0 && selectedRows.every(row => eligible(row, 'AKTIF'));
  const canBulkBoyong = selectedRows.length > 0 && selectedRows.every(row => eligible(row, 'BOYONG'));
  function selectVisible(status: 'AKTIF' | 'BOYONG') { setSelectedRowIds(visibleRows.filter(row => eligible(row, status)).map(row => row.id)); }
  function toggleSelected(rowId: number) { setSelectedRowIds(current => current.includes(rowId) ? current.filter(id => id !== rowId) : [...current, rowId]); }
  async function previewBulk(decision: BulkDecision) {
    setError(''); setBusy(true);
    try { setBulkPreview(await api<BulkPreview>(`/imports/students/${batchId}/bulk-review/preview`, { method: 'POST', body: JSON.stringify({ decision, rowIds: selectedRowIds }) })); }
    catch (cause) { setError(cause instanceof ApiError ? cause.code : 'Gagal memvalidasi pilihan bulk.'); }
    finally { setBusy(false); }
  }
  async function applyBulk() {
    if (!bulkPreview) return;
    setBusy(true); setError('');
    try {
      await api(`/imports/students/${batchId}/bulk-review`, { method: 'POST', body: JSON.stringify({ decision: bulkPreview.decision, rowIds: bulkPreview.rowIds }) });
      setBulkPreview(null); setSelectedRowIds([]); await Promise.all([load(), loadBatches()]);
    } catch (cause) { setError(cause instanceof ApiError ? cause.code : 'Gagal menyimpan keputusan bulk.'); }
    finally { setBusy(false); }
  }
  return (
    <section className="card">
      <h2>Rekonsiliasi Import Santri Word</h2>
      <form onSubmit={stageUpload}>
        <label>Dokumen Word (.docx)<input type="file" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document" onChange={event => setUploadFile(event.target.files?.[0] ?? null)} /></label>
        <button type="submit" disabled={busy || !uploadFile}>Unggah dan Siapkan</button>
      </form>
      <form onSubmit={load}>
        <label>Batch<select value={batchId} onChange={event => { setBatchId(event.target.value); setData(null); setSelectedRowIds([]); setBulkPreview(null); }} required>
          <option value="">Pilih batch...</option>
          {batches.map(batch => <option key={batch.id} value={batch.id}>#{batch.id} · {batch.source_name} · {batch.status} · unresolved {batch.unresolved_rows}/{batch.total_rows}</option>)}
        </select></label>
        <button type="submit">Muat Review</button>
        <button type="button" onClick={loadBatches}>Segarkan daftar</button>
      </form>
      {!batches.length && <p>Belum ada batch santri Word di staging.</p>}
      {error && <p className="error">{error}</p>}
      {data && <>
        <p><b>{data.batch.source_name}</b> · status batch <b>{data.batch.status}</b></p>
        <div className="filters">
          <label>Cari<input value={search} onChange={event => setSearch(event.target.value)} placeholder="NIS, nama, kelas" /></label>
          <label>Status sumber<select value={sourceFilter} onChange={event => setSourceFilter(event.target.value)}><option value="ALL">Semua</option><option value="AKTIF">Aktif</option><option value="BOYONG">Boyong</option><option value="NULL">Tidak tercatat</option></select></label>
          <label>Kelas<select value={classFilter} onChange={event => setClassFilter(event.target.value)}><option value="ALL">Semua kelas</option>{classes.map(value => <option key={value} value={value}>{value}</option>)}</select></label>
          <label>Status review<select value={matchFilter} onChange={event => setMatchFilter(event.target.value)}><option value="ALL">Semua status</option>{matchStatuses.map(value => <option key={value} value={value}>{value}</option>)}</select></label>
        </div>
        <div className="filters">
          <span>{selectedRowIds.length} dipilih dari {visibleRows.length} baris terlihat</span>
          <button type="button" disabled={busy} onClick={() => selectVisible('AKTIF')}>Pilih Aktif eligible yang terlihat</button>
          <button type="button" disabled={busy} onClick={() => selectVisible('BOYONG')}>Pilih Boyong eligible yang terlihat</button>
          <button type="button" disabled={busy || !selectedRowIds.length} onClick={() => setSelectedRowIds([])}>Batalkan pilihan</button>
          <button type="button" disabled={busy || !canBulkActive || data.batch.status === 'APPROVED' || data.batch.status === 'IMPORTED'} onClick={() => void previewBulk('CREATE_NEW')}>Pratinjau buat Aktif</button>
          <button type="button" disabled={busy || !canBulkBoyong || data.batch.status === 'APPROVED' || data.batch.status === 'IMPORTED'} onClick={() => void previewBulk('KEEP_HISTORICAL')}>Pratinjau Boyong historis</button>
        </div>
        <div className="tableWrap"><table>
          <thead><tr><th>Pilih</th><th>Baris</th><th>NIS sumber</th><th>NIS terverifikasi</th><th>Nama</th><th>Kelas</th><th>Status sumber</th><th>Review</th><th>Santri cocok</th><th>Aksi</th></tr></thead>
          <tbody>{visibleRows.map(row => <tr key={row.id} className={conflict(row) ? 'review-conflict' : ''}>
            <td><input aria-label={`Pilih baris ${row.source_row_number}`} type="checkbox" checked={selectedRowIds.includes(row.id)} disabled={busy || !eligible(row, row.source_status === 'BOYONG' ? 'BOYONG' : 'AKTIF')} onChange={() => toggleSelected(row.id)} /></td>
            <td>{row.source_row_number}</td><td>{row.source_nis ?? '-'}</td><td>{row.reviewed_nis ?? '-'}</td>
            <td>{row.source_name}{conflict(row) && <><br /><strong>Perlu verifikasi</strong></>}</td><td>{row.source_class ?? '-'}</td>
            <td>{row.source_status === 'AKTIF' ? 'Aktif (sumber)' : row.source_status === 'BOYONG' ? 'Boyong (sumber)' : 'Tidak tercatat'}</td>
            <td>{row.match_status}</td><td>{row.matched_student_name ? `${row.matched_student_nis ?? '-'} · ${row.matched_student_name}` : '-'}</td>
            <td>
              <button type="button" onClick={() => openNis(row)}>Koreksi NIS</button>{' '}
              <button type="button" onClick={() => openDecision(row, 'MATCH_EXISTING')}>Cocokkan</button>{' '}
              {row.source_status === 'BOYONG' && row.match_status === 'UNMATCHED' && <button type="button" onClick={() => openDecision(row, 'KEEP_HISTORICAL')}>Boyong historis</button>}
              {row.source_status === 'AKTIF' && <>
                <button type="button" onClick={() => openDecision(row, 'CREATE_NEW')}>Santri Baru</button>{' '}
                <button type="button" onClick={() => openDecision(row, 'REVIEW')}>Tetap Review</button>
              </>}
            </td>
          </tr>)}</tbody>
        </table></div>
        <p><button type="button" disabled={busy || data.batch.status === 'IMPORTED'} onClick={() => setConfirm('approve')}>Setujui Batch</button>{' '}
          <button type="button" disabled={busy || data.batch.status !== 'APPROVED'} onClick={() => setConfirm('apply')}>Terapkan Batch</button></p>
      </>}
      {edit && <div className="modal-backdrop"><form className="modal-card" onSubmit={saveEdit}>
        <h3>{edit.kind === 'NIS' ? 'Koreksi NIS' : 'Keputusan Rekonsiliasi'}</h3>
        <p><b>{edit.row.source_name}</b><br />NIS sumber: {edit.row.source_nis ?? '-'} · Kelas: {edit.row.source_class ?? '-'} · Status sumber: {edit.row.source_status ?? '-'}</p>
        {edit.kind === 'NIS' ? <label>NIS hasil verifikasi<input value={edit.value} onChange={event => setEdit({ ...edit, value: event.target.value })} maxLength={50} /></label>
          : edit.decision === 'MATCH_EXISTING' ? <label>ID santri existing<input value={edit.value} onChange={event => setEdit({ ...edit, value: event.target.value })} inputMode="numeric" required /></label>
            : <p>Keputusan: <b>{edit.decision}</b></p>}
        <label>Catatan<textarea value={edit.note} onChange={event => setEdit({ ...edit, note: event.target.value })} maxLength={1000} /></label>
        <p><button type="submit" disabled={busy}>Simpan</button>{' '}<button type="button" disabled={busy} onClick={() => setEdit(null)}>Batal</button></p>
      </form></div>}
      {confirm && <div className="modal-backdrop"><div className="modal-card">
        <h3>Konfirmasi</h3>
        <p>{confirm === 'approve' ? 'Setujui batch setelah seluruh konflik selesai direview?' : 'Terapkan batch APPROVED ke data santri?'}</p>
        <p><button type="button" disabled={busy} onClick={runBatch}>Ya, lanjutkan</button>{' '}<button type="button" disabled={busy} onClick={() => setConfirm(null)}>Batal</button></p>
      </div></div>}
      {bulkPreview && <div className="modal-backdrop"><div className="modal-card" role="dialog" aria-modal="true" aria-labelledby="bulk-review-title">
        <h3 id="bulk-review-title">Konfirmasi keputusan massal</h3>
        <p>{bulkPreview.decision === 'CREATE_NEW' ? `${bulkPreview.rowCount} santri AKTIF akan ditandai untuk dibuat setelah approval.` : `${bulkPreview.rowCount} santri BOYONG akan ditandai sebagai historis; tidak dibuatkan enrollment aktif.`}</p>
        <p>{Object.entries(bulkPreview.classCounts).map(([className, count]) => `${className}: ${count}`).join(' · ')}</p>
        <p>Server memvalidasi ulang semua baris saat keputusan disimpan. Satu konflik akan membatalkan seluruh pilihan.</p>
        <p><button type="button" disabled={busy} onClick={() => void applyBulk()}>Simpan {bulkPreview.rowCount} keputusan</button>{' '}<button type="button" disabled={busy} onClick={() => setBulkPreview(null)}>Batal</button></p>
      </div></div>}
    </section>
  );
}
