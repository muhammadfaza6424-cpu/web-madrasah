import { FormEvent, useEffect, useState } from 'react';
import { api, apiUrl, ApiError } from '../../services/api';

type AcademicYear = { id: number; name: string; is_active: number; starts_on: string | null };
type Batch = { id: number; source_name: string; source_checksum: string; academic_year_id: number; status: string; total_rows: number; unresolved_rows: number };
type Row = { id: number; source_row_number: number; source_nis: string | null; source_name: string | null; source_class: string | null; source_status: 'AKTIF' | 'BOYONG' | null; classification: string; decision: string; validation_error_code: string | null; matched_student_id: number | null; matched_student_name: string | null; matched_student_status: string | null };
type Preview = { counts: Record<string, number>; decisions: Record<string, number>; duplicateNisCount: number; invalidCount: number };
type Review = { batch: Batch; rows: Row[]; preview: Preview };
type Decision = 'CREATE_NEW' | 'REUSE_EXISTING' | 'KEEP_HISTORICAL' | 'MARK_BOYONG' | 'REVIEW';

function allowedDecisions(row: Row): Decision[] {
  const eligible: Decision[] = [];
  if (row.classification === 'NEW_STUDENT' && row.source_status === 'AKTIF') eligible.push('CREATE_NEW');
  if (['UNCHANGED','CLASS_CHANGE'].includes(row.classification) && row.source_status === 'AKTIF' && row.matched_student_id) eligible.push('REUSE_EXISTING');
  if (row.classification === 'HISTORICAL' && row.source_status === 'BOYONG') eligible.push(row.matched_student_id ? 'MARK_BOYONG' : 'KEEP_HISTORICAL');
  return [...eligible, 'REVIEW'];
}

export default function StudentRosterImport() {
  const [years, setYears] = useState<AcademicYear[]>([]), [batches, setBatches] = useState<Batch[]>([]), [targetYearId, setTargetYearId] = useState(''), [batchId, setBatchId] = useState(''), [file, setFile] = useState<File | null>(null), [review, setReview] = useState<Review | null>(null), [error, setError] = useState(''), [busy, setBusy] = useState(false), [search, setSearch] = useState(''), [classFilter, setClassFilter] = useState('ALL'), [statusFilter, setStatusFilter] = useState('ALL'), [classificationFilter, setClassificationFilter] = useState('ALL'), [confirmation, setConfirmation] = useState<'approve' | 'apply' | null>(null), [result, setResult] = useState<Record<string, number> | null>(null);

  async function refresh() {
    const [yearResult, batchResult] = await Promise.all([
      api<{ academicYears: AcademicYear[] }>('/academic-years'),
      api<{ batches: Batch[] }>('/imports/students/roster'),
    ]);
    setYears(yearResult.academicYears);
    setBatches(batchResult.batches);
    if (!targetYearId) {
      const target = yearResult.academicYears.find(year => !year.is_active) ?? yearResult.academicYears[0];
      if (target) setTargetYearId(String(target.id));
    }
    if (!batchId && batchResult.batches[0]) setBatchId(String(batchResult.batches[0].id));
  }

  useEffect(() => { void refresh().catch(cause => setError(cause instanceof ApiError ? cause.code : 'Gagal memuat tahun ajaran dan batch.')); }, []);

  async function loadReview(id = batchId) {
    if (!/^\d+$/.test(id)) return;
    setReview(await api<Review>(`/imports/students/roster/${id}/review`));
  }

  async function downloadTemplate() {
    setBusy(true); setError('');
    try {
      const response = await fetch(apiUrl('/imports/students/roster/template'), { credentials: 'include' });
      if (!response.ok) throw new ApiError(response.status, (await response.json().catch(() => null))?.error ?? 'TEMPLATE_DOWNLOAD_FAILED');
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url; link.download = 'student-roster-template.xlsx'; link.click(); URL.revokeObjectURL(url);
    } catch (cause) { setError(cause instanceof ApiError ? cause.code : 'Gagal mengunduh template.'); }
    finally { setBusy(false); }
  }

  async function stage(event: FormEvent) {
    event.preventDefault();
    if (!file || !targetYearId) { setError('Pilih file XLSX dan tahun ajaran tujuan.'); return; }
    setBusy(true); setError(''); setResult(null);
    try {
      const form = new FormData(); form.append('file', file); form.append('targetYearId', targetYearId);
      const staged = await api<{ batchId: number }>('/imports/students/roster/stage', { method: 'POST', body: form });
      setFile(null); setBatchId(String(staged.batchId));
      await Promise.all([loadReview(String(staged.batchId)), refresh()]);
    } catch (cause) { setError(cause instanceof ApiError ? cause.code : 'Gagal menyiapkan roster.'); }
    finally { setBusy(false); }
  }

  async function saveDecision(row: Row, decision: Decision) {
    setBusy(true); setError('');
    try {
      await api(`/imports/students/roster/${batchId}/review/${row.id}`, { method: 'PUT', body: JSON.stringify({ decision }) });
      await Promise.all([loadReview(), refresh()]);
    } catch (cause) { setError(cause instanceof ApiError ? cause.code : 'Gagal menyimpan keputusan row.'); }
    finally { setBusy(false); }
  }

  async function transition() {
    if (!confirmation) return;
    setBusy(true); setError('');
    try {
      if (confirmation === 'approve') {
        await api(`/imports/students/roster/${batchId}/approve`, { method: 'POST' });
        setResult(null);
      } else {
        const applied = await api<Record<string, number>>(`/imports/students/roster/${batchId}/apply`, { method: 'POST' });
        setResult(applied);
      }
      setConfirmation(null); await Promise.all([loadReview(), refresh()]);
    } catch (cause) { setError(cause instanceof ApiError ? cause.code : 'Proses roster gagal.'); }
    finally { setBusy(false); }
  }

  const rows = review?.rows.filter(row => (classFilter === 'ALL' || row.source_class === classFilter) && (statusFilter === 'ALL' || row.source_status === statusFilter) && (classificationFilter === 'ALL' || row.classification === classificationFilter) && (!search || `${row.source_nis ?? ''} ${row.source_name ?? ''} ${row.source_class ?? ''}`.toLocaleLowerCase('id-ID').includes(search.toLocaleLowerCase('id-ID')))) ?? [];
  const classes = [...new Set(review?.rows.map(row => row.source_class).filter((value): value is string => Boolean(value)) ?? [])].sort();
  const classifications = [...new Set(review?.rows.map(row => row.classification) ?? [])].sort();
  const mayReview = review && ['STAGED', 'REVIEW_REQUIRED'].includes(review.batch.status);

  return <section className="card">
    <h2>Roster Tahun Ajaran</h2>
    <form onSubmit={stage}>
      <div className="filters">
        <label>Tahun ajaran tujuan<select value={targetYearId} onChange={event => setTargetYearId(event.target.value)} required>{years.map(year => <option key={year.id} value={year.id}>{year.name}{year.is_active ? ' · aktif' : ''}</option>)}</select></label>
        <label>File roster (.xlsx)<input type="file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onChange={event => setFile(event.target.files?.[0] ?? null)} /></label>
        <button type="button" disabled={busy} onClick={() => void downloadTemplate()}>Unduh template</button>
        <button type="submit" disabled={busy || !file || !targetYearId}>Unggah dan validasi</button>
      </div>
    </form>
    <div className="filters">
      <label>Batch<select value={batchId} onChange={event => { setBatchId(event.target.value); setReview(null); setResult(null); }}><option value="">Pilih batch</option>{batches.map(batch => <option key={batch.id} value={batch.id}>#{batch.id} · {batch.source_name} · {batch.status}</option>)}</select></label>
      <button type="button" disabled={!batchId || busy} onClick={() => void loadReview().catch(cause => setError(cause instanceof ApiError ? cause.code : 'Gagal memuat review roster.'))}>Muat review</button>
      <button type="button" disabled={busy} onClick={() => void refresh().catch(cause => setError(cause instanceof ApiError ? cause.code : 'Gagal memperbarui daftar batch.'))}>Segarkan</button>
    </div>
    {error && <p role="alert" className="error">{error}</p>}
    {result && <p role="status">Diterapkan: {result.createdActive} Aktif baru, {result.enrolledExisting} enrollment existing, {result.createdHistorical} historis baru, {result.markedBoyong} ditandai Boyong, {result.unchanged} unchanged.</p>}
    {review && <>
      <p><b>{review.batch.source_name}</b> · batch {review.batch.status} · checksum {review.batch.source_checksum}</p>
      <p>Klasifikasi: {Object.entries(review.preview.counts).map(([key, count]) => `${key} ${count}`).join(' · ')} · invalid {review.preview.invalidCount} · duplicate NIS {review.preview.duplicateNisCount}</p>
      <div className="filters">
        <label>Cari<input value={search} onChange={event => setSearch(event.target.value)} placeholder="NIS, nama, kelas" /></label>
        <label>Kelas<select value={classFilter} onChange={event => setClassFilter(event.target.value)}><option value="ALL">Semua</option>{classes.map(value => <option key={value}>{value}</option>)}</select></label>
        <label>Status sumber<select value={statusFilter} onChange={event => setStatusFilter(event.target.value)}><option value="ALL">Semua</option><option value="AKTIF">Aktif</option><option value="BOYONG">Boyong</option></select></label>
        <label>Klasifikasi<select value={classificationFilter} onChange={event => setClassificationFilter(event.target.value)}><option value="ALL">Semua</option>{classifications.map(value => <option key={value}>{value}</option>)}</select></label>
      </div>
      <div className="tableWrap"><table><thead><tr><th>Baris</th><th>NIS</th><th>Nama</th><th>Kelas</th><th>Sumber</th><th>Klasifikasi</th><th>Santri cocok</th><th>Keputusan</th><th>Error</th></tr></thead><tbody>
        {rows.map(row => <tr key={row.id}><td>{row.source_row_number}</td><td>{row.source_nis ?? '-'}</td><td>{row.source_name ?? '-'}</td><td>{row.source_class ?? '-'}</td><td>{row.source_status ?? '-'}</td><td>{row.classification}</td><td>{row.matched_student_name ? `${row.matched_student_name} · ${row.matched_student_status}` : '-'}</td><td><select aria-label={`Keputusan baris ${row.source_row_number}`} disabled={!mayReview || busy || Boolean(row.validation_error_code) || ['CONFLICT','AMBIGUOUS','INVALID'].includes(row.classification)} value={row.decision} onChange={event => void saveDecision(row, event.target.value as Decision)}>{allowedDecisions(row).map(decision => <option key={decision}>{decision}</option>)}</select></td><td>{row.validation_error_code ?? '-'}</td></tr>)}
      </tbody></table></div>
      <p><button type="button" disabled={busy || !mayReview || review.preview.invalidCount > 0 || review.preview.duplicateNisCount > 0} onClick={() => setConfirmation('approve')}>Setujui roster</button>{' '}<button type="button" disabled={busy || review.batch.status !== 'APPROVED'} onClick={() => setConfirmation('apply')}>Terapkan tahun ajaran</button></p>
    </>}
    {confirmation && <div className="modal-backdrop"><div className="modal-card" role="dialog" aria-modal="true"><h3>{confirmation === 'approve' ? 'Setujui roster' : 'Terapkan roster'}</h3><p>{confirmation === 'approve' ? `Server memvalidasi ${review?.rows.length ?? 0} row dan semua keputusan sebelum approval.` : `Terapkan keputusan terverifikasi untuk ${review?.rows.length ?? 0} row secara transaksional. Riwayat enrollment lama dipertahankan.`}</p><button type="button" disabled={busy} onClick={() => void transition()}>{confirmation === 'approve' ? 'Setujui' : 'Terapkan'}</button>{' '}<button type="button" disabled={busy} onClick={() => setConfirmation(null)}>Batal</button></div></div>}
  </section>;
}
