import { FormEvent, useEffect, useState } from 'react';
import { api, apiUrl, ApiError } from '../../services/api';

type AcademicYear = { id: number; name: string; is_active: number };
type Batch = { id: number; source_name: string; status: string; academic_year_id: number; total_rows: number; unresolved_rows: number };
type Row = {
  id: number;
  source_row_number: number;
  source_nis: string;
  source_name: string | null;
  source_class: string | null;
  source_subject: string;
  semester: 'GANJIL' | 'GENAP';
  score: number | null;
  notes: string | null;
  matched_student_id: number | null;
  matched_subject_id: number | null;
  match_status: string;
  review_note: string | null;
};
type Review = { batch: Batch; rows: Row[] };
type Candidates = {
  students: Array<{ id: number; nis: string; name: string; status: string }>;
  subjects: Array<{ id: number; code: string | null; name: string; book_name: string | null }>;
};
type Resolution = { studentId: string; subjectId: string; note: string };

function displayError(cause: unknown, fallback: string): string {
  return cause instanceof ApiError ? cause.code : fallback;
}

export default function GradeImport() {
  const [years, setYears] = useState<AcademicYear[]>([]);
  const [batches, setBatches] = useState<Batch[]>([]);
  const [yearId, setYearId] = useState('');
  const [batchId, setBatchId] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [review, setReview] = useState<Review | null>(null);
  const [candidates, setCandidates] = useState<Record<number, Candidates>>({});
  const [resolutions, setResolutions] = useState<Record<number, Resolution>>({});
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  async function refresh() {
    const [batchResult, yearResult] = await Promise.all([
      api<{ batches: Batch[] }>('/imports/grades'),
      api<{ academicYears: AcademicYear[] }>('/academic-years'),
    ]);
    setBatches(batchResult.batches);
    setYears(yearResult.academicYears);
    if (!yearId && yearResult.academicYears[0]) setYearId(String(yearResult.academicYears[0].id));
    if (!batchId && batchResult.batches[0]) setBatchId(String(batchResult.batches[0].id));
  }

  useEffect(() => {
    void refresh().catch(cause => setError(displayError(cause, 'Gagal memuat batch nilai.')));
  }, []);

  async function loadReview(id = batchId) {
    if (!/^\d+$/.test(id)) return;
    const result = await api<Review>(`/imports/grades/${id}/review`);
    setReview(result);
    setResolutions(Object.fromEntries(result.rows.map(row => [
      row.id,
      {
        studentId: row.matched_student_id ? String(row.matched_student_id) : '',
        subjectId: row.matched_subject_id ? String(row.matched_subject_id) : '',
        note: row.review_note ?? '',
      },
    ])));
    setCandidates({});
  }

  async function downloadTemplate() {
    setBusy(true);
    setError('');
    try {
      const response = await fetch(apiUrl('/imports/grades/template'), { credentials: 'include' });
      if (!response.ok) throw new ApiError(response.status, (await response.json().catch(() => null))?.error ?? 'TEMPLATE_DOWNLOAD_FAILED');
      const url = URL.createObjectURL(await response.blob());
      const link = document.createElement('a');
      link.href = url;
      link.download = 'grade-template.xlsx';
      link.click();
      URL.revokeObjectURL(url);
    } catch (cause) { setError(displayError(cause, 'Gagal mengunduh template nilai.')); }
    finally { setBusy(false); }
  }

  async function stage(event: FormEvent) {
    event.preventDefault();
    if (!file || !yearId) { setError('Pilih file XLSX dan tahun ajaran.'); return; }
    setBusy(true);
    setError('');
    setMessage('');
    try {
      const form = new FormData();
      form.append('file', file);
      form.append('academicYearId', yearId);
      const result = await api<{ batchId: number }>('/imports/grades/stage', { method: 'POST', body: form });
      setFile(null);
      setBatchId(String(result.batchId));
      await Promise.all([loadReview(String(result.batchId)), refresh()]);
    } catch (cause) { setError(displayError(cause, 'Gagal menyiapkan batch nilai.')); }
    finally { setBusy(false); }
  }

  async function loadCandidates(rowId: number) {
    setBusy(true);
    setError('');
    try {
      const result = await api<Candidates>(`/imports/grades/candidates?batchId=${batchId}&rowId=${rowId}`);
      setCandidates(current => ({ ...current, [rowId]: result }));
    } catch (cause) { setError(displayError(cause, 'Gagal memuat kandidat pencocokan.')); }
    finally { setBusy(false); }
  }

  async function saveResolution(row: Row) {
    const value = resolutions[row.id];
    if (!value) return;
    setBusy(true);
    setError('');
    try {
      await api(`/imports/grades/${batchId}/review/${row.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          studentId: value.studentId ? Number(value.studentId) : null,
          subjectId: value.subjectId ? Number(value.subjectId) : null,
          note: value.note.trim() || null,
        }),
      });
      await loadReview();
    } catch (cause) { setError(displayError(cause, 'Gagal menyimpan pencocokan nilai.')); }
    finally { setBusy(false); }
  }

  async function transition(action: 'approve' | 'apply') {
    if (!review || !window.confirm(action === 'approve'
      ? 'Setujui nilai setelah semua siswa, mapel, dan semester ditinjau?'
      : 'Terapkan nilai resmi dari batch yang telah disetujui?')) return;
    setBusy(true);
    setError('');
    setMessage('');
    try {
      await api(`/imports/grades/${batchId}/${action}`, {
        method: 'POST',
        ...(action === 'approve' ? { body: JSON.stringify({ academicYearId: review.batch.academic_year_id }) } : {}),
      });
      setMessage(action === 'approve' ? 'Batch disetujui; penerapan harus dijalankan terpisah.' : 'Nilai dari batch berhasil diterapkan.');
      await Promise.all([loadReview(), refresh()]);
    } catch (cause) { setError(displayError(cause, 'Proses batch nilai gagal.')); }
    finally { setBusy(false); }
  }

  return <section className="card">
    <h2>Import Nilai XLSX</h2>
    <p>Semester wajib diisi per baris sumber; sistem tidak menetapkan GANJIL/GENAP otomatis. Upload hanya membuat batch staging, dan nilai baru diterapkan setelah review, approval, serta apply terpisah.</p>
    <form onSubmit={stage}>
      <div className="filters">
        <label>Tahun ajaran<select value={yearId} onChange={event => setYearId(event.target.value)} required>
          {years.map(year => <option key={year.id} value={year.id}>{year.name}{year.is_active ? ' · aktif' : ''}</option>)}
        </select></label>
        <label>File nilai (.xlsx)<input type="file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" onChange={event => setFile(event.target.files?.[0] ?? null)} /></label>
        <button type="button" disabled={busy} onClick={() => void downloadTemplate()}>Unduh template</button>
        <button type="submit" disabled={busy || !file || !yearId}>Unggah untuk review</button>
      </div>
    </form>
    <div className="filters">
      <label>Batch<select value={batchId} onChange={event => { setBatchId(event.target.value); setReview(null); }}><option value="">Pilih batch</option>
        {batches.map(batch => <option key={batch.id} value={batch.id}>#{batch.id} · {batch.source_name} · {batch.status} · belum cocok {batch.unresolved_rows}</option>)}
      </select></label>
      <button type="button" disabled={busy || !batchId} onClick={() => void loadReview().catch(cause => setError(displayError(cause, 'Gagal memuat review nilai.')))}>Muat review</button>
      <button type="button" disabled={busy} onClick={() => void refresh().catch(cause => setError(displayError(cause, 'Gagal memperbarui batch.')))}>Segarkan</button>
      {review && ['STAGED', 'REVIEW_REQUIRED'].includes(review.batch.status) &&
        <button type="button" disabled={busy} onClick={() => void transition('approve')}>Setujui batch</button>}
      {review?.batch.status === 'APPROVED' &&
        <button type="button" disabled={busy} onClick={() => void transition('apply')}>Terapkan nilai</button>}
    </div>
    {error && <p role="alert" className="error">{error}</p>}
    {message && <p role="status">{message}</p>}
    {review && <div className="tableWrap">
      <table><thead><tr><th>Baris</th><th>NIS / Nama sumber</th><th>Mapel</th><th>Semester</th><th>Nilai</th><th>Pencocokan</th><th>Aksi</th></tr></thead>
        <tbody>{review.rows.map(row => {
          const value = resolutions[row.id] ?? { studentId: '', subjectId: '', note: '' };
          const options = candidates[row.id];
          return <tr key={row.id}>
            <td>{row.source_row_number}</td>
            <td>{row.source_nis} · {row.source_name ?? '—'}{row.source_class ? ` · ${row.source_class}` : ''}</td>
            <td>{row.source_subject}</td><td>{row.semester}</td><td>{row.score ?? '—'}</td>
            <td>{row.match_status}{row.review_note ? ` · ${row.review_note}` : ''}</td>
            <td>
              {!options
                ? <button type="button" disabled={busy || !['STAGED', 'REVIEW_REQUIRED'].includes(review.batch.status)} onClick={() => void loadCandidates(row.id)}>Tinjau kandidat</button>
                : <>
                  <label>Santri<select value={value.studentId} disabled={busy || !['STAGED', 'REVIEW_REQUIRED'].includes(review.batch.status)} onChange={event => setResolutions(current => ({ ...current, [row.id]: { ...value, studentId: event.target.value } }))}>
                    <option value="">Belum dipilih</option>{options.students.map(student => <option key={student.id} value={student.id}>{student.nis} · {student.name} · {student.status}</option>)}
                  </select></label>
                  <label>Mapel<select value={value.subjectId} disabled={busy || !['STAGED', 'REVIEW_REQUIRED'].includes(review.batch.status)} onChange={event => setResolutions(current => ({ ...current, [row.id]: { ...value, subjectId: event.target.value } }))}>
                    <option value="">Belum dipilih</option>{options.subjects.map(subject => <option key={subject.id} value={subject.id}>{subject.code ? `${subject.code} · ` : ''}{subject.name}{subject.book_name ? ` · ${subject.book_name}` : ''}</option>)}
                  </select></label>
                  <label>Catatan override<input value={value.note} maxLength={500} onChange={event => setResolutions(current => ({ ...current, [row.id]: { ...value, note: event.target.value } }))} /></label>
                  <button type="button" disabled={busy || !['STAGED', 'REVIEW_REQUIRED'].includes(review.batch.status)} onClick={() => void saveResolution(row)}>Simpan pencocokan</button>
                </>}
            </td>
          </tr>;
        })}</tbody>
      </table>
    </div>}
  </section>;
}
