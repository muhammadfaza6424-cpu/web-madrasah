import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './app/App';

// Keep one browser origin for local cookies and API requests.
if (window.location.hostname === '127.0.0.1' && window.location.port === '5173') {
  const destination = new URL(window.location.href);
  destination.hostname = 'localhost';
  window.location.replace(destination.href);
} else {
  createRoot(document.getElementById('root')!).render(<React.StrictMode><App /></React.StrictMode>);
}
