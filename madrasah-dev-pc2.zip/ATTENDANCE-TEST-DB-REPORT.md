# Laporan Audit Database Test Attendance (Tahap 1.5)

Tanggal: 2026-10-02
Workspace: `/var/www/madrasah-dev`
Status: AUDIT ONLY — tidak ada migration dijalankan, tidak ada kode diubah.

## 1. Database test yang ditemukan

- **Tidak ada kredensial database test yang tersedia** di workspace ini.
- Yang ditemukan hanya nama database test/CI yang diharapkan: **`madrasah_ci`**, direferensikan di:
  - `scripts/production/migrate-test.mjs` (guard: wajib `DB_NAME === 'madrasah_ci'`)
  - `scripts/production/validate-test-schema.mjs` (guard yang sama)
  - `scripts/production/reset-test-schema.mjs` (guard yang sama)
  - `scripts/production/seed-permissions.mjs` (guard yang sama)
  - `scripts/production/backup-restore-test.mjs` (guard yang sama)
- Server MySQL lokal berjalan di `127.0.0.1:3306` (MySQL Community Server, aktif sejak 2026-09-30), tetapi **tanpa kredensial** penulis tidak dapat memverifikasi apakah schema `madrasah_ci` benar-benar ada maupun kondisinya.
- Percobaan `mysqladmin ping` gagal dengan `Access denied` (tanpa password) — konsisten dengan tidak adanya kredensial.
- Tidak ada file `/var/www/madrasah/.env.production.local` yang dibaca (sesuai aturan), dan memang tidak ada file `.env` apapun di `/var/www/madrasah-dev` selain `backend/.env.example`.

## 2. Cara konfigurasi database test ditemukan

- `package.json` script:
  - `"db:migrate:test": "node --env-file=.env scripts/production/migrate-test.mjs"` — mengharapkan file **`/var/www/madrasah-dev/.env`**
  - `"db:validate:test": "node scripts/production/validate-test-schema.mjs"` — memakai env dari shell / `dotenv/config` (CWD)
  - `"test:fixture": "node tests/integration/setup-role-fixture.mjs"` — direktori `tests/` tidak ditemukan di workspace
- Semua script production test memakai `import 'dotenv/config'` sehingga env diambil dari `.env` di working directory (root workspace).
- Variabel yang diperlukan: `DB_HOST`, `DB_PORT` (default 3306), `DB_NAME` (harus `madrasah_ci`), `DB_USER`, `DB_PASSWORD`.
- **File `/var/www/madrasah-dev/.env` tidak ada.** Akibatnya:
  - `db:migrate:test` akan gagal (`--env-file=.env` tidak menemukan file atau variabel kosong).
  - `db:validate:test` akan gagal di guard `DB_NAME !== 'madrasah_ci'` / `Missing ...`.
- Template konfigurasi umum hanya ada di `backend/.env.example` (mencontohkan `DB_NAME=madrasah_diniyah`, bukan test).

## 3. Bukti database tersebut bukan production

- Tidak dapat dibuktikan secara langsung karena tidak ada akses DB.
- Bukti kontekstual/tidak langsung:
  - Semua script test membatasi secara eksplisit `DB_NAME === 'madrasah_ci'` dan melempar error selain itu.
  - `backup-restore-test.mjs` dan `reset-test-schema.mjs` menolak jalan di luar `madrasah_ci`.
  - Guard ini memisahkan test dari database production (`madrasah`), tetapi **verifikasi aktual** (mis. `SELECT DATABASE()` atau listing schema) belum dapat dilakukan tanpa kredensial.
- Operator wajib memastikan `DB_NAME` di `.env` test benar-benar `madrasah_ci` dan user DB yang dipakai tidak memiliki akses ke schema production.

## 4. Status schema_migrations

- Tidak dapat diperiksa langsung (tidak ada kredensial).
- Hanya diketahui ekspektasi repository: migration di `database/migrations/` berurutan hingga `038` (terakhir pra-attendance), dan `validate-test-schema.mjs` masih mengasersi `COUNT(*) = 38`.
- Stage 1 report sebelumnya (baris 124, 137) mencatat: "Tidak ada `.env` dev/test dan tidak ada kredensial DB di `/var/www/madrasah-dev`".

## 5. Migration terakhir

- Migration terakhir sebelum perubahan attendance: **`038_master_data_import_admin_permission.sql`**.
- Berikutnya: **`039_attendance_schedule_session.sql`** (sudah ada di repo, belum tentu diterapkan).

## 6. Apakah migration 039 sudah diterapkan

- Tidak dapat diverifikasi tanpa kredensial DB.
- Dugaan kuat: belum diterapkan, karena `validate-test-schema.mjs` masih mengharapkan 38 migration dan Stage 1 report menyatakan belum ada pengujian skema `madrasah_ci`. **Ini perlu dikonfirmasi operator.**

## 7. Apakah database siap untuk pengujian attendance

**Belum siap.** Yang belum tersedia:

1. File `/var/www/madrasah-dev/.env` dengan `DB_HOST`, `DB_PORT`, `DB_NAME=madrasah_ci`, `DB_USER`, `DB_PASSWORD`.
2. Konfirmasi schema `madrasah_ci` benar-benar ada di server MySQL lokal dan bukan production.
3. Konfirmasi `schema_migrations` di `madrasah_ci` berisi tepat 38 baris (migration terakhir `038`).
4. Konfirmasi `039_attendance_schedule_session.sql` belum diterapkan (atau masih aman untuk di-reset).
5. Direktori `tests/integration/` untuk `test:fixture` belum ada di workspace.

## 8. Jika belum siap, apa yang kurang

- Satu file `.env` test (atau env var shell) berisi kredensial database lokal yang menunjuk ke schema `madrasah_ci`.
- Verifikasi manual oleh operator bahwa:
  - `madrasah_ci` ada dan terpisah dari production,
  - migration count = 38,
  - `039` belum diterapkan.
- Setelah itu: jalankan `npm run db:validate:test` untuk membuktikan schema siap, baru kemudian (pada tahap berikutnya, bukan sekarang) migration `039` dapat dijalankan dengan `npm run db:migrate:test`.

## 9. Bagian `validate-test-schema.mjs` yang masih mengharapkan count = 38

- Baris: `assert.equal(Number(migration.count), 38, 'Expected 38 applied migrations');`
- Artinya, sampai `039` diterapkan di `madrasah_ci`, script ini TIDAK akan lulus dan harus diperbarui (item 8.2 di Stage 1 report) menjadi 39 serta menambah asersi struktur attendance. Saat ini **belum diubah** sesuai instruksi audit.

## Keamanan

- Tidak ada password, token, connection string, atau secret lain yang ditampilkan di laporan ini.
- Tidak ada migration dijalankan, tidak ada dependency di-install, tidak ada source code diubah, tidak ada data resmi dibuat, tidak ada push ke GitHub, tidak ada deploy, tidak ada perubahan frontend.
