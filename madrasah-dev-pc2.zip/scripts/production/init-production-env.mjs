import { randomBytes } from 'node:crypto';
import { writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = fileURLToPath(new URL('../..', import.meta.url));
const target = path.join(root, '.env.production.local');
const jwtSecret = randomBytes(48).toString('base64url');
const content = `# Local-only production environment. Never commit this file.
NODE_ENV=production
PORT=3000
FRONTEND_ORIGIN=https://localhost

DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=madrasah
DB_USER=madrasah_app
DB_PASSWORD=

UPLOAD_ROOT=${path.join(root, 'storage', 'production-uploads').replaceAll('\\', '/')}
AUTH_JWT_SECRET=${jwtSecret}
AUTH_COOKIE_NAME=madin_session
AUTH_TOKEN_MINUTES=480

SMTP_HOST=
SMTP_PORT=465
SMTP_USER=
SMTP_PASSWORD=
SUPER_ADMIN_RECOVERY_EMAIL=
`;
await writeFile(target, content, { encoding: 'utf8', flag: 'wx', mode: 0o600 });
console.log('Production environment file created locally. Fill required blank values without printing them.');
