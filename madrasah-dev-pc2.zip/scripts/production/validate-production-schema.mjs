import mysql from 'mysql2/promise';

if (process.env.DB_NAME !== 'madrasah') throw new Error('Production schema validation is restricted to madrasah');
for (const key of ['DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASSWORD']) if (!process.env[key]) throw new Error(`${key} is required`);
const db = await mysql.createConnection({ host: process.env.DB_HOST, port: Number(process.env.DB_PORT ?? 3306), user: process.env.DB_USER, password: process.env.DB_PASSWORD, database: process.env.DB_NAME });
try {
  const [[migration]] = await db.query('SELECT COUNT(*) AS count FROM schema_migrations');
  const [[tables]] = await db.query("SELECT COUNT(*) AS count FROM information_schema.tables WHERE table_schema=DATABASE() AND table_type='BASE TABLE'");
  const [[foreignKeys]] = await db.query("SELECT COUNT(*) AS count FROM information_schema.table_constraints WHERE constraint_schema=DATABASE() AND constraint_type='FOREIGN KEY'");
  const [[uniqueIndexes]] = await db.query("SELECT COUNT(*) AS count FROM information_schema.statistics WHERE table_schema=DATABASE() AND non_unique=0");
  const required = ['roles', 'permissions', 'role_permissions', 'users', 'students', 'teachers', 'classes', 'subjects', 'reports', 'certificates', 'audit_logs'];
  const [rows] = await db.query('SELECT table_name FROM information_schema.tables WHERE table_schema=DATABASE()');
  const actual = new Set(rows.map(row => row.TABLE_NAME ?? row.table_name));
  const missing = required.filter(name => !actual.has(name));
  if (missing.length) throw new Error(`Missing critical tables: ${missing.join(',')}`);
  const counts = {};
  for (const table of ['users', 'students', 'teachers', 'classes', 'subjects', 'reports', 'certificates', 'import_batches']) {
    const [[row]] = await db.query(`SELECT COUNT(*) AS count FROM \`${table}\``);
    counts[table] = Number(row.count);
  }
  if (Object.values(counts).some(count => count !== 0)) throw new Error(`Production contains non-empty operational/academic tables: ${Object.entries(counts).filter(([, count]) => count !== 0).map(([table, count]) => `${table}=${count}`).join(',')}`);
  console.log(JSON.stringify({ database: 'madrasah', migrations: Number(migration.count), tables: Number(tables.count), foreignKeys: Number(foreignKeys.count), uniqueIndexes: Number(uniqueIndexes.count), criticalTables: required.length, fixtureData: 'none' }));
} finally {
  await db.end();
}
