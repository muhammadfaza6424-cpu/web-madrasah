import 'dotenv/config';

if (process.env.DB_NAME !== 'madrasah_ci') {
  throw new Error('Test migration runner is restricted to madrasah_ci');
}

await import('./migrate.mjs');