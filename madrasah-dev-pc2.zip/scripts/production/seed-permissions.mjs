import 'dotenv/config';
import mysql from 'mysql2/promise';
import { readFile } from 'node:fs/promises';

if (process.env.DB_NAME !== 'madrasah_ci') throw new Error('Permission seed is restricted to madrasah_ci');
for (const key of ['DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASSWORD']) {
  if (process.env[key] === undefined) throw new Error(`Missing ${key}`);
}

const sql = await readFile(new URL('../../database/seeds/001_roles_permissions.sql', import.meta.url), 'utf8');
const db = await mysql.createConnection({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT ?? 3306),
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  multipleStatements: true,
});

try {
  await db.beginTransaction();
  await db.query(sql);
  await db.commit();
  console.log('Permission seed applied to madrasah_ci.');
} catch (error) {
  await db.rollback();
  throw error;
} finally {
  await db.end();
}