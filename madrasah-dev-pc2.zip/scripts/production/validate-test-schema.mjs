import 'dotenv/config';
import assert from 'node:assert/strict';
import mysql from 'mysql2/promise';

if (process.env.DB_NAME !== 'madrasah_ci') throw new Error('Schema validation is restricted to madrasah_ci');
for (const key of ['DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASSWORD']) {
  if (process.env[key] === undefined) throw new Error(`Missing ${key}`);
}

const db = await mysql.createConnection({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT ?? 3306),
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});

try {
  const [[migration]] = await db.query('SELECT COUNT(*) AS count FROM schema_migrations');
  assert.equal(Number(migration.count), 38, 'Expected 38 applied migrations');

  const [sourceStatusColumns] = await db.query(
    "SELECT column_type AS columnType, is_nullable AS isNullable, column_default AS columnDefault FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='import_student_rows' AND column_name='source_status'",
  );
  assert.equal(sourceStatusColumns.length, 1, 'Missing import_student_rows.source_status');
  assert.equal(String(sourceStatusColumns[0].columnType).toLowerCase(), "enum('aktif','boyong')");
  assert.equal(sourceStatusColumns[0].isNullable, 'YES');
  assert.equal(sourceStatusColumns[0].columnDefault, null);
  const [[sourceStatusValues]] = await db.query('SELECT COUNT(*) AS count FROM import_student_rows WHERE source_status IS NOT NULL');
  assert.equal(Number(sourceStatusValues.count), 0, 'Existing staged rows must remain NULL after additive migration');

  const [rosterSourceType] = await db.query("SELECT column_type AS columnType FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='import_batches' AND column_name='source_type'");
  assert.ok(String(rosterSourceType[0]?.columnType).toLowerCase().includes("'excel_student_roster'"), 'Missing EXCEL_STUDENT_ROSTER source type');
  const [rosterTables] = await db.query("SELECT TABLE_NAME FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='import_student_roster_rows'");
  assert.equal(rosterTables.length, 1, 'Missing roster staging table');
  const [rosterColumns] = await db.query("SELECT COLUMN_NAME FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='import_student_roster_rows'");
  const rosterColumnNames = new Set(rosterColumns.map((row) => row.COLUMN_NAME ?? row.column_name));
  for (const column of ['source_row_number','source_nis','source_name','source_class','source_status','source_class_id','matched_student_id','classification','decision','resolved_by','resolved_at']) {
    assert.ok(rosterColumnNames.has(column), `Missing roster staging column ${column}`);
  }
  const [masterRowsTables] = await db.query("SELECT TABLE_NAME FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='import_master_data_rows'");
  assert.equal(masterRowsTables.length, 1, 'Missing master data import staging table');
  const [masterRowsColumns] = await db.query("SELECT COLUMN_NAME FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='import_master_data_rows'");
  const masterRowsColumnNames = new Set(masterRowsColumns.map((row) => row.COLUMN_NAME ?? row.column_name));
  for (const column of ['batch_id','entity_type','source_code','source_identifier','source_name','source_status','source_book_name','source_active','classification','decision','validation_error_code']) {
    assert.ok(masterRowsColumnNames.has(column), `Missing master data staging column ${column}`);
  }

  const requiredTables = [
    'roles', 'permissions', 'users', 'students', 'student_enrollments',
    'import_batches', 'import_grade_rows', 'muhafadloh_execution_targets',
    'import_student_roster_rows', 'import_final_exam_rows', 'reports', 'certificates', 'audit_logs',
  ];
  const [muhafadlohImportColumns] = await db.query(
    "SELECT column_name FROM information_schema.columns WHERE table_schema=DATABASE() AND ((table_name='import_muhafadloh_rows' AND column_name IN ('m2','m3','m4','m5','m6','m7','m8')) OR (table_name='muhafadloh' AND column_name IN ('m2_import_row_id','m3_import_row_id','m4_import_row_id','m5_import_row_id','m6_import_row_id','m7_import_row_id','m8_import_row_id')))",
  );
  assert.equal(muhafadlohImportColumns.length, 14, 'Muhafadloh M2-M8 staging and provenance columns must exist');
  const [finalExamProvenance] = await db.query(
    "SELECT column_name FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='certificate_final_exam_scores' AND column_name='import_row_id'",
  );
  assert.equal(finalExamProvenance.length, 1, 'Missing final-exam import provenance column');
  const [finalExamPermission] = await db.query(
    "SELECT id FROM permissions WHERE code='certificates.import.manage'",
  );
  assert.equal(finalExamPermission.length, 1, 'Missing final-exam import permission');
  const [masterPermission] = await db.query(
    `SELECT r.code FROM permissions p
     JOIN role_permissions rp ON rp.permission_id=p.id
     JOIN roles r ON r.id=rp.role_id
     WHERE p.code='masters.import.manage'`,
  );
  assert.deepEqual(
    masterPermission.map((row) => row.code).sort(),
    ['ADMIN', 'SUPER_ADMIN'],
    'Master-data import permission must be granted only to ADMIN and SUPER_ADMIN',
  );
  const [tables] = await db.query(
    'SELECT table_name FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name IN (?)',
    [requiredTables],
  );
  const actualTables = new Set(tables.map((row) => row.TABLE_NAME ?? row.table_name));
  for (const table of requiredTables) assert.ok(actualTables.has(table), `Missing table ${table}`);

  const [[foreignKeys]] = await db.query(
    "SELECT COUNT(*) AS count FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=DATABASE() AND CONSTRAINT_TYPE='FOREIGN KEY'",
  );
  const [[uniqueIndexes]] = await db.query(
    "SELECT COUNT(*) AS count FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND NON_UNIQUE=0",
  );
  assert.ok(Number(foreignKeys.count) > 0, 'No foreign keys found');
  assert.ok(Number(uniqueIndexes.count) > 0, 'No unique indexes found');

  const [openIndexes] = await db.query(
    "SELECT DISTINCT INDEX_NAME FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='muhafadloh_execution_targets' AND NON_UNIQUE=0",
  );
  assert.ok(openIndexes.length > 0, 'Muhafadloh execution table has no unique index');

  const [[openExecutions]] = await db.query("SELECT COUNT(*) AS count FROM muhafadloh_execution_targets WHERE status='OPEN'");
  assert.equal(Number(openExecutions.count), 0, 'Test schema must start without open Muhafadloh executions');
  console.log(JSON.stringify({ migrations: Number(migration.count), tables: actualTables.size, foreignKeys: Number(foreignKeys.count), uniqueIndexes: Number(uniqueIndexes.count), openMuhafadlohExecutions: Number(openExecutions.count) }));
} finally {
  await db.end();
}