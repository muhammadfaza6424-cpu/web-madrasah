import { mkdir } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

if (process.env.DB_NAME !== 'madrasah_ci') throw new Error('Backup/restore test is restricted to madrasah_ci');
for (const key of ['DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASSWORD']) if (!process.env[key]) throw new Error(`${key} is required`);
const root = fileURLToPath(new URL('../..', import.meta.url));
const dump = path.join(root, '.local', 'backups', 'madrasah_ci.sql');
const mysqlBin = 'C:\\Program Files\\MySQL\\MySQL Server 8.4\\bin';
const env = { ...process.env, MYSQL_PWD: process.env.DB_PASSWORD };
const common = ['--host', process.env.DB_HOST, '--port', String(process.env.DB_PORT ?? 3306), '--user', process.env.DB_USER, process.env.DB_NAME];
await mkdir(path.dirname(dump), { recursive: true });
const backup = spawnSync(path.join(mysqlBin, 'mysqldump.exe'), [...common, '--single-transaction', '--routines', '--events', '--result-file', dump], { env, stdio: 'ignore' });
if (backup.status !== 0) throw new Error('Test database backup failed');
const restore = spawnSync(path.join(mysqlBin, 'mysql.exe'), common, { env, input: await (await import('node:fs/promises')).readFile(dump), stdio: ['pipe', 'ignore', 'ignore'] });
if (restore.status !== 0) throw new Error('Test database restore failed');
console.log('Backup and restore passed for madrasah_ci; dump stored under ignored .local.');
