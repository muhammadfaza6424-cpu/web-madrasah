import mysql from 'mysql2/promise';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

if (process.env.DB_NAME !== 'madrasah') throw new Error('Production permission seed is restricted to madrasah');
for (const key of ['DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASSWORD']) if (!process.env[key]) throw new Error(`${key} is required`);
const root = fileURLToPath(new URL('../..', import.meta.url));
const sql = await readFile(path.join(root, 'database', 'seeds', '001_roles_permissions.sql'), 'utf8');
const db = await mysql.createConnection({ host: process.env.DB_HOST, port: Number(process.env.DB_PORT ?? 3306), user: process.env.DB_USER, password: process.env.DB_PASSWORD, database: process.env.DB_NAME, multipleStatements: true });
try {
  await db.beginTransaction();
  await db.query(sql);
  await db.commit();
  console.log('Production role/permission seed applied to madrasah.');
} catch (error) {
  await db.rollback();
  throw error;
} finally {
  await db.end();
}
