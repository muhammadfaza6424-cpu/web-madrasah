import 'dotenv/config';
import mysql from 'mysql2/promise';

if (process.env.DB_NAME !== 'madrasah_ci') throw new Error('Test schema reset is restricted to madrasah_ci');
for (const key of ['DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASSWORD']) {
  if (!process.env[key]) throw new Error(`${key} is required`);
}

const db = await mysql.createConnection({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT ?? 3306),
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});
try {
  const [rows] = await db.query(
    "SELECT TABLE_NAME FROM information_schema.tables WHERE table_schema=DATABASE() AND TABLE_TYPE='BASE TABLE'",
  );
  await db.query('SET FOREIGN_KEY_CHECKS=0');
  for (const row of rows) {
    await db.query(`DROP TABLE IF EXISTS \`${String(row.TABLE_NAME).replaceAll('`', '``')}\``);
  }
  await db.query('SET FOREIGN_KEY_CHECKS=1');
  console.log('Test schema reset completed for madrasah_ci.');
} finally {
  await db.end();
}
