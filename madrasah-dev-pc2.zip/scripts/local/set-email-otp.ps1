param()
$ErrorActionPreference = 'Stop'
$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$envFile = Join-Path $repoRoot 'backend\.env'
if (-not (Test-Path -LiteralPath $envFile)) { throw 'Konfigurasi lokal tidak ditemukan.' }
$secret = Read-Host 'Masukkan App Password Gmail (input tidak terlihat)' -AsSecureString
$ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
try {
    $plain = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    if ([string]::IsNullOrWhiteSpace($plain)) { throw 'App Password kosong.' }
    $plain = $plain.Replace(' ', '')
    $lines = @(Get-Content -LiteralPath $envFile | Where-Object { $_ -notmatch '^SMTP_PASSWORD=' })
    $lines += 'SMTP_PASSWORD=' + $plain
    Set-Content -LiteralPath $envFile -Value $lines -Encoding utf8
    Write-Host 'Email OTP lokal tersimpan. Minta saya memulai ulang layanan sebelum mencoba kode asli.'
} finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
    $plain = $null
}
