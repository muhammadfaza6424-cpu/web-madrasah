# DESAIN ABSENSI PER SESI/JADWAL — ANALISIS READ-ONLY

- **Tanggal:** 2 Oktober 2026
- **Workspace:** `/var/www/madrasah-dev`
- **Sifat:** READ-ONLY. Tidak ada source code, migration, database, dependency, deployment, atau push yang diubah.
- **Pertanyaan:** Apakah absensi sebaiknya dikembangkan menjadi **absensi per sesi/jadwal** dengan perubahan minimal?
- **Referensi kode:** `database/migrations/001_initial_schema.sql`, `025_production_invariants.sql`; `backend/src/modules/schedules/schedule.routes.ts`, `assignments/assignment.routes.ts`, `attendance/attendance.routes.ts`, `support/operations.routes.ts`, `academic-years/academic-year.routes.ts`, `reports/report.routes.ts`, `imports/attendance-import.routes.ts`; `frontend/src/features/academic/AcademicEditor.tsx`, `AcademicPage.tsx`, `ScheduleEditor.tsx`, `app/App.tsx`.

**Kesimpulan awal:** Ya. Model saat ini (`schedules` = template mingguan berulang) sudah cukup menjadi dasar sesi tanpa membuat tabel pertemuan baru. Cara paling minimal adalah menambahkan `schedule_id` (NULL) pada `attendance` dan memakai pasangan `(schedule_id, attendance_date)` sebagai identitas sesi. Absensi harian lama tetap valid sebagai `schedule_id = NULL`.

---

## 1. Struktur `schedules` Saat Ini
- Kolom: `id`, `teaching_assignment_id` (FK), `day_of_week ENUM('SENIN'..'MINGGU')`, `starts_at TIME NULL`, `ends_at TIME NULL`, `room_name`, `active`, `created_at` (001, baris 161–172).
- **Tidak ada** kolom tanggal, `semester`, `academic_year_id`, sesi ke-N, atau status pertemuan; ini template **mingguan berulang**, bukan instance pertemuan bertanggal.
- **Tidak ada UNIQUE KEY** pada `schedules`. Pencegahan bentrok murni di aplikasi (`validate()` di `schedule.routes.ts`) untuk overlap guru/kelas pada hari+jam+semester yang sama.
- Tidak ada relasi langsung ke `attendance`, `classes`, `teachers`, atau `subjects`; semuanya lewat `teaching_assignments`.

## 2. Relasi `schedules` → `teaching_assignments` → teacher/class/subject/year/semester
- `schedules.teaching_assignment_id → teaching_assignments.id` (FK).
- `teaching_assignments`: `teacher_id`, `class_id`, `subject_id`, `academic_year_id`, `semester ENUM('GANJIL','GENAP')`, `active`; `UNIQUE(teacher_id, class_id, subject_id, academic_year_id, semester)` (001, baris 133–146).
- Jadi dari satu `schedule.id` dapat diturunkan lengkap: guru, kelas, mata pelajaran, tahun ajaran, semester — mis. query `/schedules/admin` dan `/schedules/teacher/me` sudah mem-join seluruh rantai ini.
- `homeroom_assignments` (`WALI_KELAS`/`MUSRIF`) berdiri terpisah dan hanya memuat guru+kelas+tahun; dipakai untuk scope menulis absensi kelas dan otoritas raport, bukan sebagai jadwal mapel.
- Scope absensi saat ini: GURU lolos jika punya `teaching_assignments` **ATAU** `homeroom_assignments` aktif untuk kelas+tahun (per kelas, **bukan per mapel/jadwal**).

## 3. Bagaimana Frontend Dapat Memilih Jadwal/Sesi
- Sumber data sudah tersedia tanpa endpoint baru: `GET /api/schedules/teacher/me` (GURU) dan `GET /api/schedules/admin` mengembalikan `id`, `day_of_week`, `starts_at`, `ends_at`, `class_code`, `subject_name`, `semester`, `academic_year`.
- Alur usulan (minimal): user pilih **tanggal** → frontend hitung `day_of_week` dari tanggal → filter jadwal hari itu → user pilih **sesi** (`schedule.id`) → muat daftar santri + status untuk `(scheduleId, date)`.
- UI absensi saat ini (`AcademicEditor.tsx`) hanya punya **Tahun + Kelas + Tanggal**; perlu tambahan dropdown **Sesi/Jadwal** (opsional; jika kosong → mode harian lama).
- `ScheduleEditor.tsx` (Admin) tidak perlu diubah untuk fitur sesi; ia tetap mengelola template mingguan.

## 4. Perubahan Minimal Database `attendance`
- Tambah kolom **`schedule_id BIGINT UNSIGNED NULL`** + FK ke `schedules(id)` (NULL = absensi harian/legacy).
- Tambah kolom generated **`schedule_key BIGINT UNSIGNED AS (COALESCE(schedule_id,0)) STORED`** agar NULL dapat diikutkan dalam keunikan (pola sama dengan `active_slot` di migrasi 025).
- Ganti `UNIQUE KEY uq_attendance_student_date (student_id, attendance_date)` menjadi `UNIQUE (student_id, attendance_date, schedule_key)`.
- Tidak perlu mengubah kolom `class_id`/`academic_year_id`; keduanya tetap diisi dari `student_enrollments` dan konsisten dengan `teaching_assignment` sesi.
- Tidak perlu tabel `schedule_sessions` baru untuk kebutuhan minimal; pasangan `(schedule_id, attendance_date)` sudah mengidentifikasi satu pertemuan konkret.

## 5. Perubahan Minimal Backend API/Service
- `PUT /api/attendance` (`attendance.routes.ts`): tambah `scheduleId: z.number().int().positive().optional().nullable()` pada schema `write`; bila ada, validasi `schedule` aktif → `teaching_assignment` cocok `class_id`, `academic_year_id`, `semester` dengan enrollment; untuk GURU **perketat** menjadi `ta.teacher_id = auth.teacherId`; lalu upsert menyertakan `schedule_id` (`schedule_key` otomatis).
- `GET /api/attendance/class/:classId`: terima query opsional `scheduleId`; bila ada, filter join pada `a.schedule_id` (dan validasi scope jadwal guru), bukan hanya kelas.
- Tambahkan (opsional) `GET /api/attendance/schedule/:scheduleId?date=` yang mengembalikan daftar santri kelas dari `student_enrollments` + status sesi; dapat diwujudkan sebagai reuse query kelas yang sudah ada.
- Validasi periode: gunakan `academic_terms` untuk semester `teaching_assignment`, tidak hanya `academic_years.starts_on/ends_on` (konsisten dengan `report.routes.ts`).
- Tidak perlu service baru; tetap pola route-only seperti sekarang.

## 6. Perubahan Minimal Frontend
- `AcademicEditor.tsx`: saat `page==='Absensi'`, tambah dropdown **Sesi** (dari `/schedules/teacher/me` atau `/schedules/admin`, difilter `day_of_week` tanggal); kirim `scheduleId` pada GET dan pada body `PUT`; pertahankan opsi "Tanpa sesi (harian)" untuk kompatibilitas.
- `AcademicPage.tsx` (read-only) dapat menampilkan kolom sesi/jam bila ada; sifatnya opsional.
- `App.tsx` tidak perlu perubahan navigasi; halaman "Absensi" sudah tersedia untuk semua role yang relevan.
- Tidak ada perubahan pada `ScheduleEditor.tsx`.

## 7. Cara Migrasi Data Attendance Lama Tanpa Kehilangan Data
- Semua baris `attendance` lama otomatis menjadi `schedule_id = NULL`, `schedule_key = 0`; tetap valid dan tetap unik per `(student_id, attendance_date, 0)`.
- Tidak ada backfill paksa dari `NULL` ke sesi tertentu, karena pemetaan tanggal→sesi tidak dapat dipastikan tanpa data jam/sesi historis (sesuai prinsip "jangan mengarang data").
- Bila kelak ingin memetakan, lakukan sebagai operasi terpisah dan terekam audit; bukan bagian migration minimal.
- Kolom baru harus `NULL`-able dan default kompatibel agar aplikasi versi lama tetap dapat menulis (menghasilkan `schedule_key=0`).

## 8. Constraint UNIQUE yang Seharusnya Digunakan
- **Utama:** `UNIQUE (student_id, attendance_date, schedule_key)` dengan `schedule_key = COALESCE(schedule_id,0)`.
  - Mencegah duplikat harian lama (`schedule_key=0`) **dan** duplikat per sesi.
  - Menghindari jebakan MySQL: `UNIQUE(student_id, date, schedule_id)` biasa akan mengizinkan duplikat karena `NULL` dianggap berbeda.
- **Disarankan tambahan (opsional):** `UNIQUE (teaching_assignment_id, day_of_week, starts_at)` pada `schedules` untuk mencegah template jadwal ganda; saat ini tidak ada.
- **Pertahankan:** `UNIQUE (student_id, academic_year_id)` pada `student_enrollments`, dan `UNIQUE` pada `teaching_assignments` — keduanya sudah benar.

## 9. Risiko Kompatibilitas dengan Raport / Rekap / Import Excel
- **Rekap/raport (`report.routes.ts`):** query `SUM(status=...)` + `COUNT(*) recorded_days` akan **menghitung sesi, bukan hari**. Dengan sesi ganda per hari, angka "Hari tercatat" membengkak. Perlu keputusan: hitung `COUNT(DISTINCT attendance_date)`, atau definisikan rekap per sesi. Ini risiko paling nyata.
- **Import Excel (`attendance-import.routes.ts`):** saat ini membuat satu baris `(student, date)` dan menolak duplikat dalam batch. Bila dibiarkan `schedule_id=NULL`, tetap kompatibel sebagai absensi harian; sedangkan baris sesi baru hidup berdampingan (`schedule_key` berbeda). Import tidak boleh dipaksa memetakan jadwal pada fase minimal.
- **Upsert/dedup:** `INSERT ... ON DUPLICATE KEY UPDATE` saat ini bergantung pada `(student, date)`; setelah constraint berubah, wajib menyertakan `schedule_id` agar tidak salah menimpa baris harian lama.
- **Kebijakan konflik:** aturan `MANUAL_ATTENDANCE_EXISTS` (import tidak menimpa MANUAL) dan arah sebaliknya (manual menimpa IMPORT_EXCEL) perlu ditinjau agar tidak ada kesan data hilang saat sesi ditambahkan.
- **Scope guru:** memperketat ke `schedule.teacher_id = auth.teacherId` saat sesi dipilih dapat memblokir guru yang sebelumnya boleh menulis karena wali kelas; perlu aturan eksplisit (mis. wali kelas hanya untuk mode harian).

## 10. Rekomendasi Desain Berdasarkan Kode yang BENAR-BENAR ADA
- **Pilih opsi sesi-ringan (A):** jadikan `schedules` sebagai definisi sesi; identitas sesi = `(schedule_id, attendance_date)`; simpan pada `attendance.schedule_id`. Tidak membuat tabel `schedule_sessions` pada fase minimal.
- **Constraint:** `UNIQUE(student_id, attendance_date, schedule_key)` dengan kolom generated `COALESCE(schedule_id,0)` (pola sudah terbukti di migrasi 025).
- **Backward compatible:** `schedule_id` NULL = mode harian; semua data lama aman, `AcademicEditor` menyediakan opsi "tanpa sesi".
- **Scope & otorisasi:** pertahankan model role+permission; saat `schedule_id` diisi, gunakan `teaching_assignment.teacher_id` sebagai batas ketat, dan `homeroom_assignments` untuk mode harian/kelas.
- **Periode:** validasi tanggal sesi terhadap `academic_terms` semester terkait (bukan `academic_years` nullable), menyamakan sumber kebenaran dengan raport.
- **Rekap:** tetapkan lebih dulu semantik (per hari vs per sesi) sebelum implementasi; ini keputusan produk yang menentukan perubahan query raport.
- **Urutan implementasi minimal yang aman:** (1) kolom + constraint baru, (2) perluas `PUT`/`GET` absensi dengan `scheduleId`, (3) tambah dropdown sesi di frontend, (4) baru sesuaikan rekap/raport dan kebijakan import. Semua menunggu persetujuan; audit ini tidak mengubah apa pun.
