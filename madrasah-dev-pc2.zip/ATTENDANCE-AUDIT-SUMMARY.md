# RINGKASAN AUDIT ABSENSI — MADRASAH DINIYAH

- **Tanggal:** 2 Oktober 2026
- **Workspace:** `/var/www/madrasah-dev`
- **Status:** AUDIT ONLY — tanpa perubahan source code, migration, dependency, database write, deployment, atau push GitHub.
- **Sumber:** `ATTENDANCE-AUDIT.md`

---

## 1. Kondisi Absensi Saat Ini
- Satu baris absensi = **(santri, tanggal)** dengan status `H/S/I/A`; tidak ada dimensi sesi/jadwal/mata pelajaran.
- Dua jalur input: manual per baris (`PUT /api/attendance`, `source='MANUAL'`) dan import Excel bertahap (*stage → review → approve → apply*, `source='IMPORT_EXCEL'`).
- Rekap dihitung *on-the-fly* via `SUM(status=...)`; snapshot raport memakai rentang `academic_terms`.

## 2. Fitur yang Sudah Ada
- Input manual H/S/I/A per kelas/tanggal, daftar absensi per kelas, dan absensi per siswa (`/attendance/student/me`) + rekap.
- Otorisasi role + permission dan scope guru (teaching/homeroom), upsert transaksional, serta penguncian kalender (`locks_attendance`).
- Import Excel dengan template, review NIS, replay protection, larangan menimpa data manual, dan audit trail menyeluruh (`audit_logs`).

## 3. Fitur yang Belum Ada
- Dimensi **sesi/pertemuan/jam pelajaran** pada data maupun UI; keunikan hanya `(student_id, attendance_date)`.
- **Simpan massal** per kelas dalam satu aksi; saat ini satu request per siswa.
- Tabel **rekap resmi tersimpan**, UI audit khusus absensi, pembatasan koreksi historis, dan test integrasi end-to-end.

## 4. Role dan Permission
- `SUPER_ADMIN` = semua permission; `ADMIN` termasuk `attendance.manage` & `attendance.import.manage`.
- `GURU` = `attendance.manage` + `teaching.scope.read` (raport hanya wali kelas); `SANTRI` = `own.academic.read`.
- `requirePermission` hanya memeriksa permission (bukan role); backend tetap otoritatif, UI hanya menyembunyikan menu.

## 5. Struktur Database Terkait Absensi
- `attendance(student_id, class_id, academic_year_id, attendance_date, status, source, recorded_by, import_row_id)` dengan `UNIQUE(student_id, attendance_date)`.
- `student_enrollments(student_id, academic_year_id, class_id, status)` dengan `UNIQUE(student_id, academic_year_id)`.
- Pendukung: `calendar_events.locks_attendance`, `academic_terms`, `import_batches` + `import_attendance_rows`, `audit_logs`.

## 6. Relasi Guru–Kelas–Santri
- `teachers` ↔ `teacher_user_links` ↔ `users`; `students` ↔ `student_user_links` ↔ `users`.
- `teaching_assignments(teacher, class, subject, year, semester)` dan `homeroom_assignments(teacher, class, year, type)` menjadi dasar scope guru.
- Kelas santri melalui `student_enrollments`; `schedules` hanya menempel ke `teaching_assignments` (tidak ke `attendance`).

## 7. Gap terhadap Workflow Absensi Guru yang Diinginkan
- Target menyebut pemilihan **tanggal/sesi** dan **date/session uniqueness**, sedangkan model & UI belum memiliki sesi.
- Guru belum memilih **penugasan/mata pelajaran** saat absensi; scope hanya per kelas.
- Belum ada **simpan massal** maupun prefill berbasis jadwal aktif; validasi input manual memakai `academic_years`, bukan `academic_terms`.

## 8. Perubahan Minimal yang Diperlukan
- Putuskan model: **harian per kelas** (pertahankan schema, dokumentasikan) atau **per sesi** (tambah `schedule_id` + ubah keunikan).
- Tambah endpoint `PUT /api/attendance/bulk` untuk satu kelas+tanggal, dan satukan periode absensi ke `academic_terms`.
- Terapkan kebijakan konflik `MANUAL` vs `IMPORT_EXCEL` secara simetris serta audit eksplisit `ATTENDANCE.CORRECTED`.

## 9. Risiko Utama
- `UNIQUE(student_id, attendance_date)` dapat **menimpa** absensi sesi/mapel berbeda pada hari yang sama.
- **Dua sumber periode** (`academic_years` nullable vs `academic_terms`) berisiko tidak konsisten; lock global `FOR UPDATE` pada baris role menimbulkan bottleneck.
- Tidak ada batas koreksi historis, dan `locks_attendance` tidak diterapkan pada jalur `apply` import.
