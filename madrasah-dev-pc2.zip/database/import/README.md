# Kebijakan Import Data Resmi

Folder ini untuk script/staging import, bukan untuk menyimpan kredensial atau dump production.

## Master-data import authorization

Migration 033 is retained unchanged because it is part of the applied migration checksum history. It creates the master-data staging schema and grants `masters.import.manage` to `SUPER_ADMIN`; its permission cleanup is limited to that permission. Migrations 037 and 038 are additive forward migrations: 037 ensures the permission and Super Admin grant, while 038 adds the approved Admin grant without removing grants from other roles.

The master-data import router requires both `masters.import.manage` and either the `SUPER_ADMIN` or `ADMIN` role on every endpoint. `GURU` and `SANTRI` remain denied even if a permission grant exists. No technical Super Admin-only capability is granted to Admin by this import permission.

## Prioritas sumber

1. Word: master santri AKTIF dan NIS resmi. NIS Excel tidak boleh menimpa NIS Word.
2. Excel Absensi: histori absensi. Baris santri boyong boleh dipertahankan bila identitas dapat dipastikan, tetapi keberadaan di Excel bukan bukti status aktif.
3. Data Muhafadloh: data aktual. Nilai M1-M8 hanya diimpor jika nilai resmi untuk bulan tersebut tersedia; bulan yang belum dilaksanakan tetap NULL.
4. Data Nilai resmi: sumber nilai akademik.
5. Contoh Raport dan Ijazah: sumber format dokumen, bukan sumber untuk membuat nilai/data palsu.

## Rekonsiliasi identitas

Semua data operasional akhirnya harus menunjuk ke `students.id`. NIS adalah business identifier resmi dan unik, tetapi bukan foreign key histori. Jika kecocokan sumber ambigu, baris harus masuk staging/review dan tidak boleh ditebak otomatis.

## Status santri

- ACTIVE berasal dari master aktif Word.
- BOYONG dapat ditetapkan untuk histori lama bila identitas dan statusnya dapat diverifikasi.
- GRADUATED ditetapkan melalui proses kelulusan resmi, bukan karena kelas 6 saja.

## Larangan

- Jangan import `mockData.ts`.
- Jangan membuat nilai, absensi, Muhafadloh, Raport atau Ijazah demo.
- Jangan membuat M2-M8 sebelum pelaksanaannya.
- Jangan membuat fitur hafalan Al-Qur'an 2 juz.
- Jangan menyimpan password plaintext pada seed/import.

## Template import absensi XLSX

Import absensi menerima satu worksheet dengan kolom `NIS`, `Nama`, `Kelas`, `Tanggal`, dan `Status`. NIS harus berupa teks agar nol di depan terjaga; status dibatasi ke kode database `H`, `S`, `I`, atau `A`; tanggal harus berupa sel tanggal Excel tanpa waktu atau teks ISO `YYYY-MM-DD`.

Upload hanya membuat batch staging. Pencocokan otomatis menggunakan NIS resmi yang sama persis; nama dan kelas tidak digunakan untuk menyimpulkan identitas. Baris tanpa pasangan tetap belum cocok sampai operator meninjau NIS secara eksplisit. Batch harus disetujui dan diterapkan terpisah; validasi ulang enrollment historis serta transaksi apply mencegah absensi manual ditimpa.

## Template import nilai XLSX

Import nilai menerima satu worksheet dengan kolom `NIS`, `Nama`, `Kelas`, `Mata_Pelajaran`, `Semester`, `Nilai`, dan `Catatan`. NIS harus berupa teks; semester harus ditulis eksplisit sebagai `GANJIL` atau `GENAP` pada setiap baris, dan nilai dibatasi 0-100 dengan maksimal dua angka desimal. Tahun ajaran dipilih operator saat staging dan disimpan pada batch.

Upload hanya membuat batch staging. Pencocokan otomatis menggunakan NIS santri dan kode/nama mapel yang sama persis; kandidat yang tidak cocok harus dipilih dan setiap override identitas memerlukan catatan. Batch hanya dapat disetujui jika seluruh baris selesai ditinjau tanpa duplikasi santri-mapel-semester. Apply memeriksa ulang enrollment, kelas, penugasan mapel untuk semester eksplisit, dan nilai manual yang sudah ada dalam transaksi; semester atau penugasan yang belum ditetapkan tidak disimpulkan otomatis.

## Template import Muhafadloh XLSX

Import menerima satu worksheet dengan kolom `NIS`, `Nama`, `Kelas`, dan `M1` sampai `M8`. NIS harus disimpan sebagai teks, setiap baris harus memiliki sedikitnya satu nilai, dan nilai yang terisi dibatasi 0-100 dengan maksimal dua angka desimal. Sel nilai yang kosong berarti tidak ada nilai sumber untuk bulan tersebut dan tidak menghapus nilai resmi.

Upload hanya membuat staging batch. Pencocokan otomatis terbatas pada NIS resmi exact; pemilihan tahun ajaran dan rekonsiliasi baris dilakukan operator. Apply transaksional menolak konflik pada setiap kolom M yang telah berisi nilai, termasuk nilai dari import sebelumnya, serta mencatat provenance per nilai; konflik membatalkan seluruh batch tanpa overwrite.

## Template import Nilai Ujian Akhir / Ijazah

Import menerima satu worksheet XLSX dengan kolom `NIS`, `Nama`, `Kelas`, `Kode_Mapel`, dan `Nilai`. NIS wajib berupa teks, kode mapel wajib salah satu dari tepat tujuh kode `TASAWWUF`, `FIQIH`, `TAUHID`, `ASWAJA`, `BACA_KITAB`, `BACA_AL_QURAN`, atau `MUHAFADLOH`, dan nilai dibatasi 0-100 dengan maksimal dua angka desimal. Tahun ajaran dipilih operator secara eksplisit saat staging.

Upload hanya membuat batch staging. Pencocokan otomatis memakai NIS resmi yang sama persis. Setiap baris ditinjau terhadap enrollment kelas akhir; pilihan identitas yang berbeda dari NIS sumber wajib disertai catatan. Approval memvalidasi ulang enrollment, kode mapel, dan duplikasi santri-mapel. Apply bersifat transaksional, menyimpan provenance per nilai dan menolak overwrite nilai yang sudah ada. Import tidak menentukan kelulusan, metadata resmi ijazah, atau menerbitkan ijazah. Nilai dan metadata yang belum tersedia harus tetap menunggu input/review manusia.

## Readiness Raport

Raport membaca nilai per mata pelajaran/kitab dari `grades` yang terhubung ke teaching assignment aktif untuk kelas, tahun ajaran, dan semester yang dipilih. Semua assignment tersebut harus memiliki nilai sebelum publikasi; nilai dari kelas lain tidak mengisi assignment saat ini. Jumlah dan rata-rata dihitung dari nilai dalam snapshot yang diterbitkan.

Publikasi juga mensyaratkan assessment yang berisi Pengajian Sore, Kelakuan, Kerajinan, dan Kerapian; periode semester pada `academic_terms` serta sedikitnya satu hari absensi tercatat; dan snapshot tanda tangan Kepala Madrasah serta tepat satu Wali Kelas aktif. `Catatan` dan `Keputusan` nullable pada schema dan bukan syarat publikasi yang ditetapkan saat ini.

Nilai Muhafadloh M1-M8 dan targetnya ditampilkan hanya dari data yang ada; nilai kosong tidak dibuat. Belum ada aturan resmi yang menyatakan apakah target berstatus `CLOSED` tanpa nilai harus menggagalkan publikasi. Kasus tersebut ditandai `HUMAN_INPUT_REQUIRED`; jangan menganggap semua M1-M8 wajib terisi atau menerka apakah pelaksanaan terjadi. Semester Raport harus dipilih eksplisit dan tidak disimpulkan dari tahun ajaran.
