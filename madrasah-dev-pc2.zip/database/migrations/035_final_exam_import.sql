ALTER TABLE import_batches
  MODIFY source_type ENUM(
    'WORD_STUDENT_MASTER',
    'EXCEL_ATTENDANCE',
    'MUHAFADLOH',
    'GRADES',
    'EXCEL_STUDENT_ROSTER',
    'EXCEL_MASTER_TEACHERS',
    'EXCEL_MASTER_SUBJECTS',
    'EXCEL_FINAL_EXAM'
  ) NOT NULL;

CREATE TABLE import_final_exam_rows (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  batch_id BIGINT UNSIGNED NOT NULL,
  source_row_number INT UNSIGNED NOT NULL,
  source_nis VARCHAR(100) NOT NULL,
  source_name VARCHAR(255) NULL,
  source_class VARCHAR(50) NULL,
  subject_code ENUM('TASAWWUF','FIQIH','TAUHID','ASWAJA','BACA_KITAB','BACA_AL_QURAN','MUHAFADLOH') NOT NULL,
  score DECIMAL(5,2) NOT NULL,
  matched_student_id BIGINT UNSIGNED NULL,
  match_status ENUM('UNMATCHED','EXACT_OFFICIAL_NIS','AMBIGUOUS','APPROVED') NOT NULL DEFAULT 'UNMATCHED',
  review_note VARCHAR(500) NULL,
  UNIQUE KEY uq_import_final_exam_row(batch_id,source_row_number),
  KEY idx_import_final_exam_match(batch_id,matched_student_id),
  CONSTRAINT fk_import_final_exam_batch FOREIGN KEY(batch_id) REFERENCES import_batches(id) ON DELETE CASCADE,
  CONSTRAINT fk_import_final_exam_student FOREIGN KEY(matched_student_id) REFERENCES students(id),
  CONSTRAINT chk_import_final_exam_score CHECK(score BETWEEN 0 AND 100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
