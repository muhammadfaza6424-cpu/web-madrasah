-- Additional fields printed on the student profile page of the report.
-- Nullable so historical students and existing published reports remain valid.
ALTER TABLE students
  ADD COLUMN gender ENUM('L','P') NULL,
  ADD COLUMN address TEXT NULL,
  ADD COLUMN parent_name VARCHAR(150) NULL,
  ADD COLUMN parent_occupation VARCHAR(150) NULL,
  ADD COLUMN admitted_class VARCHAR(100) NULL;
