-- 039: Attendance per session (schedule_id) with backward-compatible daily mode.
-- Adds a nullable schedule_id; legacy rows and Excel imports keep schedule_id = NULL.
-- schedule_key = COALESCE(schedule_id, 0) lets the UNIQUE constraint validate NULLs
-- (MySQL treats NULLs as distinct in a plain UNIQUE index).
-- This migration does NOT backfill historical data.
ALTER TABLE attendance
  ADD COLUMN schedule_id BIGINT UNSIGNED NULL AFTER class_id,
  ADD COLUMN schedule_key BIGINT UNSIGNED GENERATED ALWAYS AS (COALESCE(schedule_id, 0)) STORED AFTER schedule_id,
  ADD CONSTRAINT fk_attendance_schedule FOREIGN KEY (schedule_id) REFERENCES schedules(id),
  DROP INDEX uq_attendance_student_date,
  ADD UNIQUE KEY uq_attendance_student_date_schedule (student_id, attendance_date, schedule_key),
  ADD INDEX idx_attendance_schedule_date (schedule_id, attendance_date);
