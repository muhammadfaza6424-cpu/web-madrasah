ALTER TABLE import_student_rows
  ADD COLUMN source_status ENUM('AKTIF','BOYONG') NULL AFTER source_class;
