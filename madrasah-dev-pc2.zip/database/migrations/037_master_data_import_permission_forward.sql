-- Production-safe forward grant for the existing SUPER_ADMIN-only master import policy.
-- Deliberately does not delete or otherwise change permissions for any other role.
INSERT INTO permissions(code,description) VALUES
  ('masters.import.manage','Kelola rekonsiliasi sumber master guru dan mata pelajaran resmi')
ON DUPLICATE KEY UPDATE description=VALUES(description);

INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.code='SUPER_ADMIN' AND p.code='masters.import.manage';
