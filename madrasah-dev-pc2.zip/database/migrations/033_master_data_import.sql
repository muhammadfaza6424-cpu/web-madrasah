-- Staged, explicit-decision import support for master teachers and subjects.
-- Apply only to development/test schemas for this milestone; no source dataset is included.
ALTER TABLE import_batches
  MODIFY source_type ENUM(
    'WORD_STUDENT_MASTER',
    'EXCEL_ATTENDANCE',
    'MUHAFADLOH',
    'GRADES',
    'EXCEL_STUDENT_ROSTER',
    'EXCEL_MASTER_TEACHERS',
    'EXCEL_MASTER_SUBJECTS'
  ) NOT NULL;

CREATE TABLE import_master_data_rows (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  batch_id BIGINT UNSIGNED NOT NULL,
  source_row_number INT UNSIGNED NOT NULL,
  entity_type ENUM('TEACHER','SUBJECT') NOT NULL,
  source_code VARCHAR(50) NULL,
  source_identifier VARCHAR(100) NULL,
  source_name VARCHAR(150) NULL,
  source_status ENUM('ACTIVE','INACTIVE') NULL,
  source_book_name VARCHAR(255) NULL,
  source_active BOOLEAN NULL,
  matched_target_id BIGINT UNSIGNED NULL,
  classification ENUM('NEW','UNCHANGED','CONFLICT','AMBIGUOUS','INVALID') NOT NULL,
  decision ENUM('CREATE_NEW','KEEP_OFFICIAL','REVIEW') NOT NULL DEFAULT 'REVIEW',
  resolved_by BIGINT UNSIGNED NULL,
  resolved_at DATETIME NULL,
  validation_error_code VARCHAR(150) NULL,
  review_note VARCHAR(1000) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_import_master_data_row(batch_id,source_row_number),
  KEY idx_import_master_data_match(batch_id,entity_type,matched_target_id),
  CONSTRAINT fk_import_master_data_batch FOREIGN KEY(batch_id) REFERENCES import_batches(id) ON DELETE CASCADE,
  CONSTRAINT fk_import_master_data_resolver FOREIGN KEY(resolved_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO permissions(code,description) VALUES
  ('masters.import.manage','Kelola rekonsiliasi sumber master guru dan mata pelajaran resmi')
ON DUPLICATE KEY UPDATE description=VALUES(description);

INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.code='SUPER_ADMIN' AND p.code='masters.import.manage';

DELETE rp FROM role_permissions rp
JOIN roles r ON r.id=rp.role_id
JOIN permissions p ON p.id=rp.permission_id
WHERE r.code<>'SUPER_ADMIN' AND p.code='masters.import.manage';
