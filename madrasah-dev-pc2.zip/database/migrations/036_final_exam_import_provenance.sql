ALTER TABLE certificate_final_exam_scores
  ADD COLUMN import_row_id BIGINT UNSIGNED NULL AFTER updated_by,
  ADD CONSTRAINT fk_certificate_final_exam_import_row
    FOREIGN KEY (import_row_id) REFERENCES import_final_exam_rows(id),
  ADD UNIQUE KEY uq_certificate_final_exam_import_row (import_row_id);

INSERT INTO permissions(code, description)
VALUES ('certificates.import.manage', 'Kelola staging dan rekonsiliasi import nilai ujian akhir')
ON DUPLICATE KEY UPDATE description=VALUES(description);

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code='SUPER_ADMIN' AND p.code='certificates.import.manage';
