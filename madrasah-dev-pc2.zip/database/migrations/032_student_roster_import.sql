ALTER TABLE import_batches
  MODIFY source_type ENUM('WORD_STUDENT_MASTER','EXCEL_ATTENDANCE','MUHAFADLOH','GRADES','EXCEL_STUDENT_ROSTER') NOT NULL;

CREATE TABLE import_student_roster_rows (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  batch_id BIGINT UNSIGNED NOT NULL,
  source_row_number INT UNSIGNED NOT NULL,
  source_nis VARCHAR(100) NULL,
  source_name VARCHAR(255) NULL,
  source_class VARCHAR(50) NULL,
  source_status ENUM('AKTIF','BOYONG') NULL,
  source_class_id BIGINT UNSIGNED NULL,
  matched_student_id BIGINT UNSIGNED NULL,
  classification ENUM('NEW_STUDENT','UNCHANGED','CLASS_CHANGE','HISTORICAL','CONFLICT','AMBIGUOUS','INVALID') NOT NULL,
  decision ENUM('CREATE_NEW','REUSE_EXISTING','KEEP_HISTORICAL','MARK_BOYONG','REVIEW') NOT NULL DEFAULT 'REVIEW',
  resolved_by BIGINT UNSIGNED NULL,
  resolved_at DATETIME NULL,
  validation_error_code VARCHAR(100) NULL,
  review_note VARCHAR(500) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_import_student_roster_row(batch_id,source_row_number),
  KEY idx_import_student_roster_match(batch_id,matched_student_id),
  CONSTRAINT fk_import_student_roster_batch FOREIGN KEY(batch_id) REFERENCES import_batches(id) ON DELETE CASCADE,
  CONSTRAINT fk_import_student_roster_class FOREIGN KEY(source_class_id) REFERENCES classes(id),
  CONSTRAINT fk_import_student_roster_student FOREIGN KEY(matched_student_id) REFERENCES students(id),
  CONSTRAINT fk_import_student_roster_resolver FOREIGN KEY(resolved_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
