-- Explicitly approved master-data import policy: SUPER_ADMIN and ADMIN only.
-- Preserve any existing grants; the route additionally enforces the allowed roles.
INSERT INTO permissions(code,description) VALUES
  ('masters.import.manage','Kelola rekonsiliasi sumber master guru dan mata pelajaran resmi')
ON DUPLICATE KEY UPDATE description=VALUES(description);

INSERT IGNORE INTO role_permissions(role_id,permission_id)
SELECT r.id,p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.code IN('SUPER_ADMIN','ADMIN') AND p.code='masters.import.manage';
