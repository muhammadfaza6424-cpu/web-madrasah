# AI WORKSPACE RULES — MADRASAH DINIYAH

## Workspace
This directory is an isolated DEVELOPMENT workspace.

- Work ONLY inside `/var/www/madrasah-dev`.
- NEVER modify `/var/www/madrasah`.
- NEVER deploy directly to production.
- NEVER modify SSL certificates, DNS, Cloudflare, or private keys.
- NEVER expose, print, copy, or request production secrets.
- NEVER read `/var/www/madrasah/.env.production.local`.

## Git safety
- NEVER push to GitHub.
- NEVER merge into `main`.
- Do not create or modify `main`.
- Do not publish or deploy anything.
- Before changing code, inspect the current branch and repository state.

## Project rules
This is a production-oriented Madrasah Diniyah application.
Do not rebuild the application from scratch.
Do not replace existing architecture without evidence.
Do not invent official data.
Do not introduce mock data, localStorage-based persistence, or demo-only behavior.

## Current task: Attendance
The desired attendance workflow is:

SUPER_ADMIN:
- manage users, academic year, classes, teachers

ADMIN:
- manage academic data
- view all attendance
- perform authorized corrections

GURU:
- see assigned classes/schedules
- select date/session
- mark students:
  - Hadir
  - Sakit
  - Izin
  - Alpa
- save attendance

System:
- persist attendance in MySQL
- automatically generate recaps
- enforce teacher/class authorization
- prevent a teacher from modifying another teacher's class
- enforce appropriate date/session uniqueness
- maintain auditability

Bulk attendance upload may remain as an optional import mechanism, but it must not be the primary daily workflow.

## REQUIRED FIRST PHASE
Do NOT immediately modify code.

First perform an AUDIT ONLY of the existing attendance implementation:
1. Frontend attendance pages/components.
2. Backend attendance routes/controllers/services.
3. Authentication and role/permission checks.
4. Database attendance tables and migrations.
5. Student/class/teacher relationships.
6. Existing teacher-class assignment mechanisms.
7. Existing attendance upload/import functionality.
8. Existing audit logging.
9. Existing tests.
10. Identify exactly what already exists and what is missing.

Then report:
- files inspected
- current architecture
- existing attendance flow
- authorization flow
- database relationships
- gaps against the desired workflow
- proposed minimal changes

Do NOT edit source code during the audit phase.
Do NOT install unnecessary dependencies.
Do NOT create migrations during the audit.
Do NOT delete existing functionality.

Wait for explicit approval before implementing changes.
