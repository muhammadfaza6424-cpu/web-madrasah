# ATTENDANCE STAGE 1 REPORT — DATABASE + BACKEND

- **Tanggal:** 2 Oktober 2026
- **Workspace:** `/var/www/madrasah-dev`
- **Lingkup Tahap 1:** Database + Backend saja (TANPA frontend).
- **Status:** SELESAI. Typecheck lulus, 57/57 test backend lulus.

---

## 1. File yang Diubah / Dibuat

### Dibuat
- `database/migrations/039_attendance_schedule_session.sql` — migration (belum dijalankan).
- `backend/src/modules/attendance/attendance-priority.ts` — sumber tunggal aturan prioritas A > I > S > H.
- `backend/src/modules/attendance/attendance-session.ts` — helper murni validasi sesi (ownership/class/semester).
- `backend/src/modules/attendance/attendance-recap.test.ts` — test rekap harian.
- `backend/src/modules/attendance/attendance-session.test.ts` — test validasi sesi + statik migration/import.

### Diubah
- `backend/src/modules/attendance/attendance.routes.ts` — dukungan `scheduleId`, endpoint bulk, rekap harian, rekap sesi.
- `backend/src/modules/reports/report.routes.ts` — rekap snapshot jadi semantik harian; `version` 8 → 9.
- `backend/src/modules/imports/attendance-import.routes.ts` — cek konflik hanya baris harian (`schedule_id IS NULL`).
- `package-lock.json` / `node_modules` — **tidak ada dependency baru**; hanya menjalankan `npm install` untuk memasang dependency yang sudah dideklarasikan (typescript, tsx) karena `node_modules` belum ada dan Rule 15 mewajibkan typecheck/test.

### Tidak disentuh
- Seluruh `frontend/**` (tidak ada file berubah).
- Tidak ada source production, nginx, SSL, DNS, Cloudflare, pm2, atau secrets.

---

## 2. Migration yang Dibuat

**File:** `database/migrations/039_attendance_schedule_session.sql` (nomor 039 benar; 038 adalah migration terakhir; 039 belum ada sebelumnya).

```sql
ALTER TABLE attendance
  ADD COLUMN schedule_id BIGINT UNSIGNED NULL AFTER class_id,
  ADD COLUMN schedule_key BIGINT UNSIGNED GENERATED ALWAYS AS (COALESCE(schedule_id, 0)) STORED AFTER schedule_id,
  ADD CONSTRAINT fk_attendance_schedule FOREIGN KEY (schedule_id) REFERENCES schedules(id),
  DROP INDEX uq_attendance_student_date,
  ADD UNIQUE KEY uq_attendance_student_date_schedule (student_id, attendance_date, schedule_key),
  ADD INDEX idx_attendance_schedule_date (schedule_id, attendance_date);
```

- Tidak ada backfill (`UPDATE attendance` tidak ada).
- Data lama tetap `schedule_id = NULL` → `schedule_key = 0`.
- **Migration belum dijalankan.**

---

## 3. Endpoint yang Ditambah/Diubah

| Endpoint | Perubahan |
|---|---|
| `PUT /api/attendance` | + `scheduleId` opsional (nullable). Tanpa `scheduleId` = perilaku lama (`schedule_id=NULL`). Dengan `scheduleId` = validasi sesi + ownership + semester + enrollment kelas sesi. |
| `PUT /api/attendance/bulk` | **Baru.** Body `{classId, attendanceDate, scheduleId, entries:[{studentId,status}]}`. Satu transaksi, all-or-nothing. |
| `GET /api/attendance/class/:classId` | + query opsional `scheduleId`. Tanpa `scheduleId` → hanya baris `schedule_id IS NULL` (legacy, tidak terduplikasi). |
| `GET /api/attendance/student/me` | Rekap harian `COUNT(DISTINCT attendance_date)` + prioritas; + `sessionRecap` terpisah (berlabel sesi). |
| Report snapshot (`report.routes.ts`) | Rekap harian prioritas A>I>S>H; `version` 9. |

Audit:
- Single write → `ATTENDANCE.UPDATED` (metadata `changes`).
- Bulk → `ATTENDANCE.BULK_UPDATED` (satu operasi, metadata ringkasan + entries).
- Gunakan `writeAudit` existing; `mutationAudit` global tetap berlaku.
- Perubahan ADMIN/SUPER_ADMIN tercatat `before/after` lewat `changes`.

---

## 4. Validasi Security / Teacher Ownership

- Schedule diambil melalui `schedules JOIN teaching_assignments`; harus `schedule.active` dan `ta.active` (else `INVALID_SCHEDULE`).
- **GURU:** `teaching_assignments.teacher_id === req.auth.teacherId` (else `403 OUTSIDE_TEACHER_SCOPE`). Dibaca dengan `FOR UPDATE` di dalam transaksi (anti-TOCTOU).
- **ADMIN/SUPER_ADMIN:** boleh koreksi lintas kelas/sesi.
- `schedule.class_id === classId` (else `SCHEDULE_CLASS_MISMATCH`).
- Semua `studentId` bulk harus terdaftar di `student_enrollments` kelas+thn ajaran sesi (else `STUDENT_NOT_IN_SCHEDULE_CLASS`).
- Tanggal harus dalam periode `academic_terms` semester sesi bila terkonfigurasi (else `SEMESTER_PERIOD_MISMATCH`).
- `calendar_events.locks_attendance` dihormati pada mode sesi dan harian (`409 ATTENDANCE_LOCKED`).
- `status` hanya H/S/I/A (Zod enum); `entries` 1..500; student duplikat dalam bulk ditolak (`DUPLICATE_STUDENT_ENTRY`).

---

## 5. Perubahan Rekap

- `recorded_days` = `COUNT(DISTINCT attendance_date)` (jumlah tanggal unik).
- H/S/I/A harian dihitung setelah `GROUP BY attendance_date` dengan CASE prioritas **A > I > S > H** → dijamin `H + S + I + A = recorded_days`.
- Rekap sesi tersedia terpisah (`sessionRecap`: `GROUP BY schedule_id,status`) dan **tidak** dipakai untuk raport/rekap berlabel "hari".
- Aturan dihasilkan dari satu modul (`attendance-priority.ts`) yang juga dipakai report dan diuji.
- Snapshot report: draft baru memakai `version:9`; snapshot `version:8` lama **tidak dihitung ulang**.

---

## 6. Excel / Import

- Template Excel **tidak diubah**; import tetap **absensi harian**.
- Apply menulis `attendance` tanpa `schedule_id` → `schedule_id=NULL`.
- Cek konflik diubah menjadi `... AND schedule_id IS NULL FOR UPDATE`, sehingga record sesi baru tidak dianggap record harian.
- `MANUAL_ATTENDANCE_EXISTS` tetap dipertahankan.

---

## 7. Hasil Test / Typecheck

- `npm run typecheck --workspace backend` → **lulus (0 error)**.
- Test backend penuh `npx tsx --test "src/**/*.test.ts"` → **57 tests, 57 pass, 0 fail**.
- Test baru yang relevan:
  - 3 sesi H = 1 hari H.
  - H+H+S = 1 hari S (dan bukan H=2,S=1).
  - H+I+S = 1 hari I.
  - H+S+A = 1 hari A.
  - H+S+I+A = recorded_days (multi-tanggal).
  - Guru boleh schedule sendiri; ditolak (`OUTSIDE_TEACHER_SCOPE`) untuk schedule guru lain; ADMIN/SUPER_ADMIN bebas.
  - Class mismatch & semester mismatch ditolak.
  - Migration 039 (statik): kolom/UNIQUE/FK benar, tanpa backfill.
  - Import tetap `schedule_id=NULL` dan konflik hanya memeriksa baris harian.
  - Kompatibilitas legacy: default `schedule_id IS NULL`; `PUT /bulk` ada; report `version:9` + `GROUP BY attendance_date`.
- Test lama `attendance-xlsx.test.ts` tetap lulus (regression).

> Catatan: test yang membutuhkan DB live (dua sesi tersimpan, bulk transaction end-to-end, lock pada DB) tidak dijalankan karena tidak ada kredensial test/dev dan tidak ada `schema_migrations` yang dapat diakses. Logika inti (prioritas, ownership, mismatch, definisi migration, kompatibilitas) diuji sebagai unit/statik tanpa DB.

---

## 8. Masalah yang Ditemukan

1. **Tidak ada `.env` dev/test dan tidak ada kredensial DB** di `/var/www/madrasah-dev`. Akibatnya:
   - `schema_migrations` **tidak dapat diperiksa** secara langsung; verifikasi "039 belum diterapkan" dilakukan via bukti filesystem (039 tidak ada sebelumnya; migration terakhir 038). Migration **tidak dijalankan** dalam kondisi apa pun.
   - PM2 `madrasah-api` berjalan dari `/var/www/madrasah` (production), **tidak disentuh**.
2. **`scripts/production/validate-test-schema.mjs` meng-hardcode `assert.equal(migration.count, 38)`.** Setelah 039 diterapkan di skema test, assertion ini akan gagal dan **harus diubah ke 39** sebelum `npm run db:validate:test`. Tidak diubah di Tahap 1 agar scope tetap minimal.
3. **Urutan deploy penting:** kode baru (import & attendance) mengasumsikan kolom `attendance.schedule_id` ada. Migration **wajib dijalankan sebelum** backend versi baru aktif.
4. `node_modules` awalnya tidak ada; `npm install` dijalankan (tanpa dependency baru) untuk memenuhi kewajiban typecheck/test.

---

## 9. Bagian yang Belum Dikerjakan

- **Frontend sepenuhnya** (dropdown sesi, tombol Simpan Semua, tampilan rekap). Sesuai instruksi Tahap 1.
- Uji integrasi DB end-to-end (perlu skema test + kredensial).
- Penyesuaian `validate-test-schema.mjs` (item 8.2) dan penambahan test integrasi pada skema `madrasah_ci` — direncanakan setelah kredensial test tersedia.
- Rekap per sesi di UI (hanya backend yang menyediakannya).

---

## 10. Konfirmasi Production Tidak Disentuh

- Tidak ada perubahan pada `/var/www/madrasah`.
- Tidak deploy, tidak restart service, tidak mengubah nginx/SSL/DNS/Cloudflare.
- Tidak push GitHub / merge branch.
- Tidak membaca/menyalin production secrets; tidak membuka `.env.production.local`.
- Tidak menjalankan migration apa pun.

**File final yang berubah di Tahap 1:** hanya `backend/**` dan `database/migrations/039_attendance_schedule_session.sql` (ditambah `node_modules` hasil `npm install`).
