# RENCANA IMPLEMENTASI (REVISI FINAL) — ABSENSI PER SESI / JADWAL

- **Tanggal:** 2 Oktober 2026
- **Workspace:** `/var/www/madrasah-dev`
- **Status:** PLANNING ONLY. Tidak ada source code, migration, database, dependency, deployment, atau push yang diubah. `/var/www/madrasah` (produksi) tidak disentuh.
- **Basis:** `ATTENDANCE-IMPLEMENTATION-PLAN.md` + `ATTENDANCE-FINAL-PLAN-REVIEW.md`.
- **Keputusan produk yang mengikat:**
  1. Guru mengisi absensi **per sesi** sesuai jadwal mengajarnya.
  2. Guru hanya boleh memilih jadwal/sesi yang menjadi **tugasnya sendiri**.
  3. ADMIN/SUPER_ADMIN dapat melihat & mengoreksi berdasarkan tanggal, kelas, dan sesi.
  4. Excel dipertahankan sebagai **ABSENSI HARIAN**.
  5. Data Excel memakai `schedule_id = NULL`.
  6. Data absensi lama **tidak di-backfill**, tetap `schedule_id = NULL`.
  7. Istilah "hari" menghitung **TANGGAL UNIK**, bukan jumlah sesi.
  8. Status HARIAN dari beberapa sesi pada tanggal sama memakai prioritas **A > I > S > H**.
  9. `H + S + I + A = recorded_days` untuk rekap harian.
  10. Rekap **per sesi** tetap ada, tetapi wajib berlabel **"sesi"**, bukan "hari".
  11. Raport memakai rekap **per hari**.
  12. Snapshot/report lama yang sudah diterbitkan **tidak dihitung ulang**.
  13. Migration baru tetap bernomor **039** (`039_attendance_schedule_session.sql`).

---

## A. Files yang Akan Diubah

### Backend
1. `backend/src/modules/attendance/attendance.routes.ts`
2. `backend/src/modules/reports/report.routes.ts`
3. `backend/src/modules/imports/attendance-import.routes.ts`
4. `backend/src/modules/imports/attendance-xlsx.ts` *(opsional; hanya komentar/tidak wajib)*

### Database
5. `database/migrations/039_attendance_schedule_session.sql` *(baru, **belum dijalankan**)*

### Frontend
6. `frontend/src/features/academic/AcademicEditor.tsx`
7. `frontend/src/features/academic/AcademicPage.tsx` *(opsional: kolom sesi & rekap hari)*
8. `frontend/src/features/production/AttendanceImport.tsx` *(opsional: teks "Excel = absensi harian")*
9. `frontend/src/features/reports/ReportPage.tsx` *(hanya bila label perlu ditegaskan sebagai "hari")*

### Tests
10. `backend/src/modules/attendance/attendance-session.test.ts` *(baru)*
11. `backend/src/modules/reports/attendance-recap.test.ts` *(baru)*
12. `backend/src/modules/imports/attendance-xlsx.test.ts` *(**tidak diubah**, regression)*

---

## B. Migration Database (Nomor 039, Belum Dijalankan)

**File baru:** `database/migrations/039_attendance_schedule_session.sql`

**Bukti nomor benar (read-only):** prefix tertinggi di `database/migrations` = **038**; `039` **tidak ada**; `migrate.mjs` memuat pola `/^\d+_.*\.sql$/` lalu `.sort()` dan melacak `schema_migrations`.

**DDL rencana (TIDAK dijalankan sekarang):**
```sql
ALTER TABLE attendance
  ADD COLUMN schedule_id BIGINT UNSIGNED NULL AFTER class_id,
  ADD COLUMN schedule_key BIGINT UNSIGNED
    GENERATED ALWAYS AS (COALESCE(schedule_id, 0)) STORED AFTER schedule_id,
  ADD CONSTRAINT fk_attendance_schedule
    FOREIGN KEY (schedule_id) REFERENCES schedules(id),
  DROP INDEX uq_attendance_student_date,
  ADD UNIQUE KEY uq_attendance_student_date_schedule
    (student_id, attendance_date, schedule_key),
  ADD INDEX idx_attendance_schedule_date (schedule_id, attendance_date);
```

**Mengapa:** `schedule_id NULL` = harian/legacy; `schedule_key = COALESCE(schedule_id,0)` agar UNIQUE memvalidasi NULL; UNIQUE baru mengizinkan sesi ganda per hari sekaligus menjaga satu baris harian.

**Status:** **039 belum dibuat dan belum dijalankan.** Tidak ada referensi `039_attendance_schedule_session.sql` di filesystem (selain dokumen rencana).

**Forward strategy:** jalankan saat backend berhenti (maintenance window), lalu verifikasi index/FK; hole migrasi dilindungi `GET_LOCK('madrasah_schema_migrations')` oleh `migrate.mjs`.
**Rollback strategy:** drop index baru, pulihkan `uq_attendance_student_date`, drop FK, drop `schedule_key`/`schedule_id` — **hanya aman bila belum ada baris `schedule_id IS NOT NULL`**; setelah ada sesi, rollback bersifat satu arah. Backup sebelum migrasi.

---

## C. Backend Changes

### C1. `attendance.routes.ts`

**Apa yang berubah:**
- `GET /class/:classId`: query opsional `scheduleId`.
  - `scheduleId` diisi → filter `a.schedule_id = ?`.
  - `scheduleId` kosong → `a.schedule_id IS NULL` (mode harian legacy, output tidak berubah).
- `GET /student/me`: daftar tetap per baris; rekap memakai **rekap harian** (lihat F): `COUNT(DISTINCT attendance_date)` + H/S/I/A per hari dengan prioritas **A>I>S>H**.
- `PUT /`: tambah `scheduleId: z.number().int().positive().nullable().optional()`.
  - Diisi → validasi `schedule` aktif → turunkan `teaching_assignment` (class/year/semester/teacher); cek enrollment; GURU **wajib** `ta.teacher_id === auth.teacherId`; ADMIN/SUPER_ADMIN lintas; upsert menyertakan `schedule_id`.
  - Null/kosong → perilaku lama (`schedule_id=NULL`).
- `PUT /bulk` (baru): `{ classId, attendanceDate, scheduleId?, entries:[{studentId,status}] }`, satu transaksi, validasi scope sekali, upsert per baris, satu audit `ATTENDANCE.BULK_UPDATED`.
- Tambah endpoint rekap sesi terpisah (opsional) yang **berlabel sesi**: `GET /session-recap` atau parameter `mode=session` yang mengagregasi per `schedule_id`.

**Mengapa:** memenuhi alur sesi Guru, koreksi Admin, bulk save, dan pemisahan rekap hari vs sesi.

**Minimal:** tambahkan parameter/endpoint; jangan rombak struktur atau mekanisme audit.

**TIDAK boleh diubah:** `locks_attendance`, `NO_ENROLLMENT_FOR_DATE`, permission `attendance.manage`, `requireRole`, status `H/S/I/A`.

### C2. Audit koreksi
- `PUT` dan `PUT /bulk` menulis `writeAudit` dengan `before`/`after` untuk koreksi Admin (`ATTENDANCE.UPDATED` / `ATTENDANCE.BULK_UPDATED`).
- **TIDAK diubah:** format `audit_logs` dan middleware `mutationAudit`.

---

## D. Frontend Changes

### D1. `AcademicEditor.tsx`
- `page==='Absensi'`: tambah dropdown **Sesi** dari `GET /api/schedules/teacher/me` (GURU) / `GET /api/schedules/admin` (ADMIN/SUPER_ADMIN), difilter `day_of_week` hasil hitung dari tanggal.
- Opsi pertama **"Tanpa sesi / harian (legacy)"** → `scheduleId=null`.
- Pilih sesi → `GET /api/attendance/class/:classId?from=tgl&to=tgl&scheduleId=...`.
- Ganti Simpan per baris menjadi **"Simpan Semua"** → `PUT /api/attendance/bulk`; pertahankan simpan baris (opsional).
- Label rekap yang ditampilkan = **"hari"** (per hari), bukan sesi.

**Minimal:** satu dropdown + satu tombol bulk; jangan ubah fieldset/tabel.

**TIDAK diubah:** mode Nilai & Muhafadloh di file ini; `ScheduleEditor.tsx` tidak disentuh.

### D2. `AcademicPage.tsx`
- Tampilkan kolom sesi/jam bila ada; rekap yang diberi label "hari" memakai rekap harian. Opsional.

### D3. `AttendanceImport.tsx`
- Teks: "Import Excel = absensi harian (tanpa sesi)". Tidak menambah pilihan sesi.

---

## E. Import Changes

### `attendance-import.routes.ts`
- `apply`: tetap menulis tanpa `schedule_id` → `schedule_id=NULL`.
- Cek `existing` → `SELECT source FROM attendance WHERE student_id=? AND attendance_date=? AND schedule_id IS NULL FOR UPDATE`.
- `ON DUPLICATE KEY UPDATE` tetap aman (`schedule_key=0`).
- Pertahankan `MANUAL_ATTENDANCE_EXISTS`.

**Minimal:** ubah klausa WHERE `existing`; jangan tambah kolom sesi ke template.

**TIDAK diubah:** header template (NIS/Nama/Kelas/Tanggal/Status), dedup `(student,date)` dalam batch, status batch.

---

## F. Report / Recap Changes (Keputusan Produk)

### Aturan baku
- **`recorded_days = COUNT(DISTINCT attendance_date)`**.
- **H/S/I/A raport dihitung SETELAH menggabungkan sesi per `attendance_date`** dengan prioritas **A > I > S > H**:
  - ada A → hari = A; jika tidak ada A tapi ada I → I; jika tidak ada A/I tapi ada S → S; jika semua H → H.
- Konsekuensi: **H + S + I + A = recorded_days** (rekap harian).
- **Rekap per sesi** tetap tersedia terpisah dan **wajib berlabel "sesi"**.

### `report.routes.ts`
**Apa yang berubah:**
- Query rekap semester diganti menjadi rekap harian (lihat D2 di bawah).
- Naikkan `version` snapshot **8 → 9** karena semantik rekap berubah.
- **Snapshot lama (version 8) yang sudah diterbitkan tetap disimpan apa adanya** dan hanya dibaca/ditampilkan; tidak dihitung ulang. Hanya draft baru memakai version 9.

**Minimal:** satu query rekap + satu angka `version`.

**TIDAK diubah:** struktur `snapshot_json`, `publicationReadiness`, field `grades`/`assessment`/`muhafadloh`.

### Query/algoritma (bagian B tugas — dijelaskan eksplisit)
```sql
-- recorded_days = tanggal unik
SELECT COUNT(DISTINCT attendance_date) AS recorded_days
FROM attendance
WHERE student_id=? AND academic_year_id=? AND attendance_date BETWEEN ? AND ?;

-- H/S/I/A harian dengan prioritas A > I > S > H, lalu agregasi
SELECT
  SUM(day_status='H') AS H,
  SUM(day_status='S') AS S,
  SUM(day_status='I') AS I,
  SUM(day_status='A') AS A,
  COUNT(*)            AS recorded_days
FROM (
  SELECT attendance_date,
    CASE
      WHEN MAX(status='A')=1 THEN 'A'
      WHEN MAX(status='I')=1 THEN 'I'
      WHEN MAX(status='S')=1 THEN 'S'
      ELSE 'H'
    END AS day_status
  FROM attendance
  WHERE student_id=? AND academic_year_id=? AND attendance_date BETWEEN ? AND ?
  GROUP BY attendance_date
) d;

-- rekap PER SESI (label "sesi", bukan "hari")
SELECT schedule_id, status, COUNT(*) AS sessions
FROM attendance
WHERE academic_year_id=? AND attendance_date BETWEEN ? AND ?
GROUP BY schedule_id, status;
```
- `CASE` di atas menerapkan prioritas A > I > S > H secara deterministik; `H+S+I+A` selalu sama dengan `COUNT(*)` (jumlah tanggal unik).
- Rekap sesi tidak boleh dipakai untuk raport dan tidak boleh dilabeli "hari".

---

## G. Tests

### `attendance-session.test.ts` (baru)
1. Guru hanya dapat mengisi schedule miliknya → sukses.
2. Guru tidak dapat mengisi schedule guru lain → `403 OUTSIDE_TEACHER_SCOPE`.
3. Dua schedule berbeda pada tanggal sama menyimpan **dua record SESI**.
4. `schedule_id=NULL` tetap bekerja (satu baris harian).
5. Bulk save satu kelas menyimpan semua entri satu transaksi.
6. `locks_attendance` memblokir mode sesi & harian.

### `attendance-recap.test.ts` (baru — sesuai keputusan produk)
7. 3 sesi H pada tanggal sama = **1 hari H**.
8. H + H + S = **1 hari S**.
9. H + I + S = **1 hari I**.
10. H + S + A = **1 hari A**.
11. H + H + S **tidak boleh** menghasilkan H=2, S=1 pada rekap HARIAN.
12. H + H + S → `recorded_days = 1`.
13. Untuk setiap tanggal uji: **H + S + I + A = recorded_days**.
14. Dua sesi pada tanggal sama tetap boleh tersimpan sebagai dua record SESI (berbeda `schedule_id`).
15. Rekap sesi mengembalikan hitungan per sesi dan **dilabeli "sesi"**, bukan "hari".

### Regression / integrasi
16. Excel `apply` tetap `schedule_id=NULL` dan tetap menolak menimpa manual harian.
17. Data lama `schedule_id=NULL` tetap kompatibel (GET/PUT lama tidak berubah).
18. Audit koreksi tercatat (`ATTENDANCE.UPDATED` / `BULK_UPDATED`).
19. Snapshot raport version 8 lama tetap dapat dibaca; draft baru memakai version 9.
20. `attendance-xlsx.test.ts` dipertahankan apa adanya.

---

## H. Security / Authorization
- `requireAuthentication` + `requireRole('SUPER_ADMIN','ADMIN','GURU')` + `requirePermission('attendance.manage')` tetap.
- Kepemilikan sesi divalidasi di dalam transaksi (`FOR UPDATE`): `teaching_assignments.teacher_id = auth.teacherId`; mencegah TOCTOU dan lintas guru.
- ADMIN/SUPER_ADMIN boleh melihat/mengoreksi lintas kelas & sesi; koreksi diaudit with before/after.
- Import tetap `attendance.import.manage`.
- Tidak menampilkan/menulis secret; tidak menyentuh `.env` produksi.

## I. Backward Compatibility
- Data lama & Excel tetap `schedule_id=NULL`; tanpa backfill.
- GET/PUT lama tanpa `scheduleId` berperilaku identik.
- Snapshot terbit lama tidak dihitung ulang.
- Raport memakai rekap hari sehingga angka "hari" tidak terpengaruh jumlah sesi.
- Opsi "Tanpa sesi / harian" menjaga alur Admin lama.

## J. Deployment Sequence
1. Persetujuan implementasi.
2. Kode backend → frontend di dev; `npm run typecheck`.
3. Test unit/integrasi di skema test (bukan produksi).
4. Backup database (kebijakan operator).
5. Jalankan migrasi **039** saat backend berhenti.
6. Verifikasi index/FK & sanity check rekap.
7. Deploy backend lalu frontend.
8. Verifikasi Guru/Admin/Import/Report di dev.
9. **Jangan** push GitHub / deploy produksi tanpa instruksi eksplisit.

## K. Rollback Strategy
- Kode: revert commit (belum ada push).
- DB: hanya aman bila belum ada baris `schedule_id IS NOT NULL` — pulihkan index/kolom. Setelah ada sesi, ekspor data sesi lalu rollback; jangan hapus data tanpa persetujuan.
- Snapshot version lama tetap terbaca, sehingga rollback rekap tidak merusak data tersimpan.

## L. Risiko
- **Rekap salah label:** memakai rekap sesi di tempat berlabel "hari" → melanggar keputusan; mitigasi query CASE + test #7–#15.
- **Rollback satu arah** setelah sesi ganda tersimpan.
- **Upsert salah sasaran** bila `schedule_id` lupa disertakan; mitigasi test #3/#4.
- **Import error** bila cek `existing` tidak menyertakan `schedule_id IS NULL`.
- **Scope guru** salah bila validasi tidak memakai `teaching_assignment.teacher_id`; mitigasi test #1/#2.
- **`AcademicEditor.tsx`** padat → risiko memecah alur Nilai/Muhafadloh; ubah terisolasi + typecheck + smoke test.

---

## M. Ringkasan Perubahan per File (apa / mengapa / minimal / jangan diubah)
- **039 migration:** +`schedule_id`, +`schedule_key`, FK, UNIQUE baru / sesi & harian koeksis / satu tabel / jangan backfill atau ubah kolom lain.
- **attendance.routes.ts:** +`scheduleId`, +`PUT /bulk`, rekap hari (A>I>S>H) + rekap sesi terpisah / alur Guru & koreksi / sisipkan parameter & endpoint / jangan ubah lock, permission, status.
- **report.routes.ts:** rekap harian `COUNT(DISTINCT)` + CASE prioritas, version 9 / makna "hari" benar / satu query + satu angka / jangan hitung ulang snapshot lama atau ubah struktur lain.
- **attendance-import.routes.ts:** `existing ... schedule_id IS NULL` / import tetap harian / satu klausa / jangan ubah template & dedup.
- **AcademicEditor.tsx:** +dropdown sesi, +Simpan Semua / alur Guru / sisipkan kontrol / jangan ubah Nilai/Muhafadloh.
- **AcademicPage.tsx / AttendanceImport.tsx / ReportPage.tsx:** opsional label/kolom / transparansi / teks saja / jangan ubah logika inti.
- **Tests:** sesi, bulk, rekap prioritas A>I>S>H, `H+S+I+A=recorded_days`, snapshot, audit, import, regression / bukti pemenuhan / file baru / jangan hapus test parser.
