# FINAL PLAN REVIEW — ABSENSI PER SESI

- **Tanggal:** 2 Oktober 2026
- **Workspace:** `/var/www/madrasah-dev`
- **Sifat:** REVIEW ONLY. Tidak ada source code, migration, database, dependency, deployment, atau push yang diubah.
- **Ditinjau:** `ATTENDANCE-IMPLEMENTATION-PLAN.md`
- **Catatan ambiguitas:** keputusan semantik status H/S/I/A **tidak dapat ditentukan dari kode saja**; poin yang ambigu ditandai eksplisit dan harus dikonfirmasi produk.

---

## A. Migration Number yang Benar dan Bukti File Migration Terakhir

**Bukti repository (read-only):**
```
$ ls database/migrations | sort | tail -3
036_final_exam_import_provenance.sql
037_master_data_import_permission_forward.sql
038_master_data_import_admin_permission.sql
```
- Jumlah file migration: **38**.
- Prefix numerik tertinggi: **038**.
- Pencarian `039` / `040` di seluruh repo: **tidak ada** (`NO 039`, `NO 040`).
- `scripts/production/migrate.mjs` memuat file dengan pola `/^\d+_.*\.sql$/` lalu `.sort()` (semua zero-padded 3 digit) dan mencatat ke `schema_migrations`.

**Kesimpulan:** nomor **039 belum digunakan** dan **039 adalah nomor yang benar** untuk migration baru (`039_attendance_schedule_session.sql`). Tidak ada koreksi nomor yang diperlukan pada rencana sebelumnya.

**Ambigu yang dicatat:** migration yang benar-benar diterapkan di database bergantung pada isi tabel `schema_migrations`, yang tidak diperiksa di sini (tidak melakukan koneksi DB). Verifikasi `schema_migrations` harus dilakukan operator saat eksekusi.

---

## B. Masalah Semantik H/S/I/A pada Rencana Sebelumnya

Rencana sebelumnya menyatakan cukup mengganti `COUNT(*)` menjadi `COUNT(DISTINCT attendance_date)` dan **mempertahankan `SUM(status='H'/'S'/'I'/'A')`**. Itu **belum cukup aman**:

1. **`recorded_days` memang diperbaiki** oleh `COUNT(DISTINCT attendance_date)` — tidak lagi menghitung sesi.
2. **Tetapi `SUM(status=...)` tetap menghitung per-sesi.** Bila seorang santri punya 3 sesi pada tanggal yang sama: sesi 1 = H, sesi 2 = S, sesi 3 = S, maka rekap menjadi H=1, S=2. Pada laporan berlabel "hari" ini **menghitung sesi sebagai hari** (H+S = 3 padahal 1 hari). Ini melanggar requirement: "Jangan membiarkan laporan berlabel 'hari' diam-diam menghitung jumlah sesi."
3. **Total H+S+I+A bisa > `recorded_days`**, membingungkan pembaca raport.
4. **Import Excel menulis `schedule_id=NULL` dan satu baris per hari**, jadi di data harian murni tidak ada masalah; masalah baru muncul begitu ada sesi ganda per tanggal.
5. **Snapshot lama** yang sudah ter-publish tidak boleh dihitung ulang; hanya draft baru yang memakai semantik baru.

**Kesimpulan:** `recorded_days` = `COUNT(DISTINCT attendance_date)` benar; **`H/S/I/A` wajib pula didefinisikan pada level hari**, dan definisi mana yang dipakai **harus diputuskan produk** (lihat C/D).

---

## C. Desain Rekap yang Direkomendasikan (berdasarkan kode yang ada)

Kode saat ini: rekap hanya ada di `attendance.routes.ts` (`GET /student/me`) dan `report.routes.ts` (snapshot). Tidak ada tabel rekap tersimpan, sehingga perubahan cukup di dua query.

### C1. Rekap per SESI
- Definisi: hitung setiap baris `attendance` (satu baris = satu sesi).
- Penggunaan: tampilan operasional per sesi/kelas/jadwal; audit; bukan untuk raport.
- Query: agregasi langsung tanpa `DISTINCT` (mis. `SUM(status='H')` per `schedule_id`).
- Wajib diberi label "sesi", bukan "hari".

### C2. Rekap per HARI
- Definisi: satu baris per `attendance_date` per santri, setelah menggabungkan semua sesi pada tanggal itu.
- `recorded_days` = `COUNT(DISTINCT attendance_date)`.
- `H/S/I/A` per hari = **satu status per tanggal** yang diturunkan dari sesi-sesi tanggal tersebut.
- Penggunaan: raport, rekap santri, statistik "hari efektif".

### C3. Mana yang Digunakan Raport
- Raport memakai **rekap per HARI** (sesuai `report.routes.ts` membaca per semester dan `AcademicPage`/`ReportPage` menampilkan "Hadir/Sakit/Izin/Tanpa keterangan" + "Hari tercatat").
- Raport **tidak** boleh menampilkan hitungan sesi di bawah label "hari".

### C4. Ambiguitas yang harus dikonfirmasi produk (jangan diasumsikan)
- Jika satu tanggal punya sesi dengan status berbeda, status **hari** yang mana?
  - **Opsi A (status dominan dengan prioritas):** mis. A > I > S > H. Deterministik, H+S+I+A tidak melebihi `recorded_days`. Prioritas harus ditetapkan resmi.
  - **Opsi B (per-status distinct day):** H = jumlah tanggal yang punya minimal satu H, dst. Menghindari pemilihan prioritas, tetapi H+S+I+A **bisa** melebihi `recorded_days` (overlap), sehingga harus diberi keterangan.
  - **Opsi C (harian saja):** pertahankan `SUM` apa adanya dan **hanya benar** bila dipastikan tidak ada sesi ganda per tanggal. Ini tidak memenuhi skenario sesi ganda, jadi tidak direkomendasikan.
- Rekomendasi: **Opsi A** untuk raport (jumlah hari konsisten), dengan prioritas resmi. Jika produk memilih Opsi B, label kolom harus diubah agar tidak menyiratkan "hari". Keputusan ini **tidak boleh** diambil dari kode/asumsi.

---

## D. Query/Algoritma untuk Menghindari Menghitung Sesi sebagai Hari

### D1. `recorded_days` (aman, tidak ambigu)
```sql
SELECT COUNT(DISTINCT attendance_date) AS recorded_days
FROM attendance
WHERE student_id=? AND academic_year_id=? AND attendance_date BETWEEN ? AND ?;
```

### D2. Rekap per HARI dengan status dominan (Opsi A)
```sql
SELECT
  SUM(day_status='H') AS H,
  SUM(day_status='S') AS S,
  SUM(day_status='I') AS I,
  SUM(day_status='A') AS A,
  COUNT(*)            AS recorded_days
FROM (
  SELECT attendance_date,
    CASE
      WHEN MAX(status='A')=1 THEN 'A'
      WHEN MAX(status='I')=1 THEN 'I'
      WHEN MAX(status='S')=1 THEN 'S'
      ELSE 'H'
    END AS day_status
  FROM attendance
  WHERE student_id=? AND academic_year_id=? AND attendance_date BETWEEN ? AND ?
  GROUP BY attendance_date
) d;
```
- Menjamin `H+S+I+A = recorded_days` (jumlah hari), sehingga label "hari" benar.
- Prioritas A>I>S>H adalah contoh; **harus disetujui produk**.

### D3. Rekap per-status distinct day (Opsi B, bila dipilih)
```sql
SELECT
  COUNT(DISTINCT CASE WHEN status='H' THEN attendance_date END) AS H,
  COUNT(DISTINCT CASE WHEN status='S' THEN attendance_date END) AS S,
  COUNT(DISTINCT CASE WHEN status='I' THEN attendance_date END) AS I,
  COUNT(DISTINCT CASE WHEN status='A' THEN attendance_date END) AS A,
  COUNT(DISTINCT attendance_date) AS recorded_days
FROM attendance
WHERE student_id=? AND academic_year_id=? AND attendance_date BETWEEN ? AND ?;
```
- `H+S+I+A` dapat melebihi `recorded_days` (overlap); wajib diberi keterangan di UI.

### D4. Rekap per SESI
```sql
SELECT schedule_id, status, COUNT(*) 
FROM attendance
WHERE student_id=? AND attendance_date BETWEEN ? AND ?
GROUP BY schedule_id, status;
```
- Dipakai tampilan operasional; label "sesi".

### D5. Aturan implementasi
- Untuk raport dan `GET /student/me`, gunakan **D1 + D2** (atau D1 + D3 sesuai keputusan), **bukan** `SUM` lintas baris.
- Untuk daftar per kelas (`GET /class/:classId`) tetap mengembalikan baris individual (sesi), tetapi bila UI merangkum, gunakan D1/D2.
- Query lama `SUM(status=...)` tanpa collapse **hanya** benar untuk data `schedule_id=NULL` murni; jangan dipakai pada dataset bercampur.

---

## E. Perubahan yang Harus Dilakukan terhadap `ATTENDANCE-IMPLEMENTATION-PLAN.md`

- **A (Files):** tidak berubah; nomor migration **039 tetap** (terverifikasi). Tambahkan catatan verifikasi `schema_migrations`.
- **B (Migration):** tidak berubah secara DDL; tambahkan peringatan rollback satu arah (sudah ada) dan konfirmasi nomor 039.
- **F (Report/Recap):** **revisi wajib.** Ganti butir "cukup `COUNT(DISTINCT)` + pertahankan `SUM(status=...)`" dengan:
  - `recorded_days` = `COUNT(DISTINCT attendance_date)`.
  - `H/S/I/A` dihitung **per hari** memakai subquery `GROUP BY attendance_date` (D2) atau distinct-day (D3) sesuai keputusan produk.
  - Tegaskan Opsi A/B dan bahwa keputusan belum ditetapkan (ambiguitas eksplisit).
- **F (version):** tetap naikkan `version: 8 → 9` karena semantik rekap berubah; tambahkan alasan: `H/S/I/A` kini per-hari, bukan per-sesi.
- **F (Catatan semantik):** hapus opsi "pertahankan SUM" sebagai default; jadikan hanya sebagai catatan bahwa itu tidak valid untuk sesi ganda.
- **G (Tests):** tambahkan test bahwa `H+S+I+A` **tidak melebihi** `recorded_days` (Opsi A) atau bahwa overlap terdokumentasi (Opsi B); pertahankan test DISTINCT.
- **C1/C2 (Backend):** tambahkan bahwa rekap `/student/me` memakai D2/D3, bukan hanya D1.
- **D (Frontend):** jika Opsi B dipilih, ubah label agar tidak menyiratkan "hari"; jika Opsi A, label tetap.
- **H/L (Security/Risiko):** tambahkan risiko salah interpretasi rekap bila keputusan produk belum final.

---

## F. Daftar Final File yang Akan Diubah

### Backend
1. `backend/src/modules/attendance/attendance.routes.ts` — tambah `scheduleId` (GET/PUT), `PUT /bulk`; rekap `/student/me` memakai D1 + D2/D3.
2. `backend/src/modules/reports/report.routes.ts` — rekap snapshot memakai `COUNT(DISTINCT attendance_date)` + H/S/I/A per hari (D2/D3); `version` 8 → 9.
3. `backend/src/modules/imports/attendance-import.routes.ts` — cek `existing ... schedule_id IS NULL`; apply tetap `schedule_id=NULL`.

### Database
4. `database/migrations/039_attendance_schedule_session.sql` — **nomor terverifikasi** (`+schedule_id`, `+schedule_key COALESCE(schedule_id,0)`, FK `schedules(id)`, `UNIQUE(student_id, attendance_date, schedule_key)`). Belum dijalankan.

### Frontend
5. `frontend/src/features/academic/AcademicEditor.tsx` — dropdown sesi (opsi "Tanpa sesi/harian"), tombol "Simpan Semua", filter jadwal per hari.
6. `frontend/src/features/academic/AcademicPage.tsx` — opsional: kolom sesi & rekap per hari.
7. `frontend/src/features/production/AttendanceImport.tsx` — opsional: teks "Excel = absensi harian".
8. `frontend/src/features/reports/ReportPage.tsx` — hanya bila label H/S/I/A perlu disesuaikan dengan Opsi A/B.

### Tests
9. `backend/src/modules/attendance/attendance-session.test.ts` — baru (ownership, sesi ganda, NULL, bulk, lock).
10. `backend/src/modules/reports/attendance-recap.test.ts` — baru (DISTINCT hari, H+S+I+A ≤ recorded_days untuk Opsi A, snapshot version).
11. `backend/src/modules/imports/attendance-xlsx.test.ts` — **tidak diubah**; dipertahankan sebagai regression.

**Tidak ada file diubah pada review ini** — daftar di atas adalah rencana setelah revisi, menunggu persetujuan.
